import Ajv from "https://cdn.skypack.dev/ajv";
const validateSchema = function (payload, schema, error_el) {
	console.log("payload", payload);
	const parsed_schema = JSON.parse(schema);
	const ajv = new Ajv({ allErrors: true });
	const validate = ajv.compile(parsed_schema);
	const valid = validate(payload);
	error_el.empty();
	if (!valid) {
		validate.errors.forEach((error) => {
			render_error(error_el, `${error.instancePath} ${error.message}`);
		});
		return false;
	}
	return true;
};

const render_error = function (el, message) {
	const errorMessage = document.createElement("p");
	errorMessage.classList.add("text-sm", "p-1", "pb-2");
	errorMessage.textContent = message;
	el.append(errorMessage).show();
};

const validateFile = function (file, error_el, maxSize = 750 * 1024, filenameLength = 64) {
	console.info("File selected:", file.name);
	if (file) {
		if (file.name.length > filenameLength) {
			let msg = `Filename length exceeds ${filenameLength} characters.`;
			render_error(error_el, msg);
			throw new Error(msg);
		} else if (file.size > maxSize) {
			let msg = `File size ${file.size} exceeds ${maxSize} bytes.`;
			render_error(error_el, msg);
			throw new Error(msg);
		} else {
			return true;
		}
	}
};

export { validateSchema, validateFile };
