use aarya_entities::openai::chat::ChatEntity;
use actix_web::{web, HttpResponse, Responder};
use log::debug;
use mongodb::Client as MongoClient;

use crate::auth::user::UserAuth;

pub async fn get_chats_by_user(
    mongoc: web::Data<MongoClient>,
    session: actix_session::Session,
) -> impl Responder {
    let user_id = UserAuth::from(session).google_model.unwrap().id;
    let chat = ChatEntity {
        user_id: user_id.clone(),
        ..ChatEntity::default()
    };
    match chat.filter(&mongoc).await {
        Some(chats) => {
            debug!("Found {} chats for user: {}", chats.len(), user_id);
            HttpResponse::Ok().json(chats)
        }
        None => {
            debug!("No chats found for user: {}", user_id);
            HttpResponse::NotFound().finish()
        }
    }
}
