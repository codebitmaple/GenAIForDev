use aarya_entities::{
    course::course_entity::CourseEntity,
    openai::{
        chat::ChatEntity,
        completion_request::{Content, ContentType, Message, ResponseFormat, ResponseFormatType},
    },
    topic::topic_entity::TopicEntity,
    unit::unit_entity::UnitEntity,
};
use aarya_utils::{cache_ops, markdown_ops};
use actix_web::{web, HttpResponse, Responder};
use log::{debug, error};
use mongodb::Client as MongoClient;
use serde_json::json;

use crate::{api::openai::TopicInteraction, auth::user::UserAuth};

use super::{post_chat_completion, prepare_course_response_links, TopicFollowupRequest};

pub async fn get_tutorial(
    mongoc: web::Data<MongoClient>,
    path: web::Path<String>,
    cache: web::Data<cache_ops::Cache>,
) -> impl Responder {
    let topic_id = path.into_inner();

    let topic = match TopicEntity::find_by_id(&mongoc, &cache, topic_id).await {
        Some(t) => t,
        None => return HttpResponse::NotFound().body("Error finding topic"),
    };

    let markdown = markdown_ops::to_html(&topic.markdown);

    HttpResponse::Ok().json(json!({
        "id": topic._id.to_hex(),
        "name": topic.name,
        "description": topic.summary,
        "markdown": markdown,
    }))
}

pub async fn get_topic_by(
    mongoc: web::Data<MongoClient>,
    path: web::Path<(String, String, String)>,
    cache: web::Data<cache_ops::Cache>,
) -> impl Responder {
    let args = path.into_inner();
    let course_slug = args.0;
    let unit_slug = args.1;
    let topic_slug = args.2;

    let courses = CourseEntity::scan(&mongoc, &cache).await.unwrap();
    let units = UnitEntity::scan(&mongoc, &cache).await.unwrap();
    let topics = TopicEntity::scan(&mongoc, &cache).await.unwrap();

    let course = match courses.iter().find(|c| c.slug == course_slug) {
        Some(c) => c,
        None => return HttpResponse::NotFound().body("Error finding course"),
    };

    let course_response = match prepare_course_response_links(&units, &topics, course) {
        Some(c) => c,
        None => return HttpResponse::NotFound().body("Error finding course"),
    };

    let unit = match units.iter().find(|u| u.slug == unit_slug && u.course_id == course._id.to_hex()) {
        Some(u) => u,
        None => return HttpResponse::NotFound().body("Error finding unit"),
    };

    let topic = match topics.iter().find(|t| t.slug == topic_slug && t.unit_id == unit._id.to_hex()) {
        Some(t) => t,
        None => return HttpResponse::NotFound().body("Error finding topic"),
    };

    let markdown = markdown_ops::to_html(&topic.markdown);

    HttpResponse::Ok().json(json!({
        "id": topic._id.to_hex(),
        "name": topic.name,
        "description": topic.summary,
        "markdown": markdown,
        "course_slug": course_slug,
        "unit_slug": unit_slug,
        "course_all": course_response,
    }))
}

pub async fn post_topic_followup(
    model: web::Json<TopicFollowupRequest>,
    session: actix_session::Session,
) -> impl Responder {
    let model = model.into_inner();
    let user_auth = UserAuth::from(session);
    let messages = vec![
        Message {
            role: "system".to_string(),
            content: vec![Content {
                content_type: ContentType::Text,
                text: Some(format!(
                    "You are an expert in computer science, engineering, and architecture. \
                    A student is learning: `{}` and has questions about the unit: `{}` and topic: `{}`. \
                    Please generate 4, 7-15 words follow-up questions. \
                    The questions must be contextual, aiding the fundamental undertsanding of the problem, \
                    such as generating code samples, using analogies, practical examples, etc. \
                    Do not include questions unrelated to the given course, unit, and topic.",
                    model.course_name, model.unit_name, model.topic_name
                )),
                image_url: None,
            }],
        },
        Message {
            role: "user".to_string(),
            content: vec![Content {
                content_type: ContentType::Text,
                text: Some(format!(
                    "I need to understand the following part of the topic: {}\n \
                    Use the full text of the tutorial for additional context: {}",
                    model.question, model.context
                )),
                image_url: None,
            }],
        },
    ];
    debug!("Sending messages: {:?}", messages);
    let response_format = ResponseFormat {
        format_type: ResponseFormatType::JsonSchema,
        json_schema: Some(serde_json::json!({
          "name": "FollowupQuestions",
          "schema": {
            "type": "object",
            "properties": {
              "followups": {
                "type": "array",
                "items": {
                  "type": "string",
                  "description": "This text will be used as an HTML button text"
                }
              }
            },
            "required": ["followups"]
          }
        })),
    };

    match post_chat_completion(messages, Some(response_format), Some(user_auth.google_model.unwrap().id)).await {
        Some(r) => HttpResponse::Ok().json(r),
        None => {
            error!("Failed to post chat completion");
            HttpResponse::InternalServerError().json(json!({"message": "Failed to post chat completion"}))
        }
    }
}

pub async fn post_topic_explanation_followups(
    mongoc: web::Data<MongoClient>,
    model: web::Json<TopicFollowupRequest>,
    session: actix_session::Session,
) -> impl Responder {
    let model = model.into_inner();
    let user_auth = UserAuth::from(session);
    let messages = vec![
        Message {
            role: "system".to_string(),
            content: vec![Content {
                content_type: ContentType::Text,
                text: Some(format!(
                    "You are an expert in computer science, engineering, and architecture. \
                    A student is learning the course: `{}`, unit: `{}`, and topic: `{}` has asked a followup question that you need to answer. \
                    Generate concise responses in JSON format strictly adhering to the schema. \
                    Limit the `description` field to 50-75 words. \
                    Limit the `summary` field to 50-75 words. \
                    Show, don't tell. \
                    Use first principles and explain keywords to aid understanding and learning. \
                    Use active voice, short sentences, and bullet points. \
                    Use analogies, practical examples, code samples, etc. \
                    The response in the description field must be well-formatted html inside a div with headers and lists (only HTML without backticks). \
                    Describe with code samples, analogies, practical examples, etc. \
                    Include 2-3 follow-up questions that further aids in learning the about the question asked. \
                    Do not include followup questions that are unrelated to the course, unit, and topic",
                    model.course_name, model.unit_name, model.topic_name
                )),
                image_url: None,
            }],
        },
        Message {
            role: "user".to_string(),
            content: vec![Content {
                content_type: ContentType::Text,
                text: Some(format!(
                    "I need to understand the following: {}\n \
                Use the full text of the tutorial for additional context: {}",
                    model.question, model.context
                )),
                image_url: None,
            }],
        },
    ];
    debug!("Sending messages: {:?}", messages);
    let response_format = ResponseFormat {
        format_type: ResponseFormatType::JsonSchema,
        json_schema: Some(serde_json::json!({
          "name": "FollowupQuestions",
            "schema": {
                "type": "object",
                "properties": {
                    "title": {
                        "type": "string",
                        "description": "Identify a suitable title for this interaction in 5-10 words."
                    },
                    "summary": {
                        "type": "string",
                        "description": "Summarize the response. State its intent and purpose. Explain what is it about and how can it help its learner in plain text format."
                    },
                    "description": {
                        "type": "string",
                        "description": "A brief description of the topic in HTML format and will go inside a div"
                    },
                    "followups": {
                        "type": "array",
                        "items": {
                            "type": "string",
                            "description": "This text will be used as an HTML button text"
                        }
                    }
                },
                "required": ["description", "followups", "summary", "title"]
            }
        })),
    };

    match post_chat_completion(messages, Some(response_format), Some(user_auth.google_model.clone().unwrap().id)).await {
        Some(r) => {
            let response = serde_json::from_str::<TopicInteraction>(r.as_str()).unwrap();
            let chat = ChatEntity {
                user_id: user_auth.google_model.unwrap().id,
                source: "topic-followup".to_string(),
                course_name: Some(model.course_name),
                unit_name: Some(model.unit_name),
                topic_name: Some(model.topic_name),
                question: model.question,
                context: Some(model.context),
                response: r.clone(),
                summary: Some(response.summary),
                title: Some(response.title),
                ..Default::default()
            };
            match chat.create(&mongoc).await {
                Some(_) => debug!("chat saved"),
                None => {
                    error!("Failed to save chat");
                    return HttpResponse::InternalServerError().json(json!({"message": "Failed to save chat"}));
                }
            }
            HttpResponse::Ok().json(r)
        }
        None => {
            error!("Failed to post chat completion");
            HttpResponse::InternalServerError().json(json!({"message": "Failed to post chat completion"}))
        }
    }
}
