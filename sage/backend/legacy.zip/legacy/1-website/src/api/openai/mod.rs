use rand::seq::SliceRandom;
use serde_json::json;
use std::collections::{HashMap, HashSet};

use aarya_entities::{
    course::course_entity::CourseEntity,
    openai::{
        chat::ChatEntity,
        completion_request::{ChatCompletionRequest, Content, ContentType, Message, ResponseFormat, ResponseFormatType},
        completion_response::ChatCompletionResponse,
        PostChatCompletionRequest,
    },
    question::question_entity::{QuestionEntity, QuestionKind, QuestionTarget},
    topic::topic_entity::TopicEntity,
    unit::unit_entity::UnitEntity,
};
use aarya_utils::{
    cache_ops,
    environ::{Environ, Environment, OpenAIConfig},
};
use actix_web::{web, HttpResponse, Responder};
use exam::{get_exam_results, post_exam_followup_answer};
use exercise::{get_exercise_results, post_exercise_followup_answer};
use log::debug;
use mongodb::Client;
use practice_test::{get_practice_results, post_practice_followup_answer};
use reqwest::Client as HttpClient;
use serde::{Deserialize, Serialize};

use crate::auth::user::UserAuth;

pub mod chat;
pub mod course;
pub mod exam;
pub mod exercise;
pub mod practice_test;
pub mod result;
pub mod topic;
pub mod unit;

#[derive(Debug, Serialize, Deserialize)]
pub struct TopicInteraction {
    /// Identify a suitable title for this interaction in 5-10 words.
    pub title: String,

    /// Summarize the response. State its intent and purpose. Explain what it is about and how it can help its learner in plain text format.
    pub summary: String,

    /// A brief description of the topic in HTML format that will go inside a div.
    pub description: String,

    /// A list of follow-up prompts. Each item will be used as HTML button text.
    pub followups: Vec<String>,
}

#[derive(Debug, Serialize, Deserialize, Clone)]
pub struct RecommendationInteraction {
    /// Identify a suitable title for this interaction in 5-10 words.
    pub title: String,

    /// Summarize the response. State its intent and purpose. Explain what it is about and how it can help its learner in plain text format.
    pub summary: String,

    /// A brief description of the topic in HTML format that will go inside a div.
    pub description: String,
}

#[derive(Serialize, Deserialize, Debug, Clone)]
pub enum TestType {
    #[serde(rename = "exercise")]
    Exercise,
    #[serde(rename = "exam")]
    MockExam,
    #[serde(rename = "practice")]
    PracticeTest,
}

#[derive(Serialize, Deserialize, Debug, Clone)]
pub struct TopicFollowupRequest {
    pub question: String,
    pub context: String,
    pub course_name: String,
    pub user_type: String,
    pub user_level: String,
    pub unit_name: String,
    pub topic_name: String,
}

#[derive(Serialize, Deserialize, Debug, Clone)]
pub struct FollowupRequest {
    pub question: String,
    pub context: String,
    pub test_type: TestType,
    pub test_id: String,
    pub question_id: String,
    pub course_name: String,
    pub user_type: String,
    pub unit_name: Option<String>,
    pub topic_name: Option<String>,
    pub is_correct: bool,
}

pub async fn post_post_chat_completion(model: web::Json<PostChatCompletionRequest>) -> impl Responder {
    let model = model.into_inner();
    post_chat_completion(model.messages, model.response_format, Some("aarya".to_string())).await
}

pub async fn post_chat_completion(
    messages: Vec<Message>,
    response_format: Option<ResponseFormat>,
    user_id: Option<String>,
) -> Option<String> {
    let openai_config: OpenAIConfig = Environ::init();

    let max_completion_tokens = if Environment::get_env() == Environment::Dev { None } else { Some(2048) };

    let openai_request = ChatCompletionRequest {
        model: openai_config.model,
        messages,
        stream: Some(false),
        max_completion_tokens,
        user: user_id,
        response_format,
        temperature: Some(0.5),
        top_p: None,
        n: Some(1),
        stop: None,
        presence_penalty: None,
        frequency_penalty: None,
        logit_bias: None,
    };

    let client = HttpClient::new();
    let response = client
        .post("https://api.openai.com/v1/chat/completions")
        .header("Content-Type", "application/json")
        .header("Authorization", format!("Bearer {}", openai_config.api_key))
        .json(&openai_request)
        .send()
        .await;

    let response = match response {
        Ok(r) => r,
        Err(e) => {
            log::error!("OpenAI request failed: {}", e);
            return None;
        }
    };

    if response.status().is_success() {
        let response_body = response.text().await.unwrap();
        let data = serde_json::from_str::<ChatCompletionResponse>(&response_body).unwrap();
        let choice = &data.choices[0];
        debug!("Finish reason: {}", choice.finish_reason);
        let content = &choice.message.content;
        Some(content.to_string())
    } else {
        log::error!("OpenAI response NOT OK: {} Details: [{}]", response.status(), response.text().await.unwrap());
        None
    }
}

pub async fn get_test_results(
    mongoc: web::Data<Client>,
    cache: web::Data<cache_ops::Cache>,
    path: web::Path<(TestType, String)>,
) -> impl Responder {
    let (test_type, test_id) = path.into_inner();

    match test_type {
        TestType::Exercise => get_exercise_results(mongoc, cache, test_id).await,
        TestType::MockExam => get_exam_results(mongoc, cache, test_id).await,
        TestType::PracticeTest => get_practice_results(mongoc, cache, test_id).await,
    }
}

pub async fn post_followup_response(
    mongoc: web::Data<Client>,
    model: web::Json<FollowupRequest>,
    session: actix_session::Session,
) -> impl Responder {
    match model.test_type {
        TestType::Exercise => post_exercise_followup_answer(mongoc, model, session).await,
        TestType::MockExam => post_exam_followup_answer(mongoc, model, session).await,
        TestType::PracticeTest => post_practice_followup_answer(mongoc, model, session).await,
    }
}

pub async fn post_answer_recommendations(
    mongoc: web::Data<Client>,
    model: web::Json<FollowupRequest>,
    session: actix_session::Session,
) -> impl Responder {
    let user_auth = UserAuth::from(session);
    let model = model.clone();

    let messages = vec![
        Message {
            role: "system".to_string(),
            content: vec![Content {
                content_type: ContentType::Text,
                text: Some(format!(
                    "You are an expert in computer science, engineering, and architecture. \
                    A student answering a practie test from the course: `{}`. \
                    Use the additional context (including result, choices, and key concepts): {} \
                    Be succinct, use active voice, and provide actionable feedback. \
                    Show, don't tell: provide relevant code examples. \
                    Use bullet points. \
                    Use the `description` field for the 100-150 word explanation in well-formatted html inside a div with headers and lists (only HTML without backticks). \
                    Use the `summary` field for a 50-75 word summary of the response. Do not include result in summary. I will use it in my HTML meta description. \
                    Use the `title` field for a suitable title for this interaction in 5-10 words. \
                    Describe with code samples, analogies, and practical examples \
                    Provide tips and tricks on how to solve similar problems. \
                    Add a bonus point relevant to the problem context. \
                    Point the user to the units and topics that they need to review in this app.",
                    model.course_name, model.context,
                )),
                image_url: None,
            }],
        },
        Message {
            role: "user".to_string(),
            content: vec![Content {
                content_type: ContentType::Text,
                text: Some(format!(
                    "Can you please analyze the question, choices, and user response and generate 50-80 words feedback? \
                    Generate constructive feedback given the context and the following question: {}. \
                    Please note, my answer was: {}",
                    model.question,
                    if model.is_correct {
                        "correct"
                    } else {
                        "incorrect. I need specific pointers and tutorial to improve."
                    }
                )),
                image_url: None,
            }],
        },
    ];

    let response_format = ResponseFormat {
        format_type: ResponseFormatType::JsonSchema,
        json_schema: Some(serde_json::json!({
          "name": "RecommendationInteraction",
            "schema": {
                "type": "object",
                "properties": {
                    "title": {
                        "type": "string",
                        "description": "Identify a suitable title for this interaction in 5-10 words."
                    },
                    "summary": {
                        "type": "string",
                        "description": "Summarize the response. State its intent and purpose. Explain what is it about and how can it help its learner in plain text format."
                    },
                    "description": {
                        "type": "string",
                        "description": "Describe the question response using well-formatted HTML inside a div with headings and bullet points."
                    }
                },
                "required": ["title", "description", "summary"]
            }
        })),
    };

    match post_chat_completion(messages, Some(response_format), Some(user_auth.google_model.clone().unwrap().id)).await {
        Some(r) => {
            let response = serde_json::from_str::<RecommendationInteraction>(r.as_str()).unwrap();
            let result = response.clone().description;
            let chat = ChatEntity {
                user_id: user_auth.google_model.unwrap().id,
                source: "answer-recommendations".to_string(),
                course_name: Some(model.course_name.clone()),
                unit_name: model.unit_name.clone(),
                topic_name: model.topic_name.clone(),
                question: model.question.clone(),
                context: Some(model.context.clone()),
                title: Some(response.title),
                summary: Some(response.summary),
                response: response.description,
                ..Default::default()
            };
            match chat.create(&mongoc).await {
                Some(id) => debug!("Chat saved with id: {}", id),
                None => {
                    log::error!("Failed to save chat");
                    return HttpResponse::InternalServerError().json(json!({"message": "Failed to save chat"}));
                }
            }
            HttpResponse::Ok().json(result)
        }
        None => {
            log::error!("Failed to post chat completion");
            HttpResponse::InternalServerError().json(json!({"message": "Failed to post chat completion"}))
        }
    }
}

pub fn get_grouped_questions(
    questions: Vec<QuestionEntity>,
    count: usize,
) -> Vec<QuestionEntity> {
    let mut rng = rand::thread_rng();
    let mut grouped_questions: HashMap<String, Vec<QuestionEntity>> = HashMap::new();
    let mut single_questions = Vec::new();

    // Filter questions with target Exam and categorize them by group_id or as single questions
    for question in questions.into_iter() {
        if question.target == Some(QuestionTarget::Exam) {
            if let Some(group_id) = &question.group_id {
                grouped_questions.entry(group_id.clone()).or_default().push(question);
            } else {
                single_questions.push(question);
            }
        }
    }

    // Collect all group ids and their representative questions
    let mut group_ids: Vec<String> = grouped_questions.keys().cloned().collect();
    group_ids.shuffle(&mut rng);
    let mut candidates: Vec<QuestionEntity> = single_questions;

    // Include the first question (based on order) from each group into candidates
    for group_id in &group_ids {
        if let Some(group) = grouped_questions.get(group_id) {
            if let Some(first_question) = group.iter().min_by_key(|q| q.order) {
                candidates.push(first_question.clone());
            }
        }
    }

    // Shuffle the candidates and pick the desired number of questions
    candidates.shuffle(&mut rng);
    let mut selected_questions = Vec::new();
    let mut seen_group_ids = HashSet::new();

    for candidate in candidates {
        if selected_questions.len() >= count {
            break;
        }

        if let Some(group_id) = &candidate.group_id {
            if !seen_group_ids.contains(group_id) {
                // Add all questions from the group, sorted by the 'order' field
                if let Some(mut group) = grouped_questions.get(group_id).cloned() {
                    group.sort_by_key(|q| q.order);
                    selected_questions.extend(group);
                }
                seen_group_ids.insert(group_id.clone());
            }
        } else {
            // Add single question
            selected_questions.push(candidate);
        }
    }

    debug!("Selected questions: {:?}", selected_questions.len());
    selected_questions
}

pub fn get_standalone_questions(
    questions: Vec<QuestionEntity>,
    count: usize,
) -> Vec<QuestionEntity> {
    let mut rng = rand::thread_rng();

    // Filter questions with target Exam
    let exam_questions: Vec<_> = questions
        .into_iter()
        .filter(|q| {
            let q = q.clone();
            if q.kind.is_none() {
                return false;
            }
            if q.target.is_none() {
                return false;
            }
            q.clone().target.unwrap() == QuestionTarget::Exam && (q.clone().kind.unwrap() == QuestionKind::Standalone || q.clone().kind.unwrap() == QuestionKind::NotSet)
        })
        .collect();

    // Shuffle the filtered questions
    let mut shuffled_questions = exam_questions.clone();
    shuffled_questions.shuffle(&mut rng);

    shuffled_questions.truncate(count);
    shuffled_questions
}

#[cfg(test)]
#[test]
fn test_grouped_questions_in_order() {
    // Create grouped questions
    let group_id = "group1".to_string();
    let questions = vec![
        QuestionEntity {
            question: "Question 1".to_string(),
            group_id: Some(group_id.clone()),
            target: Some(QuestionTarget::Exam),
            order: Some(2),
            ..Default::default()
        },
        QuestionEntity {
            question: "Question 2".to_string(),
            group_id: Some(group_id.clone()),
            target: Some(QuestionTarget::Exam),
            order: Some(1),
            ..Default::default()
        },
        QuestionEntity {
            question: "Question 3".to_string(),
            group_id: Some(group_id.clone()),
            target: Some(QuestionTarget::Exam),
            order: Some(3),
            ..Default::default()
        },
    ];

    let selected_questions = get_grouped_questions(questions, 10);

    // Assert that the questions are returned in order
    assert_eq!(selected_questions.len(), 3);
    assert_eq!(selected_questions[0].order, Some(1));
    assert_eq!(selected_questions[1].order, Some(2));
    assert_eq!(selected_questions[2].order, Some(3));
}

#[test]
fn test_single_questions_included() {
    // Create single questions and grouped questions
    let group_id = "group1".to_string();
    let questions = vec![
        // Grouped questions
        QuestionEntity {
            question: "Group Question 1".to_string(),
            group_id: Some(group_id.clone()),
            target: Some(QuestionTarget::Exam),
            order: Some(1),
            ..Default::default()
        },
        // Single question
        QuestionEntity {
            question: "Single Question 1".to_string(),
            group_id: None,
            target: Some(QuestionTarget::Exam),
            order: None,
            ..Default::default()
        },
    ];

    let selected_questions = get_grouped_questions(questions, 10);

    // Assert that both grouped and single questions are included
    assert_eq!(selected_questions.len(), 2);
    assert!(selected_questions.iter().any(|q| q.question == "Single Question 1"));
    assert!(selected_questions.iter().any(|q| q.question == "Group Question 1"));
}

#[test]
fn test_limit_number_of_questions() {
    let group_id1 = "group1".to_string();
    let group_id2 = "group2".to_string();
    let questions = vec![
        // Group 1
        QuestionEntity {
            question: "G1 Q1".to_string(),
            group_id: Some(group_id1.clone()),
            target: Some(QuestionTarget::Exam),
            order: Some(1),
            ..Default::default()
        },
        QuestionEntity {
            question: "G1 Q2".to_string(),
            group_id: Some(group_id1.clone()),
            target: Some(QuestionTarget::Exam),
            order: Some(2),
            ..Default::default()
        },
        // Group 2
        QuestionEntity {
            question: "G2 Q1".to_string(),
            group_id: Some(group_id2.clone()),
            target: Some(QuestionTarget::Exam),
            order: Some(1),
            ..Default::default()
        },
        QuestionEntity {
            question: "G2 Q2".to_string(),
            group_id: Some(group_id2.clone()),
            target: Some(QuestionTarget::Exam),
            order: Some(2),
            ..Default::default()
        },
        // Single questions
        QuestionEntity {
            question: "Single Q1".to_string(),
            group_id: None,
            target: Some(QuestionTarget::Exam),
            order: Some(0),
            ..Default::default()
        },
        QuestionEntity {
            question: "Single Q2".to_string(),
            group_id: None,
            target: Some(QuestionTarget::Exam),
            order: Some(0),
            ..Default::default()
        },
    ];

    // Request only 3 questions
    let selected_questions = get_grouped_questions(questions, 3);

    // Assert that only 3 questions are returned
    assert!(selected_questions.len() >= 3);
}

#[test]
fn test_empty_input() {
    let questions = vec![];

    let selected_questions = get_grouped_questions(questions, 10);

    // Assert that no questions are returned
    assert_eq!(selected_questions.len(), 0);
}

#[test]
fn test_only_exam_target_selected() {
    let group_id = "group1".to_string();
    let questions = vec![
        QuestionEntity {
            question: "Exam Question".to_string(),
            group_id: Some(group_id.clone()),
            target: Some(QuestionTarget::Exam),
            order: Some(1),
            ..Default::default()
        },
        QuestionEntity {
            question: "Exercise Question".to_string(),
            group_id: Some(group_id.clone()),
            target: Some(QuestionTarget::Exercise),
            order: Some(2),
            ..Default::default()
        },
        QuestionEntity {
            question: "Single Exam Question".to_string(),
            group_id: None,
            target: Some(QuestionTarget::Exam),
            order: Some(0),
            ..Default::default()
        },
        QuestionEntity {
            question: "Single Exercise Question".to_string(),
            group_id: None,
            target: Some(QuestionTarget::Exercise),
            order: Some(0),
            ..Default::default()
        },
    ];

    let selected_questions = get_grouped_questions(questions, 10);

    // Assert that only Exam target questions are selected
    assert_eq!(selected_questions.len(), 2);
    assert!(selected_questions.iter().all(|q| q.target == Some(QuestionTarget::Exam)));
}

#[test]
fn test_groups_are_shuffled() {
    use std::collections::HashSet;

    let group_ids = ["group1".to_string(), "group2".to_string(), "group3".to_string()];
    let mut questions = Vec::new();

    for (i, group_id) in group_ids.iter().enumerate() {
        questions.push(QuestionEntity {
            question: format!("Question {}", i),
            group_id: Some(group_id.clone()),
            target: Some(QuestionTarget::Exam),
            order: Some(1),
            ..Default::default()
        });
    }

    // Run the selection multiple times to see if groups are shuffled
    let mut selected_group_orders = Vec::new();

    for _ in 0..10 {
        let selected_questions = get_grouped_questions(questions.clone(), 10);
        let selected_group_ids: Vec<String> = selected_questions.iter().filter_map(|q| q.group_id.clone()).collect();

        selected_group_orders.push(selected_group_ids);
    }

    // Check that the order of groups varies
    let unique_orders: HashSet<Vec<String>> = selected_group_orders.into_iter().collect();
    assert!(unique_orders.len() > 1);
}

#[test]
fn test_questions_within_group_in_order() {
    let group_id1 = "group1".to_string();
    let group_id2 = "group2".to_string();
    let questions = vec![
        // Group 1
        QuestionEntity {
            question: "G1 Q2".to_string(),
            group_id: Some(group_id1.clone()),
            target: Some(QuestionTarget::Exam),
            order: Some(2),
            ..Default::default()
        },
        QuestionEntity {
            question: "G1 Q1".to_string(),
            group_id: Some(group_id1.clone()),
            target: Some(QuestionTarget::Exam),
            order: Some(1),
            ..Default::default()
        },
        // Group 2
        QuestionEntity {
            question: "G2 Q1".to_string(),
            group_id: Some(group_id2.clone()),
            target: Some(QuestionTarget::Exam),
            order: Some(1),
            ..Default::default()
        },
        QuestionEntity {
            question: "G2 Q2".to_string(),
            group_id: Some(group_id2.clone()),
            target: Some(QuestionTarget::Exam),
            order: Some(2),
            ..Default::default()
        },
    ];

    let selected_questions = get_grouped_questions(questions, 10);

    // Separate questions by group
    let mut group1_questions = Vec::new();
    let mut group2_questions = Vec::new();

    for question in selected_questions {
        if question.group_id == Some(group_id1.clone()) {
            group1_questions.push(question);
        } else if question.group_id == Some(group_id2.clone()) {
            group2_questions.push(question);
        }
    }

    // Assert that questions within each group are in order
    assert!(group1_questions.len() == 2);
    assert_eq!(group1_questions[0].order, Some(1));
    assert_eq!(group1_questions[1].order, Some(2));

    assert!(group2_questions.len() == 2);
    assert_eq!(group2_questions[0].order, Some(1));
    assert_eq!(group2_questions[1].order, Some(2));
}

#[derive(Serialize, Deserialize, Debug, Clone)]
struct TopicResponse {
    id: String,
    name: String,
    slug: String,
    description: String,
}

#[derive(Serialize, Deserialize, Debug, Clone)]
struct UnitResponse {
    id: String,
    name: String,
    slug: String,
    description: String,
    topics: Vec<TopicResponse>,
}
#[derive(Serialize, Deserialize, Debug, Clone)]
pub struct CourseResponse {
    id: String,
    name: String,
    slug: String,
    description: String,
    units: Vec<UnitResponse>,
}

pub fn prepare_course_response_links(
    units: &[UnitEntity],
    topics: &[TopicEntity],
    course: &CourseEntity,
) -> Option<CourseResponse> {
    let mut units_response = vec![];

    units.iter().for_each(|unit| {
        if unit.course_id == course._id.to_hex() {
            let mut topics_response = vec![];
            topics.iter().for_each(|topic| {
                if topic.unit_id == unit._id.to_hex() {
                    topics_response.push(TopicResponse {
                        id: topic._id.to_hex(),
                        name: topic.name.clone(),
                        slug: topic.slug.clone(),
                        description: topic.meta_description.clone(),
                    });
                }
            });
            units_response.push(UnitResponse {
                id: unit._id.to_hex(),
                name: unit.name.clone(),
                slug: unit.slug.clone(),
                description: unit.description.clone(),
                topics: topics_response,
            });
        }
    });

    Some(CourseResponse {
        id: course._id.to_hex(),
        name: course.name.clone(),
        slug: course.slug.clone(),
        description: course.summary.clone(),
        units: units_response,
    })
}
