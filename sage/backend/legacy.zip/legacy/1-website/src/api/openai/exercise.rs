use aarya_entities::{
    course::course_entity::CourseEntity,
    exercise::exercise_entity::{ExerciseEntity, ExerciseRequestModel, ExerciseResponseModel},
    key_value::KeyValue,
    openai::{
        completion_request::{Content, ContentType, Message, ResponseFormat, ResponseFormatType},
        user_info::UserType,
    },
    question::question_entity::QuestionEntity,
    AnswerRequest, AnswerRequestModel, QuestionResponseModel,
};
use aarya_utils::{cache_ops, markdown_ops};
use actix_web::{web, HttpResponse, Responder};
use log::{debug, error};
use mongodb::{bson::oid::ObjectId, Client};
use rand::seq::SliceRandom;
use serde_json::json;

use crate::{api::openai::post_chat_completion, auth::user::UserAuth};

use super::FollowupRequest;

pub async fn post_exercise_questions(
    mongoc: web::Data<Client>,
    model: web::Json<ExerciseRequestModel>,
    session: actix_session::Session,
    cache: web::Data<cache_ops::Cache>,
) -> impl Responder {
    // let model = model.clone();
    let questions = match QuestionEntity::scan(&mongoc, &cache).await {
        Some(q) => q,
        None => {
            error!("Failed to get questions");
            return HttpResponse::NotFound().json(json!({"message": "No questions found"}));
        }
    };

    let random_questions = get_random_questions(questions, model.clone());

    let mut return_questions: Vec<QuestionResponseModel> = Vec::new();

    random_questions.clone().iter().for_each(|question| {
        let question = QuestionResponseModel {
            id: question._id.to_hex(),
            question: markdown_ops::to_html(&question.question),
            choices: question
                .choices
                .iter()
                .map(|c| KeyValue {
                    key: c.key.clone(),
                    value: markdown_ops::to_html(&c.value),
                })
                .collect(),
            question_type: question.question_type.clone(),
            difficulty: question.question_difficulty.clone(),
        };

        return_questions.push(question);
    });

    let user_auth = UserAuth::from(session);
    let model = model.clone();
    let exercise = ExerciseEntity {
        questions: random_questions.clone(),
        user_id: user_auth.user_key.unwrap(),
        course_id: model.course_id,
        unit_id: model.unit_id,
        topic_id: model.topic_id,
        ..Default::default()
    };

    match exercise.create(&mongoc).await {
        Some(_) => debug!("Exercise created"),
        None => {
            error!("Failed to create exercise");
            return HttpResponse::InternalServerError().json(json!({"message": "Failed to create exercise"}));
        }
    }

    HttpResponse::Ok().json(ExerciseResponseModel {
        exercise_id: exercise._id.to_hex(),
        questions: return_questions,
    })
}

pub async fn post_exercise_answers(
    mongoc: web::Data<Client>,
    model: web::Json<AnswerRequestModel>,
) -> impl Responder {
    let model = model.clone();
    let exercise = ExerciseEntity {
        _id: match ObjectId::parse_str(model.test_id.clone()) {
            Ok(id) => id,
            Err(e) => {
                error!("Failed to parse exercise id: {}", e);
                return HttpResponse::BadRequest().json(json!({"message": "Failed to parse exercise id"}));
            }
        },
        ..Default::default()
    };
    let mut exercise = match exercise.find(&mongoc).await {
        Some(e) => e,
        None => {
            error!("Failed to get exercise");
            return HttpResponse::NotFound().json(json!({"message": "Exercise not found"}));
        }
    };
    exercise.user_answers = Some(AnswerRequestModel {
        test_id: model.test_id.clone(),
        answers: model.answers.clone(),
    });
    match exercise.update(&mongoc).await {
        Some(_) => debug!("Exercise updated"),
        None => {
            error!("Failed to update exercise");
            return HttpResponse::InternalServerError().json(json!({"message": "Failed to update exercise"}));
        }
    }

    HttpResponse::Ok().json(json!({"message": "Answers submitted"}))
}

pub async fn get_exercise_results(
    mongoc: web::Data<Client>,
    cache: web::Data<cache_ops::Cache>,
    test_id: String,
) -> HttpResponse {
    let exercise = ExerciseEntity {
        _id: ObjectId::parse_str(test_id.clone()).unwrap(),
        ..Default::default()
    };
    let exercise = exercise.find(&mongoc).await.unwrap();

    // scoring
    // from the exercise extract all the questions with id and correct answers
    let mut user_answers: Vec<AnswerRequest> = Vec::new();
    let mut correct_answers: Vec<AnswerRequest> = Vec::new();
    exercise.user_answers.as_ref().unwrap().answers.iter().for_each(|a| {
        let user_answer = a.clone();
        let question = exercise.questions.iter().find(|q| q._id.to_hex() == user_answer.question_id).unwrap();
        let correct_answer = AnswerRequest {
            question_id: user_answer.question_id.clone(),
            answers: question.answers.clone(),
        };
        user_answers.push(user_answer);
        correct_answers.push(correct_answer);
    });

    let course_slug = match CourseEntity::scan(&mongoc, &cache).await {
        Some(c) => match c.into_iter().find(|c| c._id.to_hex() == exercise.course_id) {
            Some(c) => c.slug.clone(),
            None => {
                error!("Failed to get course");
                return HttpResponse::NotFound().json(json!({"message": "No course found"}));
            }
        },
        None => {
            error!("Failed to get course");
            return HttpResponse::NotFound().json(json!({"message": "No course found"}));
        }
    };

    HttpResponse::Ok().json(json!(exercise
        .questions
        .iter()
        .map(|q| {
            let user_answer = user_answers.iter().find(|a| a.question_id == q._id.to_hex()).unwrap();
            let correct_answer = correct_answers.iter().find(|a| a.question_id == q._id.to_hex()).unwrap();
            let correct_count = correct_answer.answers.iter().filter(|c| user_answer.answers.contains(c)).count();
            let score_per_question = correct_count as f32 / correct_answer.answers.len() as f32;
            let correct = score_per_question == 1.0;
            let key_concept = q.key_concept.clone();
            let question_difficulty = q.question_difficulty.clone();
            let answer_explanation = q.answer_explanation.clone();
            json!({
                "question": markdown_ops::to_html(&q.question),
                "choices": q.choices.iter().map(|c| KeyValue {
                                key: c.key.clone(),
                                value: markdown_ops::to_html(&c.value),
                            }).collect::<Vec<KeyValue>>(),
                "user_answers": user_answer.answers,
                "correct_answers": correct_answer.answers,
                "score": score_per_question,
                "key_concept": key_concept,
                "question_difficulty": question_difficulty,
                "answer_explanation": markdown_ops::to_html(&answer_explanation),
                "correct": correct,
                "exercise_id": test_id.clone(),
                "question_id": q._id.to_hex(),
                "course_slug": course_slug.clone(),
            })
        })
        .collect::<Vec<serde_json::Value>>()))
}

pub async fn post_exercise_followup(
    model: web::Json<FollowupRequest>,
    session: actix_session::Session,
) -> impl Responder {
    let user_auth = UserAuth::from(session);
    let model = model.clone();

    let messages = vec![
        Message {
            role: "system".to_string(),
            content: vec![Content {
                content_type: ContentType::Text,
                text: Some(format!(
                    "You are an experienced {} teacher. \
                    A {} is doing an exercise in unit: {} and topic: {}. \
                    Depending on the Result (true or false: correct or incorrect) below, please generate 4-5, 7-15 words follow-up questions. \
                    If the answer is incorrect, include a question why the answer is incorrect. \
                    The following are more details about the question (including result, choices, and key concepts): \
                    {} \
                    The questions should be about probing the correct/incorrect answer, key concepts, generating code samples,  \
                    using analogies, explaining in a different voice, practical examples, etc. \
                    Do not include questions unrelated to the given course, unit, and topic. \
                    Answer in a json format using the included schema",
                    model.course_name,
                    UserType::to_str(&model.user_type),
                    model.unit_name.unwrap_or_default(),
                    model.topic_name.unwrap_or_default(),
                    model.context,
                )),
                image_url: None,
            }],
        },
        Message {
            role: "user".to_string(),
            content: vec![Content {
                content_type: ContentType::Text,
                text: Some(format!(
                    "Generate relevant questions given the context and the following question: {}. Please note, my answer was: {}",
                    model.question,
                    if model.is_correct { "correct" } else { "incorrect. I need to know why?" }
                )),
                image_url: None,
            }],
        },
    ];
    debug!("Sending messages: {:?}", messages);
    let response_format = ResponseFormat {
        format_type: ResponseFormatType::JsonSchema,
        json_schema: Some(serde_json::json!({
          "name": "FollowupQuestions",
          "schema": {
            "type": "object",
            "properties": {
              "followups": {
                "type": "array",
                "items": {
                  "type": "string",
                  "description": "This text will be used as an HTML button text"
                }
              }
            },
            "required": ["followups"]
          }
        })),
    };

    match post_chat_completion(messages, Some(response_format), Some(user_auth.google_model.unwrap().id)).await {
        Some(r) => HttpResponse::Ok().json(r),
        None => {
            error!("Failed to post chat completion");
            HttpResponse::InternalServerError().json(json!({"message": "Failed to post chat completion"}))
        }
    }
}

pub async fn post_exercise_followup_answer(
    _mongoc: web::Data<Client>,
    _model: web::Json<FollowupRequest>,
    _session: actix_session::Session,
) -> HttpResponse {
    // let model = model.into_inner();
    // let user_auth = UserAuth::from(session);
    // let messages = vec![
    //     Message {
    //         role: "system".to_string(),
    //         content: vec![Content {
    //             content_type: ContentType::Text,
    //             text: Some(format!(
    //                 "You are an experienced {} teacher. \
    //                 A {} is doing an exercise in course: {}. \
    //                 The student has asked a followup question: {} \
    //                 Answer the question in a way that a {} can understand. \
    //                 Also, include 2-3 followup questions that the student may have. \
    //                 The questions should be about probing the key concepts, generating code samples,  \
    //                 using analogies, explaining in a different voice, practical examples, etc. \
    //                 Do not include questions unrelated to the given course, unit, and topic.\
    //                 Answer in a json format using the included schema",
    //                 model.course_name,
    //                 UserType::to_str(&model.user_type),
    //                 model.course_name,
    //                 model.question,
    //                 UserType::to_str(&model.user_type)
    //             )),
    //             image_url: None,
    //         }],
    //     },
    //     Message {
    //         role: "user".to_string(),
    //         content: vec![Content {
    //             content_type: ContentType::Text,
    //             text: Some(format!(
    //                 "I need to understand the following: {}\n \
    //                 Use additional details of the question for context: {}",
    //                 model.question, model.context
    //             )),
    //             image_url: None,
    //         }],
    //     },
    // ];
    // debug!("Sending messages: {:?}", messages);
    // let response_format = ResponseFormat {
    //     format_type: ResponseFormatType::JsonSchema,
    //     json_schema: Some(serde_json::json!({
    //       "name": "FollowupQuestions",
    //         "schema": {
    //             "type": "object",
    //             "properties": {
    //                 "description": {
    //                     "type": "string",
    //                     "description": "A brief description of the topic in HTML format and will go inside a div"
    //                 },
    //                 "followups": {
    //                     "type": "array",
    //                     "items": {
    //                         "type": "string",
    //                         "description": "This text will be used as an HTML button text"
    //                     }
    //                 }
    //             },
    //             "required": ["description", "followups"]
    //         }
    //     })),
    // };

    // // let entity = ExerciseEntity {
    // //     _id: ObjectId::parse_str(model.test_id.clone()).unwrap(),
    // //     ..Default::default()
    // // };

    // // let entity = match entity.find(&mongoc).await {
    // //     Some(e) => e,
    // //     None => {
    // //         error!("Failed to get exercise");
    // //         return HttpResponse::NotFound().json(json!({"message": "Exercise not found"}));
    // //     }
    // // };

    // // let mut followups = if entity.followups.is_none() { vec![] } else { entity.clone().followups.unwrap() };
    // // followups.push(model.question.clone());
    // // match entity.update(&mongoc).await {
    // //     Some(_) => debug!("Exercise updated"),
    // //     None => {
    // //         error!("Failed to update exercise");
    // //         return HttpResponse::InternalServerError().json(json!({"message": "Failed to update exercise"}));
    // //     }
    // // }

    // post_chat_completion(messages, Some(response_format), Some(user_auth.google_model.unwrap().id)).await

    HttpResponse::Ok().json(json!({"message": "Followup questions sent"}))
}

pub fn get_random_questions(
    questions: Vec<QuestionEntity>,
    model: ExerciseRequestModel,
) -> Vec<QuestionEntity> {
    let mut rng = rand::thread_rng();

    // Filter questions with target Exam
    let exam_questions: Vec<_> = questions
        .into_iter()
        .filter(|q| {
            let q = q.clone();
            q.topic_id.is_some() && model.course_id == q.course_id && model.unit_id == q.unit_id && model.topic_id == q.topic_id.unwrap()
        })
        .collect();

    // Shuffle the filtered questions
    let mut shuffled_questions = exam_questions.clone();
    shuffled_questions.shuffle(&mut rng);

    shuffled_questions.truncate(model.question_count);
    shuffled_questions
}
