use std::collections::HashMap;

use aarya_entities::practice::result_entity::ResultEntity;
use actix_web::{web, HttpResponse, Responder};
use log::debug;
use mongodb::Client as MongoClient;

use crate::auth::user::UserAuth;

pub async fn get_results_by_user(
    mongoc: web::Data<MongoClient>,
    session: actix_session::Session,
) -> impl Responder {
    let user_id = UserAuth::from(session).google_model.unwrap().id;
    let result_entity = ResultEntity {
        user_id: user_id.clone(),
        ..ResultEntity::default()
    };
    let mut grouped: HashMap<String, Vec<ResultEntity>> = HashMap::new();
    let results = match result_entity.filter(&mongoc, "user_id", &user_id).await {
        Some(results) => results,
        None => {
            debug!("No results found for user: {}", user_id);
            return HttpResponse::NotFound().finish();
        }
    };

    for result in results {
        grouped.entry(result.exercise_id.clone()).or_default().push(result);
    }

    HttpResponse::Ok().json(grouped)
}
