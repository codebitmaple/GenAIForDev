use aarya_entities::{
    course::course_entity::CourseEntity,
    topic::topic_entity::{TopicEntity, TopicResponseModel},
    unit::unit_entity::UnitEntity,
};
use aarya_utils::cache_ops;
use actix_web::{web, HttpResponse, Responder};
use mongodb::Client as MongoClient;
use serde::{Deserialize, Serialize};

use crate::services::admin::course::CourseResponseModel;

use super::prepare_course_response_links;

#[derive(Debug, Serialize, Deserialize, Clone)]
struct CourseUnitResponseModel {
    course: CourseResponseModel,
    units: Vec<UnitTopicsResponseModel>,
    links: super::CourseResponse,
}

#[derive(Debug, Serialize, Deserialize, Clone)]
pub struct UnitTopicsResponseModel {
    pub id: String,
    pub name: String,
    pub description: String,
    pub topics: Option<Vec<TopicResponseModel>>,
    pub slug: Option<String>,
}

impl From<UnitEntity> for UnitTopicsResponseModel {
    fn from(unit: UnitEntity) -> Self {
        UnitTopicsResponseModel {
            id: unit._id.to_hex(),
            name: unit.name,
            description: unit.description,
            topics: None,
            slug: Some(unit.slug),
        }
    }
}

impl UnitTopicsResponseModel {
    pub fn with_topics(
        mut self,
        topics: Vec<TopicResponseModel>,
    ) -> Self {
        self.topics = Some(topics);
        self
    }

    pub fn from_units(units: Vec<UnitEntity>) -> Vec<UnitTopicsResponseModel> {
        units.into_iter().map(UnitTopicsResponseModel::from).collect()
    }
}

/// Get Units and their topics for a course
pub async fn get_units(
    mongoc: web::Data<MongoClient>,
    path: web::Path<String>,
    cache: web::Data<cache_ops::Cache>,
) -> impl Responder {
    let course_slug = path.into_inner();

    let course = match CourseEntity::scan(&mongoc, &cache).await {
        Some(c) => c.into_iter().find(|c| c.slug == course_slug).unwrap(),
        None => return HttpResponse::NotFound().body("Error finding courses"),
    };

    let unit_entities = match UnitEntity::find_by_course(&mongoc, &cache, &course._id.to_hex()).await {
        Some(u) => u,
        None => return HttpResponse::NotFound().body("Error finding units"),
    };

    let mut units = UnitTopicsResponseModel::from_units(unit_entities.clone());

    for u in &mut units {
        let topics = (TopicEntity::find_by_unit(&mongoc, &cache, &u.id).await).unwrap_or_default();
        u.topics = Some(TopicResponseModel::from_topics(topics));
    }

    let topics: Vec<TopicEntity> = vec![];

    let result = CourseUnitResponseModel {
        course: CourseResponseModel::from(course.clone()),
        units,
        links: prepare_course_response_links(unit_entities.as_slice(), topics.as_slice(), &course).unwrap(),
    };

    HttpResponse::Ok().json(result)
}
