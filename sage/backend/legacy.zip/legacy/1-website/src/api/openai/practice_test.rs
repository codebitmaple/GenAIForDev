use aarya_entities::{
    course::course_entity::CourseEntity,
    key_value::KeyValue,
    openai::{
        chat::ChatEntity,
        completion_request::{Content, ContentType, Message, ResponseFormat, ResponseFormatType},
    },
    practice::{
        practice_entity::{PracticeEntity, PracticeRequestModel, PracticeResponseModel},
        result_entity::ResultEntity,
    },
    question::question_entity::QuestionEntity,
    AnswerRequest, AnswerRequestModel, QuestionResponseModel,
};
use aarya_utils::{cache_ops, markdown_ops};
use actix_web::{web, HttpResponse, Responder};
use log::{debug, error};
use mongodb::{bson::oid::ObjectId, Client};
use serde_json::json;

use crate::{
    api::openai::{post_chat_completion, TopicInteraction},
    auth::user::UserAuth,
};

use super::{get_standalone_questions, FollowupRequest};

pub async fn post_practice_questions(
    mongoc: web::Data<Client>,
    model: web::Json<PracticeRequestModel>,
    session: actix_session::Session,
    cache: web::Data<cache_ops::Cache>,
) -> impl Responder {
    let model = model.clone();
    let questions = match QuestionEntity::scan(&mongoc, &cache).await {
        Some(q) => q,
        None => {
            error!("Failed to get questions");
            return HttpResponse::NotFound().json(json!({"message": "No questions found"}));
        }
    };

    let course = match CourseEntity::scan(&mongoc, &cache).await {
        Some(c) => c.into_iter().find(|c| c.slug == model.course_slug).unwrap(),
        None => {
            error!("Failed to get course");
            return HttpResponse::NotFound().json(json!({"message": "No course found"}));
        }
    };

    let questions = questions.iter().filter(|q| q.course_id == course._id.to_hex()).cloned().collect::<Vec<QuestionEntity>>();

    let random_questions = get_standalone_questions(questions.clone(), model.question_count);

    let mut return_questions: Vec<QuestionResponseModel> = Vec::new();

    random_questions.clone().iter().for_each(|question| {
        let question = QuestionResponseModel {
            id: question._id.to_hex(),
            question: markdown_ops::to_html(&question.question),
            choices: question
                .choices
                .iter()
                .map(|c| KeyValue {
                    key: c.key.clone(),
                    value: markdown_ops::to_html(&c.value),
                })
                .collect(),
            question_type: question.question_type.clone(),
            difficulty: question.question_difficulty.clone(),
        };

        return_questions.push(question);
    });

    let user_auth = UserAuth::from(session);
    let practice = PracticeEntity {
        questions: random_questions.clone(),
        user_id: user_auth.user_key.unwrap(),
        course_id: course._id.to_hex(),
        ..Default::default()
    };

    match practice.create(&mongoc).await {
        Some(_) => debug!("practice test created"),
        None => {
            error!("Failed to create practice test");
            return HttpResponse::InternalServerError().json(json!({"message": "Failed to create practice test"}));
        }
    }

    HttpResponse::Ok().json(PracticeResponseModel {
        practice_id: practice._id.to_hex(),
        questions: return_questions,
        course_slug: course.slug,
        course_id: course._id.to_hex(),
        course_name: course.name,
    })
}

pub async fn post_practice_answers(
    mongoc: web::Data<Client>,
    model: web::Json<AnswerRequestModel>,
) -> impl Responder {
    let model = model.clone();
    let practice = PracticeEntity {
        _id: match ObjectId::parse_str(model.test_id.clone()) {
            Ok(id) => id,
            Err(e) => {
                error!("Failed to parse practice test id: {}", e);
                return HttpResponse::BadRequest().json(json!({"message": "Failed to parse practice test id"}));
            }
        },
        ..Default::default()
    };
    let mut practice = match practice.find(&mongoc).await {
        Some(e) => e,
        None => {
            error!("Failed to get practice test");
            return HttpResponse::NotFound().json(json!({"message": "practice test not found"}));
        }
    };
    practice.user_answers = Some(AnswerRequestModel {
        test_id: model.test_id.clone(),
        answers: model.answers.clone(),
    });
    match practice.update(&mongoc).await {
        Some(_) => debug!("model.course_name, updated"),
        None => {
            error!("Failed to update practice test");
            return HttpResponse::InternalServerError().json(json!({"message": "Failed to update practice test"}));
        }
    }

    HttpResponse::Ok().json(json!({"message": "Answers submitted"}))
}

pub async fn get_practice_results(
    mongoc: web::Data<Client>,
    cache: web::Data<cache_ops::Cache>,
    test_id: String,
) -> HttpResponse {
    let exam_id = test_id.clone();

    let result_entity = ResultEntity {
        exercise_id: exam_id.clone(),
        ..Default::default()
    };

    match result_entity.filter(&mongoc, "exercise_id", &exam_id).await {
        Some(r) => return HttpResponse::Ok().json(r),
        None => {
            debug!("Creating result for exercise_id: {}.", exam_id);
        }
    };

    let practice = PracticeEntity {
        _id: ObjectId::parse_str(exam_id.clone()).unwrap(),
        ..Default::default()
    };
    let practice = practice.find(&mongoc).await.unwrap();

    // scoring
    // from the exercise extract all the questions with id and correct answers
    let mut user_answers: Vec<AnswerRequest> = Vec::new();
    let mut correct_answers: Vec<AnswerRequest> = Vec::new();
    practice.user_answers.as_ref().unwrap().answers.iter().for_each(|a| {
        let user_answer = a.clone();
        let question = practice.questions.iter().find(|q| q._id.to_hex() == user_answer.question_id).unwrap();
        let correct_answer = AnswerRequest {
            question_id: user_answer.question_id.clone(),
            answers: question.answers.clone(),
        };
        user_answers.push(user_answer);
        correct_answers.push(correct_answer);
    });

    debug!("Practice: {:?}", practice);

    let course_slug = match CourseEntity::scan(&mongoc, &cache).await {
        Some(c) => match c.into_iter().find(|c| c._id.to_hex() == practice.course_id) {
            Some(c) => c.slug.clone(),
            None => {
                error!("Failed to get course");
                return HttpResponse::NotFound().json(json!({"message": "No course found"}));
            }
        },
        None => {
            error!("Failed to get course");
            return HttpResponse::NotFound().json(json!({"message": "No course found"}));
        }
    };

    let result_entities = practice
        .questions
        .iter()
        .map(|q| {
            let user_answer = user_answers.iter().find(|a| a.question_id == q._id.to_hex()).unwrap();
            let correct_answer = correct_answers.iter().find(|a| a.question_id == q._id.to_hex()).unwrap();
            let correct_count = correct_answer.answers.iter().filter(|c| user_answer.answers.contains(c)).count();
            let score_per_question = correct_count as f64 / correct_answer.answers.len() as f64;
            let correct = score_per_question == 1.0;
            let key_concept = q.key_concept.clone();
            let question_difficulty = q.question_difficulty.clone();
            let answer_explanation = q.answer_explanation.clone();
            let question = markdown_ops::to_html(&q.question);
            let choices = q
                .choices
                .iter()
                .map(|c| KeyValue {
                    key: c.key.clone(),
                    value: markdown_ops::to_html(&c.value),
                })
                .collect::<Vec<KeyValue>>();
            let question_id = q._id.to_hex();
            ResultEntity {
                question,
                choices,
                user_answers: user_answer.answers.clone(),
                correct_answers: correct_answer.answers.clone(),
                score: score_per_question,
                key_concept: Some(key_concept),
                question_difficulty,
                answer_explanation,
                correct,
                exercise_id: exam_id.clone(),
                question_id,
                course_slug: course_slug.clone(),
                user_id: practice.user_id.clone(),
                ..Default::default()
            }
        })
        .collect::<Vec<ResultEntity>>();

    for entity in &result_entities {
        entity.create(&mongoc).await;
    }

    HttpResponse::Ok().json(result_entities)
}

pub async fn post_practice_followup(
    model: web::Json<FollowupRequest>,
    session: actix_session::Session,
) -> impl Responder {
    let user_auth = UserAuth::from(session);
    let model = model.clone();

    let messages = vec![
        Message {
            role: "system".to_string(),
            content: vec![Content {
                content_type: ContentType::Text,
                text: Some(format!(
                    "You are an expert in computer scienec, engineering, and architecture. \
                    A student is learning course: `{}`. \
                    Depending on the Result (true or false: correct or incorrect) below, please generate 4-5, 7-15 words follow-up questions. \
                    If the answer is incorrect, include a question why the answer is incorrect. \
                    Use the following context (including result, choices, and key concepts): {} \
                    The questions should be about probing the correct/incorrect answer, key concepts, generating code samples,  \
                    using analogies, elaborating further, practical examples, etc. \
                    Do not include questions unrelated to the given course, unit, and topic. \
                    Answer in a json format using the included schema",
                    model.course_name, model.context,
                )),
                image_url: None,
            }],
        },
        Message {
            role: "user".to_string(),
            content: vec![Content {
                content_type: ContentType::Text,
                text: Some(format!(
                    "Generate relevant questions given the context and the following question: {}. Please note, my answer was: {}",
                    model.question,
                    if model.is_correct { "correct" } else { "incorrect. I need to know why?" }
                )),
                image_url: None,
            }],
        },
    ];
    debug!("Sending messages: {:?}", messages);
    let response_format = ResponseFormat {
        format_type: ResponseFormatType::JsonSchema,
        json_schema: Some(serde_json::json!({
          "name": "FollowupQuestions",
          "schema": {
            "type": "object",
            "properties": {
              "followups": {
                "type": "array",
                "items": {
                  "type": "string",
                  "description": "This text will be used as an HTML button text"
                }
              }
            },
            "required": ["followups"]
          }
        })),
    };

    match post_chat_completion(messages, Some(response_format), Some(user_auth.google_model.unwrap().id)).await {
        Some(r) => HttpResponse::Ok().json(r),
        None => HttpResponse::InternalServerError().json(json!({"message": "Failed to post chat completion"})),
    }
}

pub async fn post_practice_followup_answer(
    mongoc: web::Data<Client>,
    model: web::Json<FollowupRequest>,
    session: actix_session::Session,
) -> HttpResponse {
    let model = model.into_inner();
    let user_auth = UserAuth::from(session);
    let messages = vec![
        Message {
            role: "system".to_string(),
            content: vec![Content {
                content_type: ContentType::Text,
                text: Some(format!(
                    "You are an expert in computer science and engineering. \
                    A student is taking practice tests for the course: {}. \
                    and has asked the following question: `{}` \
                    Answer the question succinctly in 50-75 words. \
                    Limit the `summary` field to 50-75 words. \
                    Show, don't tell. Use analogies, practical examples, and code samples. \
                    Use bullet points and lists. \
                    Also, include 2-3 followup questions that aids in understanding and gaining expertise in the concept. \
                    The questions should be about probing the key concepts, generating code samples,  \
                    using analogies, practical examples, etc. \
                    The response in the description field must be well-formatted html inside a div with headers and lists (only HTML without backticks). \
                    Do not include questions unrelated to the given course and context. \
                    Answer in a json format strictly adhering to the schema",
                    model.course_name, model.question,
                )),
                image_url: None,
            }],
        },
        Message {
            role: "user".to_string(),
            content: vec![Content {
                content_type: ContentType::Text,
                text: Some(format!(
                    "Explain the following to me: {}\n \
                    Use additional details of the question for context: {}",
                    model.question, model.context
                )),
                image_url: None,
            }],
        },
    ];
    debug!("Sending messages: {:?}", messages);
    let response_format = ResponseFormat {
        format_type: ResponseFormatType::JsonSchema,
        json_schema: Some(serde_json::json!({
          "name": "FollowupQuestions",
            "schema": {
                "type": "object",
                "properties": {
                    "title": {
                        "type": "string",
                        "description": "Identify a suitable title for this interaction in 5-10 words."
                    },
                    "summary": {
                        "type": "string",
                        "description": "Summarize the response. State its intent and purpose. Explain what is it about and how can it help its learner in plain text format."
                    },
                    "description": {
                        "type": "string",
                        "description": "A brief description of the topic in HTML format and will go inside a div"
                    },
                    "followups": {
                        "type": "array",
                        "items": {
                            "type": "string",
                            "description": "This text will be used as an HTML button text"
                        }
                    }
                },
                "required": ["description", "followups", "summary", "title"]
            }
        })),
    };

    match post_chat_completion(messages, Some(response_format), Some(user_auth.google_model.unwrap().id)).await {
        Some(r) => {
            let response = serde_json::from_str::<TopicInteraction>(r.as_str()).unwrap();
            let chat = ChatEntity {
                user_id: user_auth.user_key.unwrap(),
                source: "practice".to_string(),
                course_name: Some(model.course_name.clone()),
                question: model.question.clone(),
                context: Some(model.context.clone()),
                response: r.clone(),
                summary: Some(response.summary),
                title: Some(response.title),
                ..Default::default()
            };
            match chat.create(&mongoc).await {
                Some(_) => debug!("chat completion created"),
                None => {
                    error!("Failed to create chat completion");
                    return HttpResponse::InternalServerError().json(json!({"message": "Failed to create chat completion"}));
                }
            }
            HttpResponse::Ok().json(r)
        }
        None => {
            error!("Failed to post chat completion");
            HttpResponse::InternalServerError().json(json!({"message": "Failed to post chat completion"}))
        }
    }
}
