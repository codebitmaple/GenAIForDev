use aarya_entities::{
    course::course_entity::CourseEntity,
    openai::{
        completion_request::{Content, ContentType, Message, ResponseFormat, ResponseFormatType},
        course_info::DescribeCourseRequest,
        user_info::{UserLevel, UserType},
    },
};

use aarya_utils::cache_ops;
use actix_web::{web, HttpResponse, Responder};
use log::debug;
use mongodb::Client as MongoClient;

use crate::auth::user::UserAuth;

use super::post_chat_completion;

pub async fn get_courses(
    mongoc: web::Data<MongoClient>,
    cache: web::Data<cache_ops::Cache>,
) -> impl Responder {
    let courses = CourseEntity::scan(&mongoc, &cache).await;

    match courses {
        Some(c) => HttpResponse::Ok().json(c),
        None => HttpResponse::InternalServerError().body("Error finding courses"),
    }
}

pub async fn get_course_by_slug(
    mongoc: web::Data<MongoClient>,
    cache: web::Data<cache_ops::Cache>,
    path: web::Path<String>,
) -> impl Responder {
    let course_slug = path.into_inner();
    let courses = CourseEntity::scan(&mongoc, &cache).await;
    match courses {
        Some(c) => {
            let course = c.iter().find(|c| c.slug == course_slug);
            debug!("Course: {:?}", course);
            match course {
                Some(c) => HttpResponse::Ok().json(c),
                None => HttpResponse::InternalServerError().body(format!("Error finding course: {}", course_slug)),
            }
        }
        None => HttpResponse::InternalServerError().body("Error finding courses"),
    }
}

pub async fn post_describe_course(
    model: web::Json<DescribeCourseRequest>,
    session: actix_session::Session,
) -> impl Responder {
    let user_auth = UserAuth::from(session);
    let messages = vec![
            Message {
                role: "system".to_string(),
                content: vec![Content{
                    content_type: ContentType::Text,
                    text: Some(format!("You are an academic councellor. Generate concise responses in JSON format. The actual course description should be in well-formatted html inside a div using headers and lists. Include 3 follow-up questions that the user might ask. Do not include followup questions that are unrelated to {}.", model.course_name)),
                    image_url: None
                }],
            },
            Message {
                role: "user".to_string(),
                content: vec![Content{
                    content_type: ContentType::Text,
                    text: Some(format!("In 200-250 words, describe the {} course for a {} self-rated as a {}. Include syllabus and exam details including usual exam dates, scoring system, benefits and real-life applications of the course.", model.course_name, UserType::to_str(&model.user_type), UserLevel::to_str(&model.user_level))),
                    image_url: None
                }],
            }
        ];
    let response_format = ResponseFormat {
        format_type: ResponseFormatType::JsonSchema,
        json_schema: Some(serde_json::json!({
            "name": "CourseDescription",
            "schema": {
                "type": "object",
                "properties": {
                    "description": {
                        "type": "string",
                        "description": "A brief description of the course in HTML format"
                    },
                    "followups": {
                        "type": "array",
                        "items": {
                            "type": "string",
                            "description": "Follow-up questions to ask the user in text format"
                        }
                    }
                },
                "required": ["description", "followups"]
            }
        })),
    };

    post_chat_completion(messages, Some(response_format), Some(user_auth.google_model.unwrap().id)).await
}

pub async fn post_course_followup(
    model: web::Json<DescribeCourseRequest>,
    session: actix_session::Session,
) -> impl Responder {
    let user_auth = UserAuth::from(session);
    let messages = vec![
        Message {
            role: "system".to_string(),
            content: vec![Content {
                content_type: ContentType::Text,
                text: Some(format!(
                    "You are an expert in computer science, engineering, and architecture. \
                    A student is learning course: `{}` has asked a followup question. Generate concise \
                    responses in JSON format. Limit the description field to 100-150 words. \
                    Answer in a way a 9th grader can understand. The response should be \
                    well-formatted html inside a div with headers and lists. \
                    Include 3 follow-up questions that the user might ask. \
                    Do not include followup questions that are unrelated to {}.",
                    model.course_name, model.course_name
                )),
                image_url: None,
            }],
        },
        Message {
            role: "user".to_string(),
            content: vec![Content {
                content_type: ContentType::Text,
                text: Some(model.followup.clone().unwrap()),
                image_url: None,
            }],
        },
    ];
    let response_format = ResponseFormat {
        format_type: ResponseFormatType::JsonSchema,
        json_schema: Some(serde_json::json!({
            "name": "CourseDescription",
            "schema": {
                "type": "object",
                "properties": {
                    "description": {
                        "type": "string",
                        "description": "A brief description of the course in HTML format"
                    },
                    "followups": {
                        "type": "array",
                        "items": {
                            "type": "string",
                            "description": "Follow-up questions to ask the user in text format"
                        }
                    }
                },
                "required": ["description", "followups"]
            }
        })),
    };

    post_chat_completion(messages, Some(response_format), Some(user_auth.google_model.unwrap().id)).await
}
