use aarya_entities::{
    course::course_entity::CourseEntity,
    exam::exam_entity::{ExamEntity, ExamRequestModel, ExamResponseModel},
    key_value::KeyValue,
    openai::{
        completion_request::{Content, ContentType, Message, ResponseFormat, ResponseFormatType},
        user_info::UserType,
    },
    question::question_entity::QuestionEntity,
    AnswerRequest, AnswerRequestModel, QuestionResponseModel,
};
use aarya_utils::{cache_ops, markdown_ops};
use actix_web::{web, HttpResponse, Responder};
use log::{debug, error};
use mongodb::{bson::oid::ObjectId, Client};
use serde_json::json;

use crate::{api::openai::post_chat_completion, auth::user::UserAuth};

use super::{get_standalone_questions, FollowupRequest};

pub async fn post_exam_questions(
    mongoc: web::Data<Client>,
    model: web::Json<ExamRequestModel>,
    session: actix_session::Session,
    cache: web::Data<cache_ops::Cache>,
) -> impl Responder {
    let model = model.clone();
    let questions = match QuestionEntity::scan(&mongoc, &cache).await {
        Some(q) => q,
        None => {
            error!("Failed to get questions");
            return HttpResponse::NotFound().json(json!({"message": "No questions found"}));
        }
    };

    // let grouped_questions: usize = 5;
    // let single_questions: usize = model.question_count - grouped_questions;

    // let mut random_questions = get_grouped_questions(questions.clone(), grouped_questions);
    // random_questions.extend(get_standalone_questions(questions.clone(), single_questions));

    // random_questions.truncate(model.question_count);

    let random_questions = get_standalone_questions(questions.clone(), model.question_count);

    let mut return_questions: Vec<QuestionResponseModel> = Vec::new();

    random_questions.clone().iter().for_each(|question| {
        let question = QuestionResponseModel {
            id: question._id.to_hex(),
            question: markdown_ops::to_html(&question.question),
            choices: question
                .choices
                .iter()
                .map(|c| KeyValue {
                    key: c.key.clone(),
                    value: markdown_ops::to_html(&c.value),
                })
                .collect(),
            question_type: question.question_type.clone(),
            difficulty: question.question_difficulty.clone(),
        };

        return_questions.push(question);
    });

    let user_auth = UserAuth::from(session);
    let exam = ExamEntity {
        questions: random_questions.clone(),
        user_id: user_auth.user_key.unwrap(),
        course_id: model.course_id,
        ..Default::default()
    };

    match exam.create(&mongoc).await {
        Some(_) => debug!("Exam created"),
        None => {
            error!("Failed to create exam");
            return HttpResponse::InternalServerError().json(json!({"message": "Failed to create exam"}));
        }
    }

    HttpResponse::Ok().json(ExamResponseModel {
        exam_id: exam._id.to_hex(),
        questions: return_questions,
    })
}

pub async fn post_exam_answers(
    mongoc: web::Data<Client>,
    model: web::Json<AnswerRequestModel>,
) -> impl Responder {
    let model = model.clone();
    let exam = ExamEntity {
        _id: match ObjectId::parse_str(model.test_id.clone()) {
            Ok(id) => id,
            Err(e) => {
                error!("Failed to parse exam id: {}", e);
                return HttpResponse::BadRequest().json(json!({"message": "Failed to parse exam id"}));
            }
        },
        ..Default::default()
    };
    let mut exam = match exam.find(&mongoc).await {
        Some(e) => e,
        None => {
            error!("Failed to get exam");
            return HttpResponse::NotFound().json(json!({"message": "exam not found"}));
        }
    };
    exam.user_answers = Some(AnswerRequestModel {
        test_id: model.test_id.clone(),
        answers: model.answers.clone(),
    });
    match exam.update(&mongoc).await {
        Some(_) => debug!("exam updated"),
        None => {
            error!("Failed to update exam");
            return HttpResponse::InternalServerError().json(json!({"message": "Failed to update exam"}));
        }
    }

    HttpResponse::Ok().json(json!({"message": "Answers submitted"}))
}

pub async fn get_exam_results(
    mongoc: web::Data<Client>,
    cache: web::Data<cache_ops::Cache>,
    test_id: String,
) -> HttpResponse {
    let exam_id = test_id.clone();
    let exam = ExamEntity {
        _id: ObjectId::parse_str(exam_id.clone()).unwrap(),
        ..Default::default()
    };
    let exam = exam.find(&mongoc).await.unwrap();

    // scoring
    // from the exercise extract all the questions with id and correct answers
    let mut user_answers: Vec<AnswerRequest> = Vec::new();
    let mut correct_answers: Vec<AnswerRequest> = Vec::new();
    exam.user_answers.as_ref().unwrap().answers.iter().for_each(|a| {
        let user_answer = a.clone();
        let question = exam.questions.iter().find(|q| q._id.to_hex() == user_answer.question_id).unwrap();
        let correct_answer = AnswerRequest {
            question_id: user_answer.question_id.clone(),
            answers: question.answers.clone(),
        };
        user_answers.push(user_answer);
        correct_answers.push(correct_answer);
    });

    let course_slug = match CourseEntity::scan(&mongoc, &cache).await {
        Some(c) => match c.into_iter().find(|c| c._id.to_hex() == exam.course_id) {
            Some(c) => c.slug.clone(),
            None => {
                error!("Failed to get course");
                return HttpResponse::NotFound().json(json!({"message": "No course found"}));
            }
        },
        None => {
            error!("Failed to get course");
            return HttpResponse::NotFound().json(json!({"message": "No course found"}));
        }
    };

    HttpResponse::Ok().json(json!(exam
        .questions
        .iter()
        .map(|q| {
            let user_answer = user_answers.iter().find(|a| a.question_id == q._id.to_hex()).unwrap();
            let correct_answer = correct_answers.iter().find(|a| a.question_id == q._id.to_hex()).unwrap();
            let correct_count = correct_answer.answers.iter().filter(|c| user_answer.answers.contains(c)).count();
            let score_per_question = correct_count as f32 / correct_answer.answers.len() as f32;
            let correct = score_per_question == 1.0;
            let key_concept = q.key_concept.clone();
            let question_difficulty = q.question_difficulty.clone();
            let answer_explanation = q.answer_explanation.clone();
            json!({
                "question": markdown_ops::to_html(&q.question),
                "choices": q.choices.iter().map(|c| KeyValue {
                                key: c.key.clone(),
                                value: markdown_ops::to_html(&c.value),
                            }).collect::<Vec<KeyValue>>(),
                "user_answers": user_answer.answers,
                "correct_answers": correct_answer.answers,
                "score": score_per_question,
                "key_concept": key_concept,
                "question_difficulty": question_difficulty,
                "answer_explanation": markdown_ops::to_html(&answer_explanation),
                "correct": correct,
                "exercise_id": exam_id.clone(),
                "question_id": q._id.to_hex(),
                "course_slug": course_slug.clone(),
            })
        })
        .collect::<Vec<serde_json::Value>>()))
}

pub async fn post_exam_followup(
    model: web::Json<FollowupRequest>,
    session: actix_session::Session,
) -> impl Responder {
    let user_auth = UserAuth::from(session);
    let model = model.clone();

    let messages = vec![
        Message {
            role: "system".to_string(),
            content: vec![Content {
                content_type: ContentType::Text,
                text: Some(format!(
                    "You are an experienced {} teacher. \
                    A {} is answering an exam in the course: {}. \
                    Depending on the Result (true or false: correct or incorrect) below, please generate 4-5, 7-15 words follow-up questions. \
                    If the answer is incorrect, include a question why the answer is incorrect. \
                    The following are more details about the question (including result, choices, and key concepts): \
                    {} \
                    The questions should be about probing the correct/incorrect answer, key concepts, generating code samples,  \
                    using analogies, explaining in the style of a celebrity, practical examples, etc. \
                    Do not include questions unrelated to the given course, unit, and topic. \
                    Answer in a json format using the included schema",
                    model.course_name,
                    UserType::to_str(&model.user_type),
                    model.course_name,
                    model.context,
                )),
                image_url: None,
            }],
        },
        Message {
            role: "user".to_string(),
            content: vec![Content {
                content_type: ContentType::Text,
                text: Some(format!(
                    "Generate relevant questions given the context and the following question: {}. Please note, my answer was: {}",
                    model.question,
                    if model.is_correct { "correct" } else { "incorrect. I need to know why?" }
                )),
                image_url: None,
            }],
        },
    ];
    debug!("Sending messages: {:?}", messages);
    let response_format = ResponseFormat {
        format_type: ResponseFormatType::JsonSchema,
        json_schema: Some(serde_json::json!({
          "name": "FollowupQuestions",
          "schema": {
            "type": "object",
            "properties": {
              "followups": {
                "type": "array",
                "items": {
                  "type": "string",
                  "description": "This text will be used as an HTML button text"
                }
              }
            },
            "required": ["followups"]
          }
        })),
    };

    post_chat_completion(messages, Some(response_format), Some(user_auth.google_model.unwrap().id)).await
}

pub async fn post_exam_followup_answer(
    _mongoc: web::Data<Client>,
    _model: web::Json<FollowupRequest>,
    _session: actix_session::Session,
) -> HttpResponse {
    // let model = model.into_inner();
    // let user_auth = UserAuth::from(session);
    // let messages = vec![
    //     Message {
    //         role: "system".to_string(),
    //         content: vec![Content {
    //             content_type: ContentType::Text,
    //             text: Some(format!(
    //                 "You are an experienced {} teacher. \
    //                 A {} is answering an exam in the course: {} and has asked a followup question: {} \
    //                 Answer the question in a way that a {} can understand. \
    //                 Also, include 2-3 followup questions that the student may have. \
    //                 The questions should be about probing the key concepts, generating code samples,  \
    //                 using analogies, explaining in a fictional character voice, practical examples, etc. \
    //                 Do not include questions unrelated to the given course, unit, and topic.\
    //                 Answer in a json format using the included schema",
    //                 model.course_name,
    //                 UserType::to_str(&model.user_type),
    //                 model.course_name,
    //                 model.question,
    //                 UserType::to_str(&model.user_type)
    //             )),
    //             image_url: None,
    //         }],
    //     },
    //     Message {
    //         role: "user".to_string(),
    //         content: vec![Content {
    //             content_type: ContentType::Text,
    //             text: Some(format!(
    //                 "I need to understand the following: {}\n \
    //                 Use additional details of the question for context: {}",
    //                 model.question, model.context
    //             )),
    //             image_url: None,
    //         }],
    //     },
    // ];
    // debug!("Sending messages: {:?}", messages);
    // let response_format = ResponseFormat {
    //     format_type: ResponseFormatType::JsonSchema,
    //     json_schema: Some(serde_json::json!({
    //       "name": "FollowupQuestions",
    //         "schema": {
    //             "type": "object",
    //             "properties": {
    //                 "description": {
    //                     "type": "string",
    //                     "description": "A brief description of the topic in HTML format and will go inside a div"
    //                 },
    //                 "followups": {
    //                     "type": "array",
    //                     "items": {
    //                         "type": "string",
    //                         "description": "This text will be used as an HTML button text"
    //                     }
    //                 }
    //             },
    //             "required": ["description", "followups"]
    //         }
    //     })),
    // };

    // // let entity = ExamEntity {
    // //     _id: ObjectId::parse_str(model.test_id.clone()).unwrap(),
    // //     ..Default::default()
    // // };

    // // let entity = match entity.find(&mongoc).await {
    // //     Some(e) => e,
    // //     None => {
    // //         error!("Failed to get exam");
    // //         return HttpResponse::NotFound().json(json!({"message": "exam not found"}));
    // //     }
    // // };

    // // let mut followups = if entity.followups.is_none() { vec![] } else { entity.clone().followups.unwrap() };
    // // followups.push(model.question.clone());
    // // match entity.update(&mongoc).await {
    // //     Some(_) => debug!("exam updated"),
    // //     None => {
    // //         error!("Failed to update exam");
    // //         return HttpResponse::InternalServerError().json(json!({"message": "Failed to update exam"}));
    // //     }
    // // }

    // post_chat_completion(messages, Some(response_format), Some(user_auth.google_model.unwrap().id)).await

    HttpResponse::Ok().json(json!({"message": "Followup questions sent"}))
}
