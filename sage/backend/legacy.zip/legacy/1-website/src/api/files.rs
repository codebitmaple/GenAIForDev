use serde_json::json;
use std::collections::HashMap;

use aarya_utils::{
    environ::{AwsConfig, Environ},
    file_ops, random_ops, s3_ops, string_ops,
};
use actix_multipart::Multipart;
use actix_web::{HttpResponse, Responder};
use futures::StreamExt;
use serde::{Deserialize, Serialize};

#[derive(Debug, Deserialize, Serialize)]
pub struct FileResponse {
    pub paths: HashMap<String, String>,
}

pub async fn post_markdown(mut payload: Multipart) -> impl Responder {
    let mut response = Vec::new();

    if let Some(item) = payload.next().await {
        let s3_config: AwsConfig = Environ::init();
        let unique_key = format!("{}/{}", s3_config.markdown_uploads_folder, random_ops::generate_guid(16));
        match s3_ops::upload_leading_slash(item, unique_key, s3_config.s3_image_bucket).await {
            Some(path) => {
                response.push(path);
            }
            None => return HttpResponse::BadRequest().json(json!({"message": "upload failed"})),
        };
    }
    HttpResponse::Ok().json(response)
}

pub async fn post_markdown_base64(mut payload: Multipart) -> impl Responder {
    if let Some(item) = payload.next().await {
        let contents = file_ops::read_upload_file(item).await.unwrap();
        println!("contents: {:?}", contents);
        return HttpResponse::Ok().json(json!({"contents": string_ops::to_base64(contents.as_bytes())}));
    }
    HttpResponse::BadRequest().json(json!({"message": "upload failed"}))
}
