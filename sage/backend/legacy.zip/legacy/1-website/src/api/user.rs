use actix_web::{HttpResponse, Responder};
use serde::{Deserialize, Serialize};

use crate::auth::user::UserAuth;

#[derive(Debug, Deserialize, Serialize)]
pub struct UserProfileResponse {
    pub user_key: String,
    pub first_name: String,
    pub last_name: String,
    pub email: String,
}

pub async fn get_user_info(session: actix_session::Session) -> impl Responder {
    let user_auth = UserAuth::from(session);
    let google_model = user_auth.google_model.unwrap();
    let user = UserProfileResponse {
        user_key: user_auth.user_key.unwrap(),
        first_name: google_model.given_name,
        last_name: google_model.family_name,
        email: google_model.email,
    };
    HttpResponse::Ok().json(user)
}
