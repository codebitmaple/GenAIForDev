use aarya_utils::environ::{AwsConfig, Environ};
use aarya_utils::{random_ops, s3_ops};
use actix_multipart::Multipart;
use actix_web::{HttpResponse, Responder};
use futures::StreamExt;
use log::debug;
use serde::{Deserialize, Serialize};
use serde_json::json;
use std::collections::HashMap;

use crate::auth::user::UserAuth;

#[derive(Deserialize, Serialize)]
pub struct PhotoResponse {
    pub paths: Option<HashMap<String, String>>,
}

pub async fn post_photo(mut payload: Multipart) -> impl Responder {
    if let Some(item) = payload.next().await {
        debug!("Processing photo {:?}", item);
        let s3_config: AwsConfig = Environ::init();
        let unique_key = format!("{}/{}", s3_config.photo_uploads_folder, random_ops::generate_guid(16));
        let path = match s3_ops::upload_leading_slash(item, unique_key, s3_config.s3_image_bucket).await {
            Some(path) => path,
            None => return HttpResponse::BadRequest().json(json!({"message": "upload failed"})),
        };
        return HttpResponse::Ok().json(path);
    }

    HttpResponse::BadRequest().json(json!({"message": "upload failed"}))
}

pub async fn post_photos(mut payload: Multipart) -> impl Responder {
    let mut response = Vec::new();
    while let Some(item) = payload.next().await {
        debug!("Processing photo {:?}", item);
        let s3_config: AwsConfig = Environ::init();
        let unique_key = format!("{}/{}", s3_config.photo_uploads_folder, random_ops::generate_guid(16));
        let path = match s3_ops::upload_leading_slash(item, unique_key, s3_config.s3_image_bucket).await {
            Some(path) => path,
            None => return HttpResponse::BadRequest().json(json!({"message": "upload failed"})),
        };
        response.push(path);
    }

    // Return the response as JSON
    HttpResponse::Ok().json(response)
}

pub async fn get_google_profile_pic(session: actix_session::Session) -> impl Responder {
    let user_auth = UserAuth::from(session);
    let image_bytes = user_auth.photo_vector.unwrap_or_default();
    debug!("Returning image of size: {}", image_bytes.len());
    HttpResponse::Ok().content_type("image/png").body(image_bytes)
}
