use aarya_entities::{
    course::course_entity::CourseEntity,
    question::question_entity::{QuestionEntity, QuestionKind, QuestionTarget, QuestionUploadModel},
    topic::topic_entity::TopicEntity,
    unit::unit_entity::UnitEntity,
};
use aarya_utils::{cache_ops, date_ops, file_ops, hash_ops};
use actix_multipart::Multipart;
use actix_web::{web, HttpRequest, HttpResponse, Responder};
use futures::{StreamExt, TryStreamExt};
use handlebars::Handlebars;
use mongodb::{bson::oid::ObjectId, Client};
use serde_json::json;
use std::io::Cursor;

use crate::html_renderer::render_handlebars;

pub async fn get_create_question(
    req: HttpRequest,
    handlebars: web::Data<Handlebars<'_>>,
    mongoc: web::Data<Client>,
    session: actix_session::Session,
    cache: web::Data<cache_ops::Cache>,
) -> impl Responder {
    let courses = CourseEntity::scan(&mongoc, &cache).await.unwrap();
    let units = UnitEntity::scan(&mongoc, &cache).await.unwrap();
    let topics = TopicEntity::scan(&mongoc, &cache).await.unwrap();
    let course_json = courses
        .iter()
        .map(|c| {
            json!({
                "course_id": c._id.to_hex(),
                "course_name": c.name,
            })
        })
        .collect::<Vec<serde_json::Value>>();
    let unit_json = units
        .iter()
        .map(|m| {
            json!({
                "unit_id": m._id.to_hex(),
                "course_id": m.course_id,
                "unit_name": m.name,
            })
        })
        .collect::<Vec<serde_json::Value>>();
    let topic_json = topics
        .iter()
        .map(|l| {
            json!({
                "topic_id": l._id.to_hex(),
                "unit_id": l.unit_id,
                "topic_name": l.name,
            })
        })
        .collect::<Vec<serde_json::Value>>();
    render_handlebars(
        req,
        &handlebars,
        "question-create",
        json!({
            "title": "Batch Create Questions",
            "schema": file_ops::read_file("./assets/schema/question-schema.json").unwrap(),
            "courses": course_json,
            "units": serde_json::to_string(&unit_json).unwrap(),
            "topics": serde_json::to_string(&topic_json).unwrap(),
        }),
        session,
    )
    .await
}

pub async fn post_upload_questions(
    mongoc: web::Data<Client>,
    mut payload: Multipart,
    cache: web::Data<cache_ops::Cache>,
) -> impl Responder {
    // let creator_id = jwt_ops::get_user_key_from(&req).unwrap_or_default();
    let mut topic_id = None; // To store the course ID if it's found
    let mut course_id = None; // To store the course ID if it's found
    let mut unit_id = None; // To store the course ID if it's found
    let mut file_data = Vec::new(); // To store the file data

    // Iterate over the multipart stream (each field in the form)
    while let Ok(Some(mut field)) = payload.try_next().await {
        let content_disposition = field.content_disposition();

        // Check the name of the field (file or course_id)
        match content_disposition.get_name() {
            Some("file") => {
                // If it's the file field, read the file into memory
                while let Some(chunk) = field.next().await {
                    let data = chunk.unwrap();
                    file_data.extend_from_slice(&data);
                }
            }
            Some("topic_id") => {
                // If it's the course_id field, capture it as a string
                let mut question_data = Vec::new();
                while let Some(chunk) = field.next().await {
                    let data = chunk.unwrap();
                    question_data.extend_from_slice(&data);
                }
                topic_id = Some(String::from_utf8(question_data).unwrap());
            }
            Some("unit_id") => {
                // If it's the course_id field, capture it as a string
                let mut question_data = Vec::new();
                while let Some(chunk) = field.next().await {
                    let data = chunk.unwrap();
                    question_data.extend_from_slice(&data);
                }
                unit_id = Some(String::from_utf8(question_data).unwrap());
            }
            Some("course_id") => {
                // If it's the course_id field, capture it as a string
                let mut question_data = Vec::new();
                while let Some(chunk) = field.next().await {
                    let data = chunk.unwrap();
                    question_data.extend_from_slice(&data);
                }
                course_id = Some(String::from_utf8(question_data).unwrap());
            }
            _ => {}
        }
    }

    // Check if both course_id and file were found
    if file_data.is_empty() || topic_id.is_none() {
        return HttpResponse::BadRequest().body("Missing file or topic_id");
    }

    // Parse the JSON file
    let questions: Vec<QuestionUploadModel> = match serde_json::from_reader(Cursor::new(file_data)) {
        Ok(data) => data, // insert into database
        Err(err) => {
            println!("Failed to parse JSON: {:?}", err);
            return HttpResponse::BadRequest().body("Invalid JSON file");
        }
    };

    for q in questions.iter() {
        let question = QuestionEntity {
            _id: ObjectId::new(),
            course_id: course_id.clone().unwrap(),
            unit_id: unit_id.clone().unwrap(),
            topic_id: topic_id.clone(),
            created_at: date_ops::to_timestamp(),
            updated_at: date_ops::to_timestamp(),
            question: q.question.clone(),
            question_hash: hash_ops::string_hasher(&q.question),
            choices: q.choices.clone(),
            answers: q.answers.clone(),
            tags: q.tags.clone(),
            question_type: q.question_type.clone(),
            key_concept: q.key_concept.clone(),
            question_difficulty: q.question_difficulty.clone(),
            answer_explanation: q.answer_explanation.clone(),
            group_id: None,
            kind: Some(QuestionKind::Standalone),
            target: Some(QuestionTarget::Exercise),
            illustration: None,
            order: Some(q.order),
        };
        question.create(&mongoc, &cache).await;
    }

    // Process the course_id and file (JSON data) as needed
    println!("Received topic_id: {:?}", topic_id);
    println!("Parsed JSON: {:?}", questions);

    // Return success response
    HttpResponse::Ok().json(questions)
}

pub async fn get_instructor_questions() -> impl Responder {
    HttpResponse::Ok().body("Hello from get_instructor_questions")
}
