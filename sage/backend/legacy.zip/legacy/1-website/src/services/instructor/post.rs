use std::{io::Cursor, str::FromStr};

use aarya_entities::{
    instructor::entity::InstructorEntity,
    models::req_res::{PostRequestModel, PostResponseModel},
    post::PostEntity,
    user::UserEntity,
};
use aarya_utils::{
    cache_ops, date_ops,
    environ::{Environ, WebConfig},
    file_ops,
};
use actix_multipart::Multipart;
use actix_web::{web, HttpRequest, HttpResponse, Responder};

use futures::{StreamExt, TryStreamExt};
use handlebars::Handlebars;
use log::{debug, error};
use mongodb::{bson::oid::ObjectId, Client};
use serde_json::json;

use crate::{auth::user::UserAuth, html_renderer::render_handlebars};

pub async fn get_create_post(
    req: HttpRequest,
    handlebars: web::Data<Handlebars<'_>>,
    session: actix_session::Session,
) -> impl Responder {
    render_handlebars(
        req,
        &handlebars,
        "post-create",
        json!({
            "title": "Add a new Post",
            "timestamp": date_ops::to_input_date(),
            "schema": file_ops::read_file("./assets/schema/post-schema.json").unwrap()
        }),
        session,
    )
    .await
}

pub async fn get_post_list(
    req: HttpRequest,
    handlebars: web::Data<Handlebars<'_>>,
    mongoc: web::Data<Client>,
    session: actix_session::Session,
    cache: web::Data<cache_ops::Cache>,
) -> impl Responder {
    let posts = match PostEntity::scan(&mongoc, &cache).await {
        Some(p) => p,
        None => {
            error!("Failed to find posts");
            return HttpResponse::InternalServerError().body("Error finding posts");
        }
    };

    debug!("Found {} posts", posts.len());

    let users = match UserEntity::scan(&mongoc).await {
        Some(u) => u,
        None => {
            error!("Failed to find users");
            return HttpResponse::InternalServerError().body("Error finding users");
        }
    };

    debug!("Found {} users", users.len());

    let instructors = match InstructorEntity::scan(&mongoc).await {
        Some(i) => i,
        None => {
            error!("Failed to find instructors");
            return HttpResponse::InternalServerError().body("Error finding instructors");
        }
    };

    debug!("Found {} instructors", instructors.len());

    let response = PostResponseModel::all(&posts, &users, &instructors);

    debug!("Response: {:?}", response);

    let web_config: WebConfig = Environ::init();

    render_handlebars(
        req,
        &handlebars,
        "post-list",
        json!({
            "title": "All Posts",
            "posts": response,
            "base_url": web_config.images_domain
        }),
        session,
    )
    .await
}

pub async fn get_edit_post(
    req: HttpRequest,
    handlebars: web::Data<Handlebars<'_>>,
    mongoc: web::Data<Client>,
    path: web::Path<String>,
    session: actix_session::Session,
    cache: web::Data<cache_ops::Cache>,
) -> impl Responder {
    let post_id = path.into_inner();

    let post = match PostEntity::find(&mongoc, &post_id, &cache).await {
        Some(p) => p,
        None => {
            error!("Failed to find post");
            return HttpResponse::InternalServerError().body("Error finding post");
        }
    };

    let response = PostResponseModel::from_entity(post);

    render_handlebars(
        req,
        &handlebars,
        "post-edit",
        json!({
            "title": "Edit a Post",
            "post": response,
            "post_id": response.id,
            "markdown": response.body.replace("\r\n", "\n"),
            "schema": file_ops::read_file("./assets/schema/post-schema.json").unwrap()
        }),
        session,
    )
    .await
}

pub async fn get_post_download_template() -> impl Responder {
    let post = PostRequestModel::default();
    HttpResponse::Ok()
        .content_type("application/json")
        .insert_header(("Content-Disposition", "attachment; filename=\"post-create-template.json\"".to_string()))
        .body(serde_json::to_string(&post).unwrap())
}

pub async fn get_post_download(
    mongoc: web::Data<Client>,
    path: web::Path<String>,
    cache: web::Data<cache_ops::Cache>,
) -> impl Responder {
    let post_id = path.into_inner();
    let post = match PostEntity::find(&mongoc, &post_id, &cache).await {
        Some(p) => p,
        None => {
            error!("Failed to find post");
            return HttpResponse::InternalServerError().body("Error finding post");
        }
    };
    let resuest = PostRequestModel::from(post);
    HttpResponse::Ok()
        .content_type("application/json")
        .insert_header(("Content-Disposition", "attachment; filename=\"post-edit-template.json\"".to_string()))
        .body(serde_json::to_string(&resuest).unwrap())
}

pub async fn get_post_markdown_download(
    mongoc: web::Data<Client>,
    path: web::Path<String>,
    cache: web::Data<cache_ops::Cache>,
) -> impl Responder {
    let post_id = path.into_inner();
    let post = match PostEntity::find(&mongoc, &post_id, &cache).await {
        Some(p) => p,
        None => {
            error!("Failed to find post");
            return HttpResponse::InternalServerError().body("Error finding post");
        }
    };
    let request = PostRequestModel::from(post);
    let markdown = file_ops::read_base64_file(format!("./assets/markdowns/{}.md", request.body).as_str()).unwrap();
    HttpResponse::Ok()
        .content_type("application/octet-stream")
        .insert_header(("Content-Disposition", format!("attachment; filename=\"post-markdown_{}.md\"", post_id)))
        .body(markdown)
}

pub async fn post_upload_post(
    mongoc: web::Data<Client>,
    mut payload: Multipart,
    session: actix_session::Session,
    cache: web::Data<cache_ops::Cache>,
) -> impl Responder {
    let user_auth = UserAuth::from(session);
    let creator_id = user_auth.google_model.unwrap().id;

    let post = match data_from_payload(&mut payload).await {
        Ok(value) => value,
        Err(value) => return value,
    };

    match create_post(&mongoc, &post, creator_id, &cache).await {
        Some(_) => HttpResponse::Ok().json(post.permalink),
        None => HttpResponse::BadRequest().json(json!({"message": "Error creating post"})),
    }
}

pub async fn put_upload_post(
    mongoc: web::Data<Client>,
    mut payload: Multipart,
    session: actix_session::Session,
    cache: web::Data<cache_ops::Cache>,
) -> impl Responder {
    let user_auth = UserAuth::from(session);
    let creator_id = user_auth.google_model.unwrap().id;

    let (post, post_id) = match edit_data_from_payload(&mut payload).await {
        Ok(value) => value,
        Err(value) => return value,
    };

    match edit_post(&mongoc, &post, post_id, creator_id, &cache).await {
        Some(_) => HttpResponse::Ok().json(post.permalink),
        None => HttpResponse::BadRequest().json(json!({"message": "Error editing post"})),
    }
}

async fn data_from_payload(payload: &mut Multipart) -> Result<PostRequestModel, HttpResponse> {
    let mut file_data = Vec::new();
    let mut markdown = String::from("");
    while let Ok(Some(mut field)) = payload.try_next().await {
        let content_disposition = field.content_disposition();
        if let Some("file") = content_disposition.get_name() {
            while let Some(chunk) = field.next().await {
                let data = chunk.unwrap();
                file_data.extend_from_slice(&data);
            }
        } else if let Some("markdown") = content_disposition.get_name() {
            let mut markdown_data = Vec::new();
            while let Some(chunk) = field.next().await {
                let data = chunk.unwrap();
                markdown_data.extend_from_slice(&data);
            }
            markdown = String::from_utf8(markdown_data).unwrap();
        }
    }
    let mut post: PostRequestModel = match serde_json::from_reader(Cursor::new(file_data)) {
        Ok(data) => data, // insert into database (use course_id and creator_id)
        Err(err) => {
            println!("Failed to parse JSON: {:?}", err);
            return Err(HttpResponse::BadRequest().body("Invalid JSON file"));
        }
    };
    post.body = markdown;
    Ok(post)
}

async fn edit_data_from_payload(payload: &mut Multipart) -> Result<(PostRequestModel, String), HttpResponse> {
    let mut file_data = Vec::new();
    let mut post_id = None;
    let mut markdown = String::from("");
    while let Ok(Some(mut field)) = payload.try_next().await {
        let content_disposition = field.content_disposition();
        if let Some("file") = content_disposition.get_name() {
            while let Some(chunk) = field.next().await {
                let data = chunk.unwrap();
                file_data.extend_from_slice(&data);
            }
        } else if let Some("post_id") = content_disposition.get_name() {
            let mut course_data = Vec::new();
            while let Some(chunk) = field.next().await {
                let data = chunk.unwrap();
                course_data.extend_from_slice(&data);
            }
            post_id = Some(String::from_utf8(course_data).unwrap());
        } else if let Some("markdown") = content_disposition.get_name() {
            let mut markdown_data = Vec::new();
            while let Some(chunk) = field.next().await {
                let data = chunk.unwrap();
                markdown_data.extend_from_slice(&data);
            }
            markdown = String::from_utf8(markdown_data).unwrap();
        }
    }
    let mut post: PostRequestModel = match serde_json::from_reader(Cursor::new(file_data)) {
        Ok(data) => data, // insert into database (use course_id and creator_id)
        Err(err) => {
            println!("Failed to parse JSON: {:?}", err);
            return Err(HttpResponse::BadRequest().body("Invalid JSON file"));
        }
    };
    post.body = markdown;
    Ok((post, post_id.unwrap()))
}

async fn create_post(
    mongoc: &web::Data<Client>,
    request: &PostRequestModel,
    creater_id: String,
    cache: &cache_ops::Cache,
) -> Option<String> {
    let post = PostEntity {
        _id: Some(ObjectId::new()),
        creator_id: creater_id,
        ..request.to()
    };
    post.create(mongoc, cache).await
}

async fn edit_post(
    mongoc: &web::Data<Client>,
    request: &PostRequestModel,
    post_id: String,
    creater_id: String,
    cache: &cache_ops::Cache,
) -> Option<String> {
    let post = PostEntity {
        _id: Some(ObjectId::from_str(&post_id).unwrap()),
        creator_id: creater_id,
        modified_date: date_ops::to_timestamp(),
        ..request.to()
    };
    post.update(mongoc, cache).await
}
