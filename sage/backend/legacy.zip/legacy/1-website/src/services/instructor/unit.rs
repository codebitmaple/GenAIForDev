use aarya_entities::{
    course::course_entity::CourseEntity,
    key_value::KeyValues,
    unit::unit_entity::{UnitEntity, UnitUploadModel},
};
use aarya_utils::{cache_ops, date_ops, file_ops, hash_ops, jwt_ops};
use actix_multipart::Multipart;
use actix_web::{web, HttpRequest, HttpResponse, Responder};
use futures::{StreamExt, TryStreamExt};
use handlebars::Handlebars;
use log::debug;
use mongodb::{bson::oid::ObjectId, Client};
use serde::{Deserialize, Serialize};
use serde_json::json;
use std::{io::Cursor, str::FromStr};

use crate::html_renderer::render_handlebars;
#[derive(Debug, Serialize, Deserialize, Clone)]
pub struct UnitResponseModel {
    pub id: String,
    pub name: String,
    pub description: String,
}

impl From<UnitEntity> for UnitResponseModel {
    fn from(entity: UnitEntity) -> Self {
        UnitResponseModel {
            id: entity._id.to_hex(),
            name: entity.name,
            description: entity.description,
        }
    }
}

#[derive(Debug, Serialize, Deserialize)]
pub struct UnitEditModel {
    pub name: String,
    pub slug: String,
    pub description: String,
    pub created_at: i64,
    pub metadata: Vec<KeyValues>,
    pub unit_number: u32,
}

impl From<UnitEntity> for UnitEditModel {
    fn from(entity: UnitEntity) -> Self {
        UnitEditModel {
            name: entity.name,
            slug: entity.slug,
            description: entity.description,
            created_at: entity.created_at,
            metadata: entity.metadata,
            unit_number: entity.unit_number,
        }
    }
}

#[derive(Debug, Serialize, Deserialize)]
pub struct UnitRequestModel {
    pub name: String,
    pub description: String,
    pub slug: String,
    pub metadata: Vec<KeyValues>,
    pub unit_number: u32,
}

pub async fn get_create_unit(
    req: HttpRequest,
    handlebars: web::Data<Handlebars<'_>>,
    mongoc: web::Data<Client>,
    session: actix_session::Session,
    cache: web::Data<cache_ops::Cache>,
) -> impl Responder {
    let courses = CourseEntity::scan(&mongoc, &cache).await.unwrap();
    render_handlebars(
        req,
        &handlebars,
        "unit-create",
        json!({
            "title": "Create a New Unit",
            "schema": file_ops::read_file("./assets/schema/unit-schema.json").unwrap(),
            "courses": courses.iter().map(|c| json!({
                "course_id": c._id.to_hex(),
                "course_name": c.name,
            })).collect::<Vec<serde_json::Value>>(),
        }),
        session,
    )
    .await
}

pub async fn get_units_all(
    req: HttpRequest,
    handlebars: web::Data<Handlebars<'_>>,
    mongoc: web::Data<Client>,
    session: actix_session::Session,
    cache: web::Data<cache_ops::Cache>,
) -> impl Responder {
    let units = UnitEntity::scan(&mongoc, &cache).await.unwrap();
    let model = units.iter().map(|u| UnitResponseModel::from(u.clone())).collect::<Vec<UnitResponseModel>>();
    render_handlebars(
        req,
        &handlebars,
        "unit-list",
        json!({
            "title": "All Units",
            "units": model,
        }),
        session,
    )
    .await
}

pub async fn get_unit_edit(
    req: HttpRequest,
    handlebars: web::Data<Handlebars<'_>>,
    mongoc: web::Data<Client>,
    path: web::Path<String>,
    session: actix_session::Session,
    cache: web::Data<cache_ops::Cache>,
) -> impl Responder {
    let unit_id = path.into_inner();
    let unit = UnitEntity::find_by_id(&mongoc, &cache, unit_id.clone()).await.unwrap();
    let model = UnitEditModel::from(unit.clone());

    render_handlebars(
        req,
        &handlebars,
        "unit-edit",
        json!({
            "title": "Edit a Unit",
            "schema": file_ops::read_file("./assets/schema/unit-schema.json").unwrap(),
            "unit": model,
            "unit_id": unit_id,
            "course_id": unit.course_id.clone(),
            "creator_id": unit.creator_id.clone(),
        }),
        session,
    )
    .await
}

pub async fn post_upload_units(
    req: HttpRequest,
    mongoc: web::Data<Client>,
    mut payload: Multipart,
    cache: web::Data<cache_ops::Cache>,
) -> impl Responder {
    let creator_id = jwt_ops::get_user_key_from(&req).unwrap_or_default();

    let (units, course_id) = match data_from_payload(&mut payload).await {
        Ok(value) => value,
        Err(value) => return value,
    };

    create_units(&units, &course_id, creator_id, mongoc, cache).await;

    // Process the course_id and file (JSON data) as needed
    println!("Received course_id: {:?}", course_id);
    println!("Parsed JSON: {:?}", units);

    // Return success response
    HttpResponse::Ok().json(units)
}

pub async fn post_download_unit_json(
    mongoc: web::Data<Client>,
    path: web::Path<String>,
    cache: web::Data<cache_ops::Cache>,
) -> impl Responder {
    let unit_id = path.into_inner();
    let topic = UnitEntity::find_by_id(&mongoc, &cache, unit_id.clone()).await.unwrap();
    let model = [UnitEditModel::from(topic)];
    HttpResponse::Ok()
        .content_type("application/json")
        .insert_header(("Content-Disposition", format!("attachment; filename=\"unit-edit-template-{}.json\"", unit_id)))
        .body(serde_json::to_string(&model).unwrap())
}

pub async fn put_upload_units(
    mongoc: web::Data<Client>,
    mut payload: Multipart,
    cache: web::Data<cache_ops::Cache>,
) -> impl Responder {
    let (units, unit_id, creator_id, course_id) = match edit_data_from_payload(&mut payload).await {
        Ok(value) => value,
        Err(value) => return value,
    };

    debug!("Received unit_id: {:?}", unit_id);

    edit_units(&units, &course_id, &unit_id, creator_id, mongoc, cache).await;

    // Return success response
    HttpResponse::Ok().json(units)
}

async fn create_units(
    units: &[UnitUploadModel],
    course_id: &str,
    creator_id: String,
    mongoc: web::Data<Client>,
    cache: web::Data<cache_ops::Cache>,
) {
    for m in units.iter() {
        let unit = UnitEntity {
            _id: ObjectId::new(),
            course_id: course_id.to_string(),
            name_hash: hash_ops::string_hasher(&m.name),
            name: m.name.clone(),
            description: m.description.clone(),
            creator_id: creator_id.clone(),
            created_at: date_ops::to_timestamp(),
            updated_at: date_ops::to_timestamp(),
            slug: m.slug.clone(),
            metadata: m.metadata.clone(),
            unit_number: m.unit_number,
        };
        unit.create(&mongoc, &cache).await;
    }
}

async fn edit_units(
    units: &[UnitEditModel],
    course_id: &str,
    unit_id: &str,
    creator_id: String,
    mongoc: web::Data<Client>,
    cache: web::Data<cache_ops::Cache>,
) {
    for m in units.iter() {
        let unit = UnitEntity {
            _id: ObjectId::from_str(unit_id).unwrap(),
            course_id: course_id.to_string(),
            name_hash: hash_ops::string_hasher(&m.name),
            name: m.name.clone(),
            description: m.description.clone(),
            creator_id: creator_id.clone(),
            created_at: m.created_at,
            updated_at: date_ops::to_timestamp(),
            slug: m.slug.clone(),
            metadata: m.metadata.clone(),
            unit_number: m.unit_number,
        };
        unit.update(&mongoc, &cache).await;
    }
}

async fn data_from_payload(payload: &mut Multipart) -> Result<(Vec<UnitUploadModel>, String), HttpResponse> {
    let mut file_data = Vec::new();
    let mut course_id = None;
    while let Ok(Some(mut field)) = payload.try_next().await {
        let content_disposition = field.content_disposition();
        if let Some("file") = content_disposition.get_name() {
            while let Some(chunk) = field.next().await {
                let data = chunk.unwrap();
                file_data.extend_from_slice(&data);
            }
        } else if let Some("course_id") = content_disposition.get_name() {
            let mut course_data = Vec::new();
            while let Some(chunk) = field.next().await {
                let data = chunk.unwrap();
                course_data.extend_from_slice(&data);
            }
            course_id = Some(String::from_utf8(course_data).unwrap());
        }
    }
    let units: Vec<UnitUploadModel> = match serde_json::from_reader(Cursor::new(file_data)) {
        Ok(data) => data, // insert into database (use course_id and creator_id)
        Err(err) => {
            println!("Failed to parse JSON: {:?}", err);
            return Err(HttpResponse::BadRequest().body("Invalid JSON file"));
        }
    };
    Ok((units, course_id.unwrap()))
}

async fn edit_data_from_payload(payload: &mut Multipart) -> Result<(Vec<UnitEditModel>, String, String, String), HttpResponse> {
    let mut file_data = Vec::new();
    let mut course_id = None;
    let mut unit_id = None;
    let mut creator_id = None;
    while let Ok(Some(mut field)) = payload.try_next().await {
        let content_disposition = field.content_disposition();
        if let Some("file") = content_disposition.get_name() {
            while let Some(chunk) = field.next().await {
                let data = chunk.unwrap();
                file_data.extend_from_slice(&data);
            }
        } else if let Some("course_id") = content_disposition.get_name() {
            let mut course_data = Vec::new();
            while let Some(chunk) = field.next().await {
                let data = chunk.unwrap();
                course_data.extend_from_slice(&data);
            }
            course_id = Some(String::from_utf8(course_data).unwrap());
        } else if let Some("unit_id") = content_disposition.get_name() {
            let mut course_data = Vec::new();
            while let Some(chunk) = field.next().await {
                let data = chunk.unwrap();
                course_data.extend_from_slice(&data);
            }
            unit_id = Some(String::from_utf8(course_data).unwrap());
        } else if let Some("creator_id") = content_disposition.get_name() {
            let mut course_data = Vec::new();
            while let Some(chunk) = field.next().await {
                let data = chunk.unwrap();
                course_data.extend_from_slice(&data);
            }
            creator_id = Some(String::from_utf8(course_data).unwrap());
        }
    }
    let units: Vec<UnitEditModel> = match serde_json::from_reader(Cursor::new(file_data)) {
        Ok(data) => data, // insert into database (use course_id and creator_id)
        Err(err) => {
            println!("Failed to parse JSON: {:?}", err);
            return Err(HttpResponse::BadRequest().body("Invalid JSON file"));
        }
    };
    Ok((units, unit_id.unwrap(), creator_id.unwrap(), course_id.unwrap()))
}
