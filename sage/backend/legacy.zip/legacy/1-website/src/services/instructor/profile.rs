use aarya_entities::instructor::{entity::InstructorEntity, request::InstructorRequestModel, response::InstructorResponseModel};
use aarya_utils::{
    environ::{Environ, WebConfig},
    file_ops,
};
use actix_web::{web, HttpRequest, HttpResponse, Responder};

use handlebars::Handlebars;
use log::{debug, error};
use mongodb::Client;
use serde_json::json;

use crate::html_renderer::render_handlebars;

pub async fn get_instructors_all(
    req: HttpRequest,
    handlebars: web::Data<Handlebars<'_>>,
    mongoc: web::Data<Client>,
    session: actix_session::Session,
) -> impl Responder {
    let instructors = match InstructorEntity::scan(&mongoc).await {
        Some(i) => i,
        None => {
            error!("Failed to find instructors");
            return HttpResponse::NotFound().body("Error finding instructors");
        }
    };
    let instructors: Vec<InstructorResponseModel> = instructors.iter().map(|i| i.to()).collect();
    render_handlebars(
        req,
        &handlebars,
        "instructors-list",
        json!({
            "title": "All Instructors",
            "instructors": instructors
        }),
        session,
    )
    .await
}

pub async fn get_instructor_card(
    req: HttpRequest,
    handlebars: web::Data<Handlebars<'_>>,
    mongoc: web::Data<Client>,
    path: web::Path<String>,
    session: actix_session::Session,
) -> impl Responder {
    let user_key = path.into_inner(); // google ID
    let instructor = InstructorResponseModel::from_google_id(&mongoc, &user_key).await.unwrap();
    debug!("Instructor card {:?}", instructor);
    let web_config: WebConfig = Environ::init();
    render_handlebars(
        req,
        &handlebars,
        "instructor-list",
        json!({
            "title": "Edit Instructor",
            "instructor": instructor,
            "user_key": user_key,
            "profile_photo": format!("{}{}",web_config.images_domain, instructor.profile_photo)
        }),
        session,
    )
    .await
}

pub async fn get_instructor_edit(
    req: HttpRequest,
    handlebars: web::Data<Handlebars<'_>>,
    mongoc: web::Data<Client>,
    path: web::Path<String>,
    session: actix_session::Session,
) -> impl Responder {
    let instructor_id = path.into_inner();
    let instructor = InstructorResponseModel::from_google_id(&mongoc, &instructor_id).await;
    debug!("Edit instructor profile {:?}", instructor);
    render_handlebars(
        req,
        &handlebars,
        "instructor-edit",
        json!({
            "title": "Edit Instructor",
            "instructor": instructor,
            "schema": file_ops::read_file("./assets/schema/instructor-schema.json").unwrap()
        }),
        session,
    )
    .await
}

pub async fn put_instructor_edit(
    mongoc: web::Data<Client>,
    model: web::Json<InstructorRequestModel>,
) -> impl Responder {
    let model_clone = model.clone();
    let instructor_id = model_clone.id;
    let instructor = InstructorEntity {
        user_id: instructor_id.clone(),
        full_name: format!("{} {}", model_clone.first_name, model_clone.last_name),
        email: model_clone.email,
        first_name: model_clone.first_name,
        bio: model_clone.bio,
        intro: model_clone.intro,
        photo_url: model_clone.photo_url.unwrap_or_default(),
        expertise: vec![],
        last_name: Some(model_clone.last_name),
        caption: Some(model_clone.caption.unwrap_or_default()),
    };
    debug!("Updating instructor {:?}", instructor);
    match instructor.upsert(&mongoc).await {
        Some(_) => HttpResponse::Ok().json(json!({ "status": "ok" })),
        None => HttpResponse::BadRequest().json(json!({ "error": format!("{} not updated", instructor_id) })),
    }
}
