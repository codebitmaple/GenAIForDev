use std::{io::Cursor, str::FromStr};

use aarya_entities::{
    course::course_entity::CourseEntity,
    topic::topic_entity::{TopicCreateModel, TopicEditModel, TopicEntity, TopicResponseModel},
    unit::unit_entity::UnitEntity,
};
use aarya_utils::{cache_ops, date_ops, file_ops, hash_ops, jwt_ops};
use actix_multipart::Multipart;
use actix_web::{web, HttpRequest, HttpResponse, Responder};
use futures::{StreamExt, TryStreamExt};
use handlebars::Handlebars;
use mongodb::{bson::oid::ObjectId, Client};
use serde_json::json;

use crate::html_renderer::render_handlebars;

pub async fn get_create_topic(
    req: HttpRequest,
    handlebars: web::Data<Handlebars<'_>>,
    mongoc: web::Data<Client>,
    session: actix_session::Session,
    cache: web::Data<cache_ops::Cache>,
) -> impl Responder {
    let courses = CourseEntity::scan(&mongoc, &cache).await.unwrap();
    let units = UnitEntity::scan(&mongoc, &cache).await.unwrap();
    let course_json = courses
        .iter()
        .map(|c| {
            json!({
                "course_id": c._id.to_hex(),
                "course_name": c.name,
            })
        })
        .collect::<Vec<serde_json::Value>>();
    let unit_json = units
        .iter()
        .map(|m| {
            json!({
                "unit_id": m._id.to_hex(),
                "course_id": m.course_id,
                "unit_name": m.name,
            })
        })
        .collect::<Vec<serde_json::Value>>();
    render_handlebars(
        req,
        &handlebars,
        "topic-create",
        json!({
            "title": "Create a New Topic",
            "schema": file_ops::read_file("./assets/schema/topic-schema.json").unwrap(),
            "courses": course_json,
            "units": serde_json::to_string(&unit_json).unwrap(),
        }),
        session,
    )
    .await
}

pub async fn post_upload_topics(
    req: HttpRequest,
    mongoc: web::Data<Client>,
    mut payload: Multipart,
    cache: web::Data<cache_ops::Cache>,
) -> impl Responder {
    let creator_id = jwt_ops::get_user_key_from(&req).unwrap_or_default();

    let (topics, unit_id) = match data_from_payload(&mut payload).await {
        Ok(value) => value,
        Err(value) => return value,
    };

    create_topics(&topics, &unit_id, creator_id, mongoc, cache).await;

    // Process the course_id and file (JSON data) as needed
    println!("Received unit_id: {:?}", unit_id);
    println!("Parsed JSON: {:?}", topics);

    // Return success response
    HttpResponse::Ok().json(topics)
}

pub async fn get_topic_edit(
    req: HttpRequest,
    handlebars: web::Data<Handlebars<'_>>,
    mongoc: web::Data<Client>,
    path: web::Path<String>,
    session: actix_session::Session,
    cache: web::Data<cache_ops::Cache>,
) -> impl Responder {
    let topic_id = path.into_inner();
    let topic = TopicEntity::find_by_id(&mongoc, &cache, topic_id.clone()).await.unwrap();

    render_handlebars(
        req,
        &handlebars,
        "topic-edit",
        json!({
            "title": "Edit a Topic",
            "schema": file_ops::read_file("./assets/schema/topic-schema.json").unwrap(),
            "topic": topic,
            "topic_id": topic_id,
        }),
        session,
    )
    .await
}

pub async fn put_upload_topics(
    mongoc: web::Data<Client>,
    mut payload: Multipart,
    cache: web::Data<cache_ops::Cache>,
) -> impl Responder {
    let (topics, unit_id, creator_id, topic_id) = match edit_data_from_payload(&mut payload).await {
        Ok(value) => value,
        Err(value) => return value,
    };

    edit_topics(&topics, &unit_id, creator_id, topic_id.as_str(), mongoc, cache).await;

    // Process the course_id and file (JSON data) as needed
    println!("Received unit_id: {:?}", unit_id);
    println!("Parsed JSON: {:?}", topics);

    // Return success response
    HttpResponse::Ok().json(topics)
}

pub async fn get_topic_list(
    req: HttpRequest,
    handlebars: web::Data<Handlebars<'_>>,
    mongoc: web::Data<Client>,
    session: actix_session::Session,
    cache: web::Data<cache_ops::Cache>,
) -> impl Responder {
    let topics = TopicEntity::scan(&mongoc, &cache).await.unwrap_or_default();
    let model = topics.iter().map(|t| TopicResponseModel::from(t.clone())).collect::<Vec<TopicResponseModel>>();
    render_handlebars(
        req,
        &handlebars,
        "topic-list",
        json!({
            "title": "List of Topics",
            "description": "All available topics",
            "topics": model,
            "topics_empty": model.is_empty(),
        }),
        session,
    )
    .await
}

pub async fn post_download_topic_json(
    mongoc: web::Data<Client>,
    path: web::Path<String>,
    cache: web::Data<cache_ops::Cache>,
) -> impl Responder {
    let topic_id = path.into_inner();
    let topic = TopicEntity::find_by_id(&mongoc, &cache, topic_id.clone()).await.unwrap();
    let model = [TopicEditModel::from(topic)];
    HttpResponse::Ok()
        .content_type("application/json")
        .insert_header(("Content-Disposition", format!("attachment; filename=\"topic_edit_template_{}.json\"", topic_id)))
        .body(serde_json::to_string(&model).unwrap())
}

async fn create_topics(
    topics: &[TopicCreateModel],
    unit_id: &str,
    creator_id: String,
    mongoc: web::Data<Client>,
    cache: web::Data<cache_ops::Cache>,
) {
    for model in topics.iter() {
        let topic = TopicEntity {
            _id: ObjectId::new(),
            name_hash: hash_ops::string_hasher(&model.name),
            name: model.name.clone(),
            meta_description: model.meta_description.clone(),
            creator_id: creator_id.to_string(),
            created_at: date_ops::to_timestamp(),
            updated_at: date_ops::to_timestamp(),
            markdown: model.markdown.clone(),
            unit_id: unit_id.to_string(),
            tags: model.tags.clone(),
            scope: model.scope.clone(),
            slug: model.slug.clone(),
            // metadata: Some(model.metadata.clone()),
            topic_number: model.topic_number,
            summary: Some(model.summary.clone()),
        };
        topic.create(&mongoc, &cache).await;
    }
}

async fn edit_topics(
    topics: &[TopicEditModel],
    unit_id: &str,
    creator_id: String,
    topic_id: &str,
    mongoc: web::Data<Client>,
    cache: web::Data<cache_ops::Cache>,
) {
    for model in topics.iter() {
        let unit = TopicEntity {
            _id: ObjectId::from_str(topic_id).unwrap(),
            name_hash: hash_ops::string_hasher(&model.name),
            name: model.name.clone(),
            meta_description: model.meta_description.clone(),
            creator_id: creator_id.to_string(),
            created_at: model.created_at,
            updated_at: date_ops::to_timestamp(),
            markdown: model.markdown.clone(),
            unit_id: unit_id.to_string(),
            tags: model.tags.clone(),
            scope: model.scope.clone(),
            slug: model.slug.clone(),
            // metadata: Some(model.metadata.clone()),
            topic_number: model.topic_number,
            summary: Some(model.summary.clone()),
        };
        unit.update(&mongoc, &cache).await;
    }
}

async fn data_from_payload(payload: &mut Multipart) -> Result<(Vec<TopicCreateModel>, String), HttpResponse> {
    let mut file_data = Vec::new();
    let mut unit_id = None;
    while let Ok(Some(mut field)) = payload.try_next().await {
        let content_disposition = field.content_disposition();
        if let Some("file") = content_disposition.get_name() {
            while let Some(chunk) = field.next().await {
                let data = chunk.unwrap();
                file_data.extend_from_slice(&data);
            }
        } else if let Some("unit_id") = content_disposition.get_name() {
            let mut course_data = Vec::new();
            while let Some(chunk) = field.next().await {
                let data = chunk.unwrap();
                course_data.extend_from_slice(&data);
            }
            unit_id = Some(String::from_utf8(course_data).unwrap());
        }
    }
    let units: Vec<TopicCreateModel> = match serde_json::from_reader(Cursor::new(file_data)) {
        Ok(data) => data, // insert into database (use course_id and creator_id)
        Err(err) => {
            println!("Failed to parse JSON: {:?}", err);
            return Err(HttpResponse::BadRequest().body("Invalid JSON file"));
        }
    };
    Ok((units, unit_id.unwrap()))
}

async fn edit_data_from_payload(payload: &mut Multipart) -> Result<(Vec<TopicEditModel>, String, String, String), HttpResponse> {
    let mut file_data = Vec::new();
    let mut unit_id = None;
    let mut topic_id = None;
    let mut creator_id = None;
    while let Ok(Some(mut field)) = payload.try_next().await {
        let content_disposition = field.content_disposition();
        if let Some("file") = content_disposition.get_name() {
            while let Some(chunk) = field.next().await {
                let data = chunk.unwrap();
                file_data.extend_from_slice(&data);
            }
        } else if let Some("unit_id") = content_disposition.get_name() {
            let mut course_data = Vec::new();
            while let Some(chunk) = field.next().await {
                let data = chunk.unwrap();
                course_data.extend_from_slice(&data);
            }
            unit_id = Some(String::from_utf8(course_data).unwrap());
        } else if let Some("creator_id") = content_disposition.get_name() {
            let mut course_data = Vec::new();
            while let Some(chunk) = field.next().await {
                let data = chunk.unwrap();
                course_data.extend_from_slice(&data);
            }
            creator_id = Some(String::from_utf8(course_data).unwrap());
        } else if let Some("topic_id") = content_disposition.get_name() {
            let mut course_data = Vec::new();
            while let Some(chunk) = field.next().await {
                let data = chunk.unwrap();
                course_data.extend_from_slice(&data);
            }
            topic_id = Some(String::from_utf8(course_data).unwrap());
        }
    }
    let units: Vec<TopicEditModel> = match serde_json::from_reader(Cursor::new(file_data)) {
        Ok(data) => data, // insert into database (use course_id and creator_id)
        Err(err) => {
            println!("Failed to parse JSON: {:?}", err);
            return Err(HttpResponse::BadRequest().body("Invalid JSON file"));
        }
    };
    Ok((units, unit_id.unwrap(), creator_id.unwrap(), topic_id.unwrap()))
}
