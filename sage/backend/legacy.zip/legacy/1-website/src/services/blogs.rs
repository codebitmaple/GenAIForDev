use std::collections::HashSet;

use aarya_entities::instructor::entity::InstructorEntity;
use aarya_entities::instructor::response::InstructorResponseModel;
use aarya_entities::models::req_res::PostResponseModel;
use aarya_entities::post::PostEntity;
use aarya_entities::user::UserEntity;
use aarya_utils::cache_ops::Cache;
use aarya_utils::environ::Environ;
use aarya_utils::environ::WebConfig;
use aarya_utils::markdown_ops;
use actix_web::{web, HttpRequest, HttpResponse, Responder};
use handlebars::Handlebars;
use log::debug;
use log::error;
use mongodb::Client;
use serde_json::json;

use crate::html_renderer::render_handlebars;

pub async fn get_posts(
    req: HttpRequest,
    handlebars: web::Data<Handlebars<'_>>,
    mongoc: web::Data<Client>,
    session: actix_session::Session,
    cache: web::Data<Cache>,
) -> impl Responder {
    let posts = match PostEntity::scan(&mongoc, &cache).await {
        Some(p) => p,
        None => {
            error!("Failed to find posts");
            return HttpResponse::NotFound().body("Posts not found");
        }
    };

    let instructors = match InstructorEntity::scan(&mongoc).await {
        Some(i) => i,
        None => {
            error!("Failed to find instructors");
            return HttpResponse::InternalServerError().body("Error finding instructors");
        }
    };

    let users = match UserEntity::scan(&mongoc).await {
        Some(u) => u,
        None => {
            error!("Failed to find users");
            return HttpResponse::InternalServerError().body("Error finding users");
        }
    };

    render_handlebars(
        req,
        &handlebars,
        "blog-home",
        json!({
            "title": "All Posts",
            "posts": PostResponseModel::all(&posts, &users, &instructors),
        }),
        session,
    )
    .await
}

pub async fn get_post(
    req: HttpRequest,
    handlebars: web::Data<Handlebars<'_>>,
    mongoc: web::Data<Client>,
    path: web::Path<String>,
    session: actix_session::Session,
    cache: web::Data<Cache>,
) -> impl Responder {
    let permalink = path.into_inner();

    let post = match PostEntity::find_by_permalink(&mongoc, &permalink, &cache).await {
        Some(p) => p,
        None => {
            error!("Failed to find post");
            return HttpResponse::NotFound().body("Post not found");
        }
    };

    let instructor = InstructorResponseModel::from_google_id(&mongoc, &post.creator_id.to_string()).await.unwrap();

    debug!("Instructor: {:?}", instructor);

    let model = PostResponseModel::combine(&post, instructor.clone());

    let web_config: WebConfig = Environ::init();

    // find related posts belonging to the same tags
    let posts = PostEntity::scan(&mongoc, &cache).await.unwrap();
    // iterate through posts and find the ones with the same tags
    let tags: HashSet<&str> = post.tag.split(",").collect();
    let related_posts = posts
        .iter()
        .filter(|p| {
            let p_tags: HashSet<&str> = p.tag.split(",").collect();
            p_tags.intersection(&tags).count() > 0 && p._id != post._id
        })
        .take(4)
        .cloned()
        .collect::<Vec<PostEntity>>();

    // // find recommended posts from other tags
    // let recommended_posts = posts
    //     .iter()
    //     .filter(|p| {
    //         let p_tags: HashSet<&str> = p.tag.split(",").collect();
    //         p_tags.intersection(&tags).count() == 0 && p._id != post._id
    //     })
    //     .take(3)
    //     .cloned()
    //     .collect::<Vec<PostEntity>>();

    render_handlebars(
        req,
        &handlebars,
        "blog-post",
        json!({
            "title": model.title,
            "description":  model.description,
            "body": markdown_ops::to_html(&model.body),
            "model": model,
            "tldr": markdown_ops::to_html(&model.tldr),
            "hero_image": format!("{}{}", web_config.images_domain, model.hero_image),
            "profile_photo": format!("{}{}", web_config.images_domain, instructor.profile_photo),
            "instructor": instructor,
            "app_url": web_config.app_url,
            "show_booking": !post.tag.contains("high-school"),
            "related_posts": PostResponseModel::all(&related_posts, &UserEntity::scan(&mongoc).await.unwrap(), &InstructorEntity::scan(&mongoc).await.unwrap()),
            // "recommended_posts": PostResponseModel::all(&recommended_posts, &UserEntity::scan(&mongoc).await.unwrap(), &InstructorEntity::scan(&mongoc).await.unwrap()),
        }),
        session,
    )
    .await
}
