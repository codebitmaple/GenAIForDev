use aarya_entities::{course::course_entity::CourseEntity, instructor::entity::InstructorEntity, topic::topic_entity::TopicEntity, unit::unit_entity::UnitEntity};
use aarya_utils::{
    cache_ops,
    environ::{Environ, WebConfig},
    markdown_ops,
};
use actix_web::{web, HttpRequest, HttpResponse, Responder};
use handlebars::Handlebars;
use log::error;
use mongodb::Client;
use serde::{Deserialize, Serialize};
use serde_json::json;

use crate::html_renderer::render_handlebars;

pub async fn get_course_all(
    req: HttpRequest,
    mongoc: web::Data<Client>,
    handlebars: web::Data<Handlebars<'_>>,
    session: actix_session::Session,
    cache: web::Data<cache_ops::Cache>,
) -> impl Responder {
    render_handlebars(
        req,
        &handlebars,
        "course-all",
        json!({
            "title": "Courses",
            "description":  "All available courses",
            "model": (CourseEntity::scan(&mongoc, &cache).await).unwrap_or_default()
        }),
        session,
    )
    .await
}

pub async fn get_course(
    req: HttpRequest,
    mongoc: web::Data<Client>,
    handlebars: web::Data<Handlebars<'_>>,
    slug: web::Path<String>,
    session: actix_session::Session,
    cache: web::Data<cache_ops::Cache>,
) -> impl Responder {
    let slug = slug.into_inner();
    let web_config: WebConfig = Environ::init();

    let course = match CourseEntity::find_by_slug(&mongoc, &cache, slug).await {
        Some(course) => course,
        None => {
            return HttpResponse::NotFound().json(json!({"message": "Course not found"}));
        }
    };
    let units = match UnitEntity::find_by_course(&mongoc, &cache, &course._id.to_hex()).await {
        Some(units) => units,
        None => {
            return HttpResponse::NotFound().json(json!({"message": "Units not found"}));
        }
    };
    let instructors = match InstructorEntity::scan(&mongoc).await {
        Some(i) => i,
        None => {
            error!("Failed to find instructors");
            return HttpResponse::InternalServerError().body("Error finding instructors");
        }
    };

    render_handlebars(
        req,
        &handlebars,
        "course-home",
        json!({
            "title": course.name,
            "description":  course.meta_description,
            "course": course,
            "disclaimer": course.disclaimer.unwrap_or_default(),
            "intent": course.intent.unwrap_or_default(),
            "summary": markdown_ops::to_html(&course.summary),
            "units": units,
            "instructor": instructors.first().unwrap().to(),
            "app_url": web_config.app_url,
            "show_bookings": !course.tags.contains("high-school"),
        }),
        session,
    )
    .await
}

pub async fn get_unit(
    req: HttpRequest,
    mongoc: web::Data<Client>,
    handlebars: web::Data<Handlebars<'_>>,
    slug: web::Path<(String, String)>,
    session: actix_session::Session,
    cache: web::Data<cache_ops::Cache>,
) -> impl Responder {
    let slugs = slug.into_inner();
    let course_slug = slugs.0;
    let unit_slug = slugs.1;
    let unit = match UnitEntity::find_by_slug(&mongoc, &cache, unit_slug).await {
        Some(unit) => unit,
        None => {
            return HttpResponse::NotFound().json(json!({"message": "Unit not found"}));
        }
    };
    let topics = match TopicEntity::find_by_unit(&mongoc, &cache, &unit._id.to_hex()).await {
        Some(units) => units,
        None => {
            return HttpResponse::NotFound().json(json!({"message": "Topics not found"}));
        }
    };

    render_handlebars(
        req,
        &handlebars,
        "unit-home",
        json!({
            "title": unit.name,
            "description":  unit.description,
            "unit": unit,
            "topics": topics,
            "course_slug": course_slug
        }),
        session,
    )
    .await
}

#[derive(Serialize, Deserialize, Debug, Clone)]
pub struct TopicRecommendation {
    pub topic_name: String,
    pub summary: String,
    pub slug: String,
}

pub async fn get_topic(
    req: HttpRequest,
    mongoc: web::Data<Client>,
    handlebars: web::Data<Handlebars<'_>>,
    slug: web::Path<(String, String, String)>,
    session: actix_session::Session,
    cache: web::Data<cache_ops::Cache>,
) -> impl Responder {
    let slugs = slug.into_inner();
    let course_slug = slugs.0;
    let unit_slug = slugs.1;
    let topic_slug = slugs.2;

    let web_config: WebConfig = Environ::init();

    let course = match CourseEntity::find_by_slug(&mongoc, &cache, course_slug.clone()).await {
        Some(course) => course,
        None => {
            return HttpResponse::NotFound().json(json!({"message": "Course not found"}));
        }
    };

    let units = match UnitEntity::find_by_course(&mongoc, &cache, &course._id.to_hex()).await {
        Some(units) => units,
        None => {
            return HttpResponse::NotFound().json(json!({"message": "Units not found"}));
        }
    };

    let unit = units.iter().find(|u| u.slug == unit_slug).unwrap();

    let topics = match TopicEntity::find_by_unit(&mongoc, &cache, &unit._id.to_hex()).await {
        Some(units) => units,
        None => {
            return HttpResponse::NotFound().json(json!({"message": "Topics not found"}));
        }
    };

    let topics = topics.as_slice();

    let topic = topics.iter().find(|t| t.slug == topic_slug).unwrap();

    let prev_topic = topics
        .iter()
        .enumerate()
        .find(|(_, t)| t.slug == topic_slug)
        .map(|(i, _)| if i == 0 { topics.last().unwrap() } else { &topics[i - 1] })
        .unwrap();

    let next_topic = topics
        .iter()
        .enumerate()
        .find(|(_, t)| t.slug == topic_slug)
        .map(|(i, _)| if i == topics.len() - 1 { topics.first().unwrap() } else { &topics[i + 1] })
        .unwrap();

    let instructors = match InstructorEntity::scan(&mongoc).await {
        Some(i) => i,
        None => {
            error!("Failed to find instructors");
            return HttpResponse::InternalServerError().body("Error finding instructors");
        }
    };

    let recommendations = topics
        .iter()
        .filter(|t| t.slug != topic_slug)
        .map(|t| TopicRecommendation {
            slug: t.slug.clone(),
            topic_name: t.name.clone(),
            summary: t.meta_description.clone(),
        })
        .collect::<Vec<TopicRecommendation>>();

    let next_topic = TopicRecommendation {
        slug: next_topic.slug.clone(),
        topic_name: next_topic.name.clone(),
        summary: next_topic.meta_description.clone(),
    };

    let prev_topic = TopicRecommendation {
        slug: prev_topic.slug.clone(),
        topic_name: prev_topic.name.clone(),
        summary: prev_topic.meta_description.clone(),
    };

    // let unescaped_markdown = string_ops::unescape(&topic.markdown);
    // println!("Unescaped markdown: {}", unescaped_markdown);
    let markdown = markdown_ops::to_html(&topic.markdown);

    render_handlebars(
        req.clone(),
        &handlebars,
        "topic-home",
        json!({
            "title": topic.name,
            "description":  topic.meta_description,
            "topic": TopicEntity{markdown, ..topic.clone()},
            "course_slug": course_slug,
            "unit_slug": unit_slug,
            "topic_slug": topic.slug,
            "instructor": instructors.first().unwrap().to(),
            "app_url": web_config.app_url,
            "next_topic": next_topic,
            "prev_topic": prev_topic,
            "recommendations": recommendations,
            "courses": CourseEntity::scan(&mongoc, &cache).await.unwrap_or_default(),
            "units": units,
            "topics": topics,
            "show_bookings": topic.tags.contains(&"professional".to_string()),
        }),
        session,
    )
    .await
}
