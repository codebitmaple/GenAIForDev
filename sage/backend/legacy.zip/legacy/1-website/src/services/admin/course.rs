use std::{io::Cursor, str::FromStr};

use aarya_entities::{
    course::course_entity::{CourseEntity, CourseRequestModel},
    key_value::KeyValue,
};
use aarya_utils::{cache_ops, date_ops, file_ops, jwt_ops};
use actix_multipart::Multipart;
use actix_web::{web, HttpRequest, HttpResponse, Responder};
use futures::{StreamExt, TryStreamExt};
use handlebars::Handlebars;
use log::debug;
use mongodb::{bson::oid::ObjectId, Client};
use serde::{Deserialize, Serialize};
use serde_json::json;

use crate::html_renderer::render_handlebars;

// Request payload structure for creating a course

// Struct to represent a product and price response
#[derive(Serialize, Deserialize, Debug, Clone)]
pub struct ProductPriceResponse {
    pub product_name: String,
    pub price: f32,
    pub currency: String,
    pub stripe_product_id: String,
    pub stripe_price_id: String,
}

// Struct for response that includes course details and product-price pairs
#[derive(Serialize, Deserialize, Debug, Clone)]
pub struct CreateCourseResponse {
    pub course_id: String,
    pub course_name: String,
    pub products: Vec<ProductPriceResponse>,
}

#[derive(Serialize, Deserialize, Debug, Clone)]
pub struct CourseResponseModel {
    pub id: String,
    pub name: String,
    pub meta_description: String,
    pub summary: String,
    pub slug: String,
}

impl From<CourseEntity> for CourseResponseModel {
    fn from(course: CourseEntity) -> Self {
        CourseResponseModel {
            id: course._id.to_hex(),
            name: course.name,
            meta_description: course.meta_description,
            summary: course.summary,
            slug: course.slug,
        }
    }
}

#[derive(Debug, Serialize, Deserialize)]
pub struct CourseEditModel {
    pub name: String,
    pub meta_description: String,
    pub summary: String,
    pub tags: String,
    pub metadata: Vec<KeyValue>,
    pub disclaimer: Option<String>,
    pub intent: Option<String>,
    pub slug: String,
    pub restricted_words: Option<Vec<String>>,
    pub created_at: i64,
}

impl From<CourseEntity> for CourseEditModel {
    fn from(entity: CourseEntity) -> Self {
        CourseEditModel {
            name: entity.name,
            meta_description: entity.meta_description,
            summary: entity.summary,
            metadata: entity.metadata,
            disclaimer: entity.disclaimer,
            intent: entity.intent,
            restricted_words: entity.restricted_words,
            slug: entity.slug,
            created_at: entity.created,
            tags: entity.tags,
        }
    }
}

pub async fn get_create_course(
    req: HttpRequest,
    handlebars: web::Data<Handlebars<'_>>,
    session: actix_session::Session,
) -> impl Responder {
    render_handlebars(
        req,
        &handlebars,
        "course-create",
        json!({
            "title": "Create a New Course",
            "schema": file_ops::read_file("./assets/schema/course-schema.json").unwrap()
        }),
        session,
    )
    .await
}

pub async fn get_course_edit(
    req: HttpRequest,
    handlebars: web::Data<Handlebars<'_>>,
    mongoc: web::Data<Client>,
    path: web::Path<String>,
    session: actix_session::Session,
    cache: web::Data<cache_ops::Cache>,
) -> impl Responder {
    let course_id = path.into_inner();
    let course = CourseEntity::find_by_id(&mongoc, &cache, course_id.clone()).await.unwrap();

    render_handlebars(
        req,
        &handlebars,
        "course-edit",
        json!({
            "title": "Edit a Course",
            "schema": file_ops::read_file("./assets/schema/course-schema.json").unwrap(),
            "course": course,
            "course_id": course_id,
        }),
        session,
    )
    .await
}

pub async fn post_course_download_template() -> impl Responder {
    let post = CourseRequestModel::default();
    HttpResponse::Ok()
        .content_type("application/json")
        .insert_header(("Content-Disposition", "attachment; filename=\"course-template.json\"".to_string()))
        .body(serde_json::to_string(&post).unwrap())
}

pub async fn post_download_course_json(
    mongoc: web::Data<Client>,
    path: web::Path<String>,
    cache: web::Data<cache_ops::Cache>,
) -> impl Responder {
    let course_id = path.into_inner();
    let course = CourseEntity::find_by_id(&mongoc, &cache, course_id.clone()).await.unwrap();
    let model = CourseEditModel::from(course);
    HttpResponse::Ok()
        .content_type("application/json")
        .insert_header(("Content-Disposition", format!("attachment; filename=\"course-edit-template-{}.json\"", course_id)))
        .body(serde_json::to_string(&model).unwrap())
}

pub async fn put_upload_course(
    mongoc: web::Data<Client>,
    mut payload: Multipart,
    cache: web::Data<cache_ops::Cache>,
) -> impl Responder {
    let (courses, course_id, creator_id) = match course_edit_from_payload(&mut payload).await {
        Ok(value) => value,
        Err(value) => return value,
    };

    edit_course(&courses, creator_id, course_id.as_str(), &mongoc, &cache).await;

    HttpResponse::Ok().json(json! {{
        "message": "Course updated successfully"
    }})
}

pub async fn post_upload_course(
    req: HttpRequest,
    mongoc: web::Data<Client>,
    mut payload: Multipart,
    cache: web::Data<cache_ops::Cache>,
) -> impl Responder {
    // Step 1: Create the initial course entity
    let new_course = match course_from_payload(&mut payload).await {
        Ok(course_data) => create_course_entity(&course_data, jwt_ops::get_user_key_from(&req).unwrap_or_default()).await,
        Err(err) => return HttpResponse::BadRequest().json(json!({ "error": format!("{:?}", err) })),
    };

    // Step 1.1: if the course already exists, return an error
    if new_course.exists(&mongoc, &cache).await {
        return HttpResponse::BadRequest().json(json!({ "error": "Course already exists" }));
    }

    // // Step 2: Create products and prefix names with the course slug
    // let mut products = CourseFactory::create_products(&new_course);
    // prefix_product_names(&new_course.slug, &mut products);

    let new_course = CourseEntity {
        _id: ObjectId::new(),
        creator_id: jwt_ops::get_user_key_from(&req).unwrap_or_default(),
        ..new_course
    };

    new_course.create(&mongoc, &cache).await.unwrap_or_default();

    debug!("Course created: {:?}", new_course);
    // debug!("Products : {:?}", products);

    // let http_client = HttpClient::new();

    // let result = match handle_stripe_product_and_price_creation(new_course._id.to_hex().as_str(), &products, &http_client).await {
    //     Ok(responses) => responses,
    //     Err(err) => return HttpResponse::InternalServerError().body(err),
    // };

    // for v in result {
    //     debug!("Product: {:?}", v.0);
    //     let product = v.0;
    //     product.create(&mongoc).await.unwrap_or_default();
    //     debug!("Price: {:?}", v.1);
    //     let price = v.1;
    //     price.create(&mongoc).await.unwrap_or_default();
    // }

    HttpResponse::Ok().json(new_course)
}

pub async fn get_course_list(
    req: HttpRequest,
    handlebars: web::Data<Handlebars<'_>>,
    mongoc: web::Data<Client>,
    session: actix_session::Session,
    cache: web::Data<cache_ops::Cache>,
) -> impl Responder {
    let courses = CourseEntity::scan(&mongoc, &cache).await.unwrap_or_default();
    let model = courses.into_iter().map(|c| c.into()).collect::<Vec<CourseResponseModel>>();
    render_handlebars(
        req,
        &handlebars,
        "course-list",
        json!({
            "title": "List of Courses",
            "description": "All available Courses",
            "courses": model,
            "courses_empty": model.is_empty(),
        }),
        session,
    )
    .await
}

async fn course_from_payload(payload: &mut Multipart) -> Result<CourseRequestModel, HttpResponse> {
    let mut file_data = Vec::new();
    while let Ok(Some(mut field)) = payload.try_next().await {
        let content_disposition = field.content_disposition();

        // Check the name of the field (file or course_id)
        if let Some("file") = content_disposition.get_name() {
            // If it's the file field, read the file into memory
            while let Some(chunk) = field.next().await {
                let data = chunk.unwrap();
                file_data.extend_from_slice(&data);
            }
        }
    }
    let course: CourseRequestModel = match serde_json::from_reader(Cursor::new(file_data)) {
        Ok(data) => data, // insert into database (use course_id and creator_id)
        Err(err) => {
            println!("Failed to parse JSON: {:?}", err);
            return Err(HttpResponse::BadRequest().body("Invalid JSON file"));
        }
    };
    Ok(course)
}

async fn course_edit_from_payload(payload: &mut Multipart) -> Result<(CourseEditModel, String, String), HttpResponse> {
    let mut file_data = Vec::new();
    let mut course_id = None;
    let mut creator_id = None;
    while let Ok(Some(mut field)) = payload.try_next().await {
        let content_disposition = field.content_disposition();

        // Check the name of the field (file or course_id)
        if let Some("file") = content_disposition.get_name() {
            // If it's the file field, read the file into memory
            while let Some(chunk) = field.next().await {
                let data = chunk.unwrap();
                file_data.extend_from_slice(&data);
            }
        } else if let Some("course_id") = content_disposition.get_name() {
            let mut course_data = Vec::new();
            while let Some(chunk) = field.next().await {
                let data = chunk.unwrap();
                course_data.extend_from_slice(&data);
            }
            course_id = Some(String::from_utf8(course_data).unwrap());
        } else if let Some("creator_id") = content_disposition.get_name() {
            let mut course_data = Vec::new();
            while let Some(chunk) = field.next().await {
                let data = chunk.unwrap();
                course_data.extend_from_slice(&data);
            }
            creator_id = Some(String::from_utf8(course_data).unwrap());
        }
    }
    let course: CourseEditModel = match serde_json::from_reader(Cursor::new(file_data)) {
        Ok(data) => data, // insert into database (use course_id and creator_id)
        Err(err) => {
            println!("Failed to parse JSON: {:?}", err);
            return Err(HttpResponse::BadRequest().body("Invalid JSON file"));
        }
    };
    Ok((course, course_id.unwrap(), creator_id.unwrap()))
}

// Step 1: Function to create the initial course entity
async fn create_course_entity(
    input: &CourseRequestModel,
    creator_id: String,
) -> CourseEntity {
    CourseEntity {
        _id: ObjectId::new(), // Generate a new ObjectId
        name: input.name.clone(),
        meta_description: input.meta_description.clone(),
        created: date_ops::to_timestamp(), // Assume a helper function for current timestamp
        updated: date_ops::to_timestamp(),
        active: true,
        creator_id,
        disclaimer: input.disclaimer.clone(),
        intent: input.intent.clone(),
        restricted_words: input.restricted_words.clone(),
        slug: input.slug.clone(),
        metadata: input.metadata.clone(),
        summary: input.summary.clone(),
        tags: input.tags.clone(),
    }
}

async fn edit_course(
    input: &CourseEditModel,
    creator_id: String,
    course_id: &str,
    mongoc: &mongodb::Client,
    cache: &cache_ops::Cache,
) -> CourseEntity {
    let course = CourseEntity {
        _id: ObjectId::from_str(course_id).unwrap(),
        name: input.name.clone(),
        meta_description: input.meta_description.clone(),
        created: input.created_at,
        updated: date_ops::to_timestamp(),
        active: true,
        creator_id,
        disclaimer: input.disclaimer.clone(),
        intent: input.intent.clone(),
        restricted_words: input.restricted_words.clone(),
        slug: input.slug.clone(),
        metadata: input.metadata.clone(),
        summary: input.summary.clone(),
        tags: "tags".to_string(),
    };

    course.update(mongoc, cache).await.unwrap_or_default();

    course
}

// // Step 2: Function to prefix product names with the course slug
// fn prefix_product_names(
//     course_slug: &str,
//     products: &mut Vec<ProductEntity>,
// ) {
//     for product in products {
//         product.display_name = format!("{}-{}", course_slug, product.display_name).to_lowercase();
//     }
// }

// // Step 3: Function to handle both product and price creation in Stripe
// async fn handle_stripe_product_and_price_creation(
//     course_id: &str,
//     products: &Vec<ProductEntity>,
//     http_client: &HttpClient,
// ) -> Result<Vec<(ProductEntity, PriceEntity)>, String> {
//     let mut product_price_responses = vec![];
//     let mut futures = Vec::new();

//     for product in products {
//         let product_clone = product.clone();
//         let http_client = http_client.clone();

//         // Call the async task that will create a product and its price in Stripe
//         let task = async move {
//             match create_stripe_product(&product_clone, &http_client).await {
//                 Ok(stripe_product_resp) => {
//                     let new_product = ProductEntity {
//                         _id: ObjectId::new(),
//                         stripe_id: Some(stripe_product_resp.id.clone()),
//                         course_id: course_id.to_string(),
//                         ..product_clone.clone()
//                     };
//                     let price_response = create_stripe_price(&product_clone, &stripe_product_resp.id, &http_client).await;
//                     match price_response {
//                         Ok(price_resp) => {
//                             let new_price = PriceEntity {
//                                 _id: ObjectId::new(),
//                                 stripe_id: Some(price_resp.id.clone()),
//                                 product_id: new_product._id.to_hex(),
//                                 unit_amount_cents: price_resp.unit_amount,
//                                 currency: price_resp.currency,
//                                 ..Default::default()
//                             };
//                             Ok((new_product, new_price))
//                         }
//                         Err(err) => {
//                             error!("Error: Failed to create Stripe price {:?}", err);
//                             Err(format!("Failed to create Stripe price for {}", product_clone.display_name))
//                         }
//                     }
//                 }
//                 Err(err) => {
//                     error!("Error: Failed to create Stripe product {:?}", err);
//                     Err(format!("Failed to create Stripe product for {}", product_clone.display_name))
//                 }
//             }
//         };

//         futures.push(task);
//     }

//     let results = join_all(futures).await;

//     // Collect all successful product price responses
//     for res in results {
//         match res {
//             Ok(response) => product_price_responses.push(response),
//             Err(err) => return Err(err), // If any task fails, return the error
//         }
//     }

//     Ok(product_price_responses)
// }

// // Sub-function to create a product in Stripe
// async fn create_stripe_product(
//     product: &ProductEntity,
//     http_client: &HttpClient,
// ) -> Result<StripeProductResponse, String> {
//     let stripe_config: StripeConfig = Environ::init();
//     let product_url = format!("{}/product/create", stripe_config.stripe_local_server);
//     debug!("Product URL: {}", product_url);

//     let stripe_product_req = StripeProductRequest { name: product.display_name.clone() };

//     debug!("Creating Stripe product for {}", product.display_name);

//     match http_client.post(product_url).json(&stripe_product_req).send().await {
//         Ok(response) => match response.json::<StripeProductResponse>().await {
//             Ok(stripe_product_resp) => Ok(stripe_product_resp),
//             Err(e) => {
//                 error!("Error: Failed to create Stripe product {:?}", e);
//                 Err(format!("Failed to create Stripe product for {}", product.display_name))
//             }
//         },
//         Err(e) => {
//             error!("Error: Failed to create Stripe product {:?}", e);
//             Err(format!("Failed to create Stripe product for {}", product.display_name))
//         }
//     }
// }

// // Sub-function to create a price in Stripe
// async fn create_stripe_price(
//     product: &ProductEntity,
//     product_id: &str,
//     http_client: &HttpClient,
// ) -> Result<StripePricingResponse, String> {
//     let stripe_config: StripeConfig = Environ::init();
//     let prices_url = format!("{}/price/create", stripe_config.stripe_local_server);
//     debug!("Prices URL: {}", prices_url);

//     let price_builder = PriceFactory::create_builder(product);
//     let price = price_builder.build();

//     debug!("Creating price for product: {:?}", product);
//     debug!("Price: {:?}", price);

//     let stripe_price_req = StripePricingRequest {
//         product_id: product_id.to_string(),
//         currency: price.currency.clone(),
//         unit_amount: price.unit_amount_cents, // Stripe expects price in cents
//     };

//     match http_client.post(prices_url).json(&stripe_price_req).send().await {
//         Ok(response) => {
//             if response.status().is_success() {
//                 Ok(response.json::<StripePricingResponse>().await.unwrap_or_default())
//             } else {
//                 warn!("Failed to create Stripe price for {}", product.display_name);
//                 Err(format!("Failed to create Stripe price for {}", product.display_name))
//             }
//         }
//         Err(e) => {
//             error!("Error: Failed to create Stripe price {:?}", e);
//             Err(format!("Failed to create Stripe price for {}", product.display_name))
//         }
//     }
// }
