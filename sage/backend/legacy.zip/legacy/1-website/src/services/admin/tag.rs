// use aarya_entities::{
//     models::req_res::{TagRequestModel, TagResponseModel},
//     tag::TagEntity,
// };
// use aarya_utils::{
//     cache_ops::Cache,
//     db_ops::{self, Database},
//     file_ops,
//     json_ops::{self, JsonOpsResult},
//     result_types::EntityResult,
// };
// use actix_web::{web, HttpRequest, HttpResponse, Responder};

// use handlebars::Handlebars;
// use log::{debug, error, info};
// use mongodb::Client;
// use serde_json::json;

// use crate::html_renderer::render_handlebars;

// pub async fn get_create_tag(
//     req: HttpRequest,
//     cache: web::Data<Cache>,
//     handlebars: web::Data<Handlebars<'_>>,
// ) -> impl Responder {
//     render_handlebars(
//         req,
//         &cache,
//         &handlebars,
//         "tag-create",
//         json!({
//             "title": "Add a new Tag",
//             "schema": file_ops::read_file("./assets/schema/tag-schema.json").unwrap()
//         }),
//     )
//     .await
// }

// pub async fn get_tag_list(
//     req: HttpRequest,
//     cache: web::Data<Cache>,
//     handlebars: web::Data<Handlebars<'_>>,
//     mongoc: web::Data<Client>,
// ) -> impl Responder {
//     let collection = Database::get_collection(&mongoc, "tags");
//     match db_ops::Database::find_all::<TagEntity>(collection).await {
//         EntityResult::Success(r) => {
//             debug!("{:?}", r);
//             render_handlebars(
//                 req,
//                 &cache,
//                 &handlebars,
//                 "tag-list",
//                 json!({
//                     "title": "All Tags",
//                     "tags": TagResponseModel::from_vec(r)
//                 }),
//             )
//             .await
//         }
//         EntityResult::Error(e) => {
//             error!("Failed to list tags: {:?}", e);
//             HttpResponse::InternalServerError().body("Error listing tags")
//         }
//     }
// }

// pub async fn get_edit_tag(
//     req: HttpRequest,
//     cache: web::Data<Cache>,
//     handlebars: web::Data<Handlebars<'_>>,
//     mongoc: web::Data<Client>,
//     path: web::Path<String>,
// ) -> impl Responder {
//     let tag_id = path.into_inner();
//     let collection = Database::get_collection(&mongoc, "tags");
//     match db_ops::Database::find::<TagEntity>(collection, &tag_id).await {
//         EntityResult::Success(r) => {
//             debug!("{:?}", r);
//             render_handlebars(
//                 req,
//                 &cache,
//                 &handlebars,
//                 "tag-edit",
//                 json!({
//                     "title": "Edit Tag",
//                     "tag": TagResponseModel::from(r),
//                     "schema": file_ops::read_file("./assets/schema/tag-schema.json").unwrap()
//                 }),
//             )
//             .await
//         }
//         EntityResult::Error(e) => {
//             error!("Failed to find tag: {:?}", e);
//             HttpResponse::BadRequest().body("Error finding tag")
//         }
//     }
// }

// pub async fn post_create_tag(
//     model: web::Json<TagRequestModel>,
//     mongoc: web::Data<Client>,
// ) -> impl Responder {
//     debug!("{:?}", model);

//     match json_ops::validate_json_text("./assets/schema/tag-schema.json", serde_json::to_string(&model).unwrap().as_str()) {
//         JsonOpsResult::Success(_) => {
//             let collection = Database::get_collection(&mongoc, "tags");
//             match db_ops::Database::create(&collection, &model.to()).await {
//                 EntityResult::Success(r) => {
//                     info!("Tag created {:?}", r);
//                     HttpResponse::Ok().body("Tag created")
//                 }
//                 EntityResult::Error(e) => {
//                     error!("Failed to create tag: {:?}", e);
//                     HttpResponse::BadRequest().body("Error creating tag")
//                 }
//             }
//         }
//         JsonOpsResult::Error(e) => {
//             error!("Failed to validate tag: {:?}", e);
//             HttpResponse::BadRequest().body("Error validating tag")
//         }
//     }
// }

// pub async fn post_edit_tag(
//     mongoc: web::Data<Client>,
//     path: web::Path<String>,
//     model: web::Json<TagRequestModel>,
// ) -> impl Responder {
//     let tag_id = path.into_inner();
//     debug!("{:?}", model);

//     match json_ops::validate_json_text("./assets/schema/tag-schema.json", serde_json::to_string(&model).unwrap().as_str()) {
//         JsonOpsResult::Success(_) => {
//             let collection = Database::get_collection(&mongoc, "tags");
//             match Database::update(&collection, &model.to(), &tag_id).await {
//                 EntityResult::Success(r) => {
//                     info!("Tag updated {:?}", r);
//                     HttpResponse::Ok().body("Tag updated")
//                 }
//                 EntityResult::Error(e) => {
//                     error!("Failed to update tag: {:?}", e);
//                     HttpResponse::BadRequest().body("Error updating tag")
//                 }
//             }
//         }
//         JsonOpsResult::Error(e) => {
//             error!("Failed to validate tag: {:?}", e);
//             HttpResponse::BadRequest().body("Error validating tag")
//         }
//     }
// }
