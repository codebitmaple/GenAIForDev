// use aarya_entities::{
//     instructor::{InstructorEntity, InstructorResponseModel},
//     models::req_res::AuthorRequestModel,
// };
// use aarya_utils::{
//     cache_ops::Cache,
//     db_ops::Database,
//     file_ops,
//     json_ops::{self, JsonOpsResult},
//     result_types::EntityResult,
// };
// use actix_web::{web, HttpRequest, HttpResponse, Responder};

// use handlebars::Handlebars;
// use log::{debug, error, info};
// use mongodb::Client;
// use serde_json::json;

// use crate::html_renderer::render_handlebars;

// pub async fn get_create_instructor(
//     req: HttpRequest,
//     cache: web::Data<Cache>,
//     handlebars: web::Data<Handlebars<'_>>,
// ) -> impl Responder {
//     render_handlebars(
//         req,
//         &cache,
//         &handlebars,
//         "instructor-create",
//         json!({
//             "title": "Add a new Author",
//             "schema": file_ops::read_file("./assets/schema/instructor-schema.json").unwrap()
//         }),
//     )
//     .await
// }

// pub async fn get_instructor_list(
//     req: HttpRequest,
//     cache: web::Data<Cache>,
//     handlebars: web::Data<Handlebars<'_>>,
//     mongoc: web::Data<Client>,
// ) -> impl Responder {
//     debug!("Listing instructors");
//     let collection = Database::get_collection(&mongoc, "instructors");
//     match Database::find_all::<InstructorEntity>(collection).await {
//         EntityResult::Success(r) => {
//             debug!("{:?}", r);
//             render_handlebars(
//                 req,
//                 &cache,
//                 &handlebars,
//                 "instructor-list",
//                 json!({
//                     "title": "All Authors",
//                     "instructors": InstructorResponseModel::from_vec(r)
//                 }),
//             )
//             .await
//         }
//         EntityResult::Error(e) => {
//             error!("Failed to list instructor: {:?}", e);
//             HttpResponse::InternalServerError().body("Error listing instructors")
//         }
//     }
// }

// pub async fn get_edit_instructor(
//     req: HttpRequest,
//     cache: web::Data<Cache>,
//     handlebars: web::Data<Handlebars<'_>>,
//     mongoc: web::Data<Client>,
//     path: web::Path<String>,
// ) -> impl Responder {
//     let instructor_id = path.into_inner();
//     let instructor = match InstructorEntity::find(&mongoc, &instructor_id).await {
//         EntityResult::Success(r) => r,
//         EntityResult::Error(e) => {
//             error!("Failed to find instructor: {:?}", e);
//             return HttpResponse::BadRequest().body("Error finding instructor");
//         }
//     };

//     debug!("{:?}", instructor);
//     render_handlebars(
//         req,
//         &cache,
//         &handlebars,
//         "instructor-edit",
//         json!({
//             "title": "Edit Author",
//             "instructor": InstructorResponseModel::from(instructor),
//             "schema": file_ops::read_file("./assets/schema/instructor-schema.json").unwrap()
//         }),
//     )
//     .await
// }

// pub async fn post_create_instructor(
//     model: web::Json<AuthorRequestModel>,
//     mongoc: web::Data<Client>,
// ) -> impl Responder {
//     debug!("{:?}", model);

//     match json_ops::validate_json_text("./assets/schema/instructor-schema.json", serde_json::to_string(&model).unwrap().as_str()) {
//         JsonOpsResult::Success(_) => match model.to().create(&mongoc).await {
//             EntityResult::Success(r) => {
//                 info!("Instructor created {:?}", r);
//                 HttpResponse::Ok().body("Instructor created")
//             }
//             EntityResult::Error(e) => {
//                 error!("Failed to create instructor: {:?}", e);
//                 HttpResponse::BadRequest().body("Error creating instructor")
//             }
//         },
//         JsonOpsResult::Error(e) => {
//             error!("Failed to validate instructor: {:?}", e);
//             HttpResponse::BadRequest().body("Error validating instructor")
//         }
//     }
// }

// pub async fn post_edit_instructor(
//     mongoc: web::Data<Client>,
//     path: web::Path<String>,
//     model: web::Json<AuthorRequestModel>,
// ) -> impl Responder {
//     let author_id = path.into_inner();
//     debug!("{:?}", model);

//     match json_ops::validate_json_text("./assets/schema/instructor-schema.json", serde_json::to_string(&model).unwrap().as_str()) {
//         JsonOpsResult::Success(_) => match model.to().update(&mongoc, &author_id).await {
//             EntityResult::Success(r) => {
//                 info!("Instructor updated {:?}", r);
//                 HttpResponse::Ok().body("Instructor updated")
//             }
//             EntityResult::Error(e) => {
//                 error!("Failed to update instructor: {:?}", e);
//                 HttpResponse::BadRequest().body("Error updating instructor")
//             }
//         },
//         JsonOpsResult::Error(e) => {
//             error!("Failed to validate instructor: {:?}", e);
//             HttpResponse::BadRequest().body("Error validating instructor")
//         }
//     }
// }
