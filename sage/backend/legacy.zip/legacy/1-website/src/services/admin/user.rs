use aarya_entities::user::UserEntity;
use actix_web::{web, HttpRequest, Responder};
use handlebars::Handlebars;
use serde_json::json;

use crate::html_renderer::render_handlebars;

pub async fn get_user_list(
    req: HttpRequest,
    handlebars: web::Data<Handlebars<'_>>,
    session: actix_session::Session,
    mongoc: web::Data<mongodb::Client>,
) -> impl Responder {
    render_handlebars(
        req,
        &handlebars,
        "user-list",
        json!({
            "title": "All Users",
            "users": UserEntity::scan(&mongoc).await.unwrap(),
        }),
        session,
    )
    .await
}

pub async fn post_users_download(mongoc: web::Data<mongodb::Client>) -> impl Responder {
    let users = UserEntity::scan(&mongoc).await.unwrap();
    let mut csv = String::new();
    csv.push_str("email,full_name\n");
    for user in users {
        csv.push_str(&format!("{},{}\n", user.email, user.full_name));
    }
    actix_web::HttpResponse::Ok().content_type("text/csv").body(csv)
}
