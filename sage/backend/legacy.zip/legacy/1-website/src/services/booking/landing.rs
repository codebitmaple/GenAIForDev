use aarya_entities::{
    booking::{BookingEntity, BookingStatus},
    instructor::entity::InstructorEntity,
};
use aarya_utils::cache_ops::Cache;
use actix_web::{web, HttpResponse, Responder};

use log::{debug, error};
use mongodb::Client;

use crate::auth::user::UserAuth;

pub async fn get_details_page(
    cache: web::Data<Cache>,
    mongoc: web::Data<Client>,
    session: actix_session::Session,
) -> impl Responder {
    let instructors = InstructorEntity::scan(&mongoc).await.unwrap();
    let instructor_id = instructors.first().unwrap().user_id.clone();
    let user_auth = UserAuth::from(session);

    let user_key = match user_auth.user_key {
        Some(id) => id,
        None => {
            error!("Failed to get user key from session");
            return HttpResponse::InternalServerError().finish();
        }
    };
    debug!("User Key: {}", user_key);
    let student = match user_auth.google_model {
        Some(user) => user,
        None => {
            error!("Failed to get user from session");
            return HttpResponse::InternalServerError().finish();
        }
    };
    debug!("Student: {:?}, Instructor: {}", student, instructor_id);
    let booking = BookingEntity {
        student_id: student.id,
        instructor_id,
        status: BookingStatus::Init,
        ..Default::default()
    };

    match booking.add_new(&mongoc).await {
        Some(b) => b,
        None => {
            error!("Failed to create a new booking");
            return HttpResponse::InternalServerError().finish();
        }
    };

    debug!("New booking created: {:?}", &booking);
    let booking_id = booking.clone()._id.unwrap().to_hex();
    cache.set_scalar(format!("{}-{}", booking.student_id, booking.instructor_id), String::from("blog-post"));
    cache.set_json(booking_id.as_str(), &booking);
    HttpResponse::Found().append_header(("location", format!("/booking/details/{}", booking_id))).finish()
}
