use aarya_entities::{booking::BookingEntity, models::google::GoogleUserModel};
use aarya_utils::{cache_ops::Cache, jwt_ops};
use actix_web::{web, HttpRequest, HttpResponse, Responder};

use log::{debug, error};
use mongodb::Client;

pub async fn get_init_booking(
    req: HttpRequest,
    cache: web::Data<Cache>,
    mongoc: web::Data<Client>,
    path: web::Path<String>,
) -> impl Responder {
    let instructor_id = path.into_inner();
    let user_key = match jwt_ops::get_user_key_from(&req) {
        Some(id) => id,
        None => {
            error!("Failed to get user key from request");
            return HttpResponse::InternalServerError().finish();
        }
    };
    debug!("User Key: {}", user_key);
    let student = match cache.get_json::<GoogleUserModel>(&user_key) {
        Some(user) => user,
        None => {
            error!("Failed to get user from cache");
            return HttpResponse::InternalServerError().finish();
        }
    };
    debug!("Student: {:?}, Instructor: {}", student, instructor_id);
    let booking = BookingEntity {
        student_id: student.id,
        instructor_id,
        ..Default::default()
    };

    match booking.add_new(&mongoc).await {
        Some(b) => b,
        None => {
            error!("Failed to create a new booking");
            return HttpResponse::InternalServerError().finish();
        }
    };

    debug!("New booking created: {:?}", &booking);
    let booking_id = booking.clone()._id.unwrap().to_hex();
    cache.set_scalar(format!("{}-{}", booking.student_id, booking.instructor_id), String::from("blog-post"));
    cache.set_json(booking_id.as_str(), &booking);
    HttpResponse::Found().append_header(("location", format!("/booking/details/{}", booking_id))).finish()
}
