use aarya_entities::{
    booking::{BookingEntity, BookingStatus},
    instructor::entity::InstructorEntity,
    models::google::GoogleUserModel,
    payment::{PaymentEntity, PaymentStatus},
    pricing::{
        pricing_entity::PricingEntity,
        stripe_checkout::{CheckoutRequest, CheckoutResponse, Product},
    },
};
use aarya_utils::{
    cache_ops::Cache,
    date_ops,
    db_ops::Database,
    environ::{Environ, StripeConfig, WebConfig},
    jwt_ops,
    result_types::EntityResult,
};
use actix_web::{web, HttpRequest, HttpResponse, Responder};
use handlebars::Handlebars;
use log::{debug, error, info};
use mongodb::{bson::doc, Client};
use serde_json::json;

use crate::html_renderer::render_handlebars;

pub async fn get_checkout_with_reload(path: web::Path<String>) -> impl Responder {
    let booking_id = path.into_inner();
    HttpResponse::Ok().body(format!(
        r#"
                    <html>
                    <body>
                        <p>Login successful. Redirecting...</p>
                        <script>
                            // Automatically redirect the browser to the desired route
                            window.location.href = "/booking/checkout/{}";
                        </script>
                    </body>
                    </html>
                "#,
        booking_id
    ))
}

pub async fn get_checkout(
    req: HttpRequest,
    mongoc: web::Data<Client>,
    cache: web::Data<Cache>,
    handlebars: web::Data<Handlebars<'_>>,
    path: web::Path<String>,
    session: actix_session::Session,
) -> impl Responder {
    let booking_id = path.into_inner();
    let user_key = match jwt_ops::get_user_key_from(&req) {
        Some(id) => id,
        None => {
            error!("Failed to get user key from request");
            return HttpResponse::InternalServerError().json(json!({"error": "Failed to get user key from request"}));
        }
    };
    debug!("User Key: {}", user_key);
    let student = match cache.get_json::<GoogleUserModel>(&user_key) {
        Some(user) => user,
        None => {
            error!("Failed to get user from cache");
            return HttpResponse::InternalServerError().json(json!({"error": "Failed to get user from cache"}));
        }
    };

    // retrieve booking from the database
    let bookings = BookingEntity::get_collection(&mongoc);
    let booking = match Database::find::<BookingEntity>(bookings.clone(), &booking_id).await {
        EntityResult::Success(r) => {
            info!("Retrieved booking {:?}", r);
            r
        }
        EntityResult::Error(e) => {
            error!("Failed to find booking: {:?}", e);
            return HttpResponse::NotFound().json(json!({"error": "Failed to find booking"}));
        }
    };

    booking.set_status(&mongoc, &BookingStatus::Checkout).await;

    // retrieve instructor name from the database
    let instructor = match InstructorEntity::filter(&mongoc, doc! {"user_id": booking.instructor_id.clone()}).await {
        Some(i) => i.first().unwrap().clone(),
        None => {
            error!("Failed to find instructor");
            return HttpResponse::NotFound().body("Instructor not found");
        }
    };

    debug!("Booking: {:?}", booking);

    let source = cache.get_scalar::<String>(format!("{}-{}", booking.student_id, booking.instructor_id).as_str()).unwrap();
    debug!("Source: {}", source);

    let pricing_info = booking.get_pricing_info(source.as_str()).unwrap();
    debug!("Pricing Info: {:?}", pricing_info);

    let count = match booking.appointment.clone() {
        Some(appointment) => appointment.time_slots.len() as u32,
        None => 0,
    };
    debug!("Count: {}", count);

    let price_breakup = match PricingEntity::calculate(&pricing_info.pricing_type, &pricing_info.pricing_category, count, None) {
        Ok(r) => r,
        Err(e) => {
            error!("Failed to calculate payable amount: {:?}", e);
            return HttpResponse::BadRequest().json(json!({"error": "Failed to calculate payable amount"}));
        }
    };

    let web_config: WebConfig = Environ::init();
    let stripe_config: StripeConfig = Environ::init();

    let checkout_args = CheckoutRequest {
        product_data: Product {
            name: PricingEntity::determine_product_name(pricing_info.pricing_type, pricing_info.pricing_category, None).unwrap().name,
        },
        payment_method_types: Some(vec![String::from("card")]),
        currency: Some(String::from("usd")),
        price_in_cents: Some((price_breakup.amount * 100.0) as u32),
        quantity: Some(1),
        mode: Some(String::from("payment")),
        success_url: format!("{}/payment-successful/{}/reload", web_config.allowed_origin, booking_id),
        cancel_url: format!("{}/booking/checkout/{}/reload", web_config.allowed_origin, booking_id),
        customer_email: student.email,
    };

    // calling Aarya stripe server to create a checkout session
    let http_client = reqwest::Client::new();
    let response = http_client.post(format!("{}/session/checkout", stripe_config.stripe_local_server)).json(&checkout_args).send();

    match response.await {
        Ok(r) => match r.json::<CheckoutResponse>().await {
            Ok(res) => {
                let payment = PaymentEntity {
                    booking_id: booking_id.clone(),
                    status: PaymentStatus::Initiated,
                    timestamp: date_ops::to_timestamp(),
                    amount: price_breakup.amount,
                    currency: String::from("usd"),
                    stripe_checkout_id: Some(res.checkout_id),
                    livemode: Some(res.livemode),
                    ..Default::default()
                };

                match payment.upsert(&mongoc).await {
                    EntityResult::Success(_) => info!("Payment initiated"),
                    EntityResult::Error(e) => {
                        error!("Failed to initiate payment: {:?}", e);
                        return HttpResponse::InternalServerError().json(json!({"error": "Failed to initiate payment"}));
                    }
                }

                render_handlebars(
                    req.clone(),
                    &handlebars,
                    "checkout",
                    json!({
                        "title": "Checkout",
                        "learner_name": student.given_name,
                        "educator_name": instructor.first_name,
                        "booking": booking,
                        "time_slots": booking.appointment.as_ref().map(|appointment| {
                            appointment.format_time_slots().iter().map(|slot| {
                                json!({
                                    "date": slot,
                                })
                            }).collect::<Vec<_>>()
                        }),
                        "amount_payable": price_breakup.amount,
                        "payment_breakup": price_breakup,
                        "description":  "Proceed to payment",
                        "prev_url": format!("/booking/details/{}", booking_id),
                        "next_url": res.checkout_url,
                    }),
                    session,
                )
                .await
            }
            Err(e) => {
                error!("Failed to parse stripe response: {:?}", e);
                HttpResponse::InternalServerError().json(json!({"error": "Failed to parse stripe response"}))
            }
        },
        Err(e) => {
            error!("Failed to send Stripe request: {:?}", e);
            HttpResponse::InternalServerError().json(json!({"error": "Failed to send Stripe request"}))
        }
    }
}
