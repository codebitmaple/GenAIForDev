use aarya_entities::{
    booking::{Appointment, BookingEntity, BookingStatus},
    instructor::entity::InstructorEntity,
};
use aarya_utils::{
    cache_ops::Cache,
    calendar_ops::{get_availablity_model, AvailabilityModel, InstructorAvailability},
    date_ops,
    db_ops::Database,
    result_types::EntityResult,
};
use actix_web::{web, HttpRequest, HttpResponse, Responder};
use chrono::{NaiveTime, Weekday};
use handlebars::Handlebars;
use log::{debug, error, info};
use mongodb::{bson::doc, Client};
use serde::Serialize;
use serde_json::json;

use crate::html_renderer::render_handlebars;

#[derive(Serialize)]
pub struct TemplateContext {
    pub time_headers: Vec<String>,
    pub availability_entries: Vec<AvailabilityModel>,
}

pub async fn get_availability(
    req: HttpRequest,
    cache: web::Data<Cache>,
    handlebars: web::Data<Handlebars<'_>>,
    path: web::Path<String>,
    mongoc: web::Data<Client>,
    session: actix_session::Session,
) -> impl Responder {
    let booking_id = path.into_inner();

    let availability = InstructorAvailability {
        user_id: "abc".to_string(),
        role: "tutor".to_string(),
        days: vec![Weekday::Mon, Weekday::Tue, Weekday::Wed, Weekday::Thu, Weekday::Fri, Weekday::Sat].into_iter().collect(),
        start_time: vec![
            NaiveTime::from_hms_opt(17, 0, 0).expect("Invalid time"),
            NaiveTime::from_hms_opt(18, 0, 0).expect("Invalid time"),
            NaiveTime::from_hms_opt(19, 0, 0).expect("Invalid time"),
            NaiveTime::from_hms_opt(20, 0, 0).expect("Invalid time"),
        ],
        out_of_office: vec![].into_iter().collect(),
    };

    // Generate the availability data for the template
    let start_date = date_ops::add_days(date_ops::local_date(), 2);
    let days_ahead = 10;

    let availability_entries = get_availablity_model(&availability, start_date, days_ahead);

    // Define the time headers manually based on your start_time vector
    let time_headers = availability.start_time.iter().map(|time| time.to_string()).collect::<Vec<_>>();

    // let len = time_headers.len();

    let context = TemplateContext { time_headers, availability_entries };

    // retrieve booking from the cache
    let booking = match cache.get_json::<BookingEntity>(booking_id.as_str()) {
        Some(b) => b,
        None => {
            error!("Failed to get booking from cache");
            return HttpResponse::InternalServerError().finish();
        }
    };

    // retrieve instructor name from the database
    let instructor = match InstructorEntity::filter(&mongoc, doc! {"user_id": booking.instructor_id.clone()}).await {
        Some(i) => i.first().unwrap().clone(),
        None => {
            error!("Failed to find instructor");
            return HttpResponse::NotFound().body("Instructor not found");
        }
    };

    render_handlebars(
        req,
        &handlebars,
        "booking-availability",
        json!({
            "title": "Schedule an Appointment",
            "description":  "Schedule a learning appointment with an industry expert",
            "model": context,
            "author_name": instructor.first_name,
            "next_url": format!("/booking/appointment/{}", booking_id),
        }),
        session,
    )
    .await
}

pub async fn post_appointment(
    mongoc: web::Data<Client>,
    model: web::Json<Appointment>,
    path: web::Path<String>,
) -> impl Responder {
    let booking_id = path.into_inner();
    let model = model.into_inner();
    debug!("Appointment model: {:?}", model);
    debug!("Booking ID: {:?}", booking_id);
    // retrieve booking from the database
    let bookings = BookingEntity::get_collection(&mongoc);
    let booking = match Database::find::<BookingEntity>(bookings.clone(), &booking_id).await {
        EntityResult::Success(r) => {
            info!("Retrieved booking {:?}", r);
            r
        }
        EntityResult::Error(e) => {
            error!("Failed to find booking: {:?}", e);
            return HttpResponse::InternalServerError().json(json!({"error": "Failed to find booking"}));
        }
    };
    // set details property by creating a new BookingEntity
    let booking_entity = BookingEntity {
        appointment: Some(model.clone()),
        status: BookingStatus::Appointment,
        ..booking.clone()
    };
    // update the booking in the database
    // update booking in the database
    match Database::update(&bookings, &booking_entity, &booking_id).await {
        EntityResult::Success(r) => {
            info!("Booking updated {:?}", r);
        }
        EntityResult::Error(e) => {
            error!("Failed to update booking: {:?}", e);
            return HttpResponse::InternalServerError().json(json!({"error": "Failed to update booking"}));
        }
    }
    debug!("Booking updated: {:?}", booking_entity);
    HttpResponse::Ok().json(json!({"next_url": format!("/booking/checkout/{}", booking_id)}))
}
