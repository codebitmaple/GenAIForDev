use aarya_entities::{
    booking::{BookingDetails, BookingEntity, BookingStatus, BookingType},
    instructor::entity::InstructorEntity,
};
use aarya_utils::{
    cache_ops::Cache,
    db_ops::Database,
    file_ops,
    json_ops::{self, JsonOpsResult},
    result_types::EntityResult,
};
use actix_web::{web, HttpRequest, HttpResponse, Responder};

use handlebars::Handlebars;
use log::{debug, error, info};
use mongodb::{bson::doc, Client};
use serde::{Deserialize, Serialize};
use serde_json::json;

use crate::html_renderer::render_handlebars;

#[derive(Serialize, Deserialize, Debug)]
pub struct TypeTopics {
    category: BookingType,
    display: String,
    topics: Vec<String>,
}

#[derive(Serialize, Deserialize, Debug)]
pub struct FormInputs {
    pub type_topics: Vec<TypeTopics>,
    pub target_roles: Vec<String>,
}

impl Default for FormInputs {
    fn default() -> Self {
        FormInputs {
            type_topics: vec![
                TypeTopics {
                    category: BookingType::Mentoring,
                    display: String::from("Improve a Skill"),
                    topics: vec![
                        String::from("Behavioral"),
                        String::from("People Management"),
                        String::from("Data Structures and Algorithms"),
                        String::from("Systems Design"),
                        String::from("Solutions Architecture"),
                    ],
                },
                TypeTopics {
                    category: BookingType::Tutoring,
                    display: String::from("AP Exams Tutoring"),
                    topics: vec![String::from("AP Computer Science A"), String::from("AP Computer Science Principles")],
                },
                TypeTopics {
                    category: BookingType::Interviewing,
                    display: String::from("Interview Preperation"),
                    topics: vec![
                        String::from("Behavioral"),
                        String::from("People Management"),
                        String::from("System Design"),
                        String::from("Coding and Problem Solving"),
                        String::from("Solutions Architecture"),
                    ],
                },
            ],
            target_roles: vec![String::from("Software Engineer"), String::from("Solutions Architect"), String::from("Engineering Manager")],
        }
    }
}

pub async fn get_booking_details(
    req: HttpRequest,
    handlebars: web::Data<Handlebars<'_>>,
    cache: web::Data<Cache>,
    mongoc: web::Data<Client>,
    path: web::Path<String>,
    session: actix_session::Session,
) -> impl Responder {
    let booking_id = path.into_inner();
    let form_inputs = FormInputs::default();

    // retrieve booking from the cache
    let booking = match cache.get_json::<BookingEntity>(booking_id.as_str()) {
        Some(b) => b,
        None => {
            error!("Failed to get booking from cache");
            return HttpResponse::NotFound().finish();
        }
    };

    // retrieve instructor name from the database
    let instructor = match InstructorEntity::filter(&mongoc, doc! {"user_id": booking.instructor_id.clone()}).await {
        Some(i) => i.first().unwrap().clone(),
        None => {
            error!("Failed to find instructor");
            return HttpResponse::NotFound().body("Instructor not found");
        }
    };

    render_handlebars(
        req,
        &handlebars,
        "booking-details",
        json!({
            "title": "Booking Details",
            "description": "TODO: Add page description",
            "form_inputs":  serde_json::to_string(&form_inputs).unwrap(),
            "author_name": instructor.first_name,
            "booking_id": booking_id,
            "schema": file_ops::read_file("./assets/schema/booking-schema.json").unwrap(),
            "next_url": format!("/booking/details/{}", booking_id),
        }),
        session,
    )
    .await
}

pub async fn post_booking_details(
    mongoc: web::Data<Client>,
    model: web::Json<BookingDetails>,
    path: web::Path<String>,
) -> impl Responder {
    let booking_id = path.into_inner();
    debug!("Booking details: {:?}", model);
    debug!("Booking ID: {:?}", booking_id);
    let valid_model = match json_ops::validate_json_text("./assets/schema/booking-schema.json", serde_json::to_string(&model).unwrap().as_str()) {
        JsonOpsResult::Success(_) => true,
        JsonOpsResult::Error(e) => {
            error!("Failed to validate booking details: {:?}", e);
            return HttpResponse::InternalServerError().json(json!({"error": "Failed to validate booking details"}));
        }
    };
    if !valid_model {
        return HttpResponse::BadRequest().json(json!({"error": "Invalid booking details"}));
    }
    // retrieve booking from the database
    let bookings = BookingEntity::get_collection(&mongoc);
    let booking = match Database::find::<BookingEntity>(bookings.clone(), &booking_id).await {
        EntityResult::Success(r) => {
            info!("Retrieved booking {:?}", r);
            r
        }
        EntityResult::Error(e) => {
            error!("Failed to find booking: {:?}", e);
            return HttpResponse::InternalServerError().json(json!({"error": "Failed to find booking"}));
        }
    };
    // retrieve details from the model
    let details: BookingDetails = model.into_inner();
    // set details property by creating a new BookingEntity
    let booking_entity = BookingEntity {
        details: Some(details),
        status: BookingStatus::Details,
        ..booking.clone()
    };

    // update booking in the database
    match Database::update(&bookings, &booking_entity, &booking_id).await {
        EntityResult::Success(r) => {
            info!("Booking updated {:?}", r);
        }
        EntityResult::Error(e) => {
            error!("Failed to update booking: {:?}", e);
            return HttpResponse::InternalServerError().json(json!({"error": "Failed to update booking"}));
        }
    }
    debug!("Booking updated: {:?}", booking_entity);
    // transfer to the next page -> availability
    HttpResponse::Ok().json(json!({"booking_id": booking_id, "next_url": format!("/booking/availability/{}", booking_id)}))
}
