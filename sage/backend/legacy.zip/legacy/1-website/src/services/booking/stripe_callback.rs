use std::sync::{Arc, Mutex};

use aarya_entities::{
    booking::{BookingEntity, BookingStatus},
    email::payment_confirmation::PaymentConfirmationModel,
    models::google::GoogleUserModel,
    payment::{PaymentEntity, PaymentStatus},
    queue::NamedQueue,
};
use aarya_utils::{
    db_ops::Database,
    environ::{Environ, WebConfig},
    queue_ops::Producer,
    result_types::EntityResult,
};
use actix_web::{web, HttpRequest, HttpResponse, Responder};

use handlebars::Handlebars;
use mongodb::Client;
use serde_json::json;

use crate::html_renderer::{get_user_info, render_handlebars};

pub async fn get_payment_success_with_reload(path: web::Path<String>) -> impl Responder {
    let booking_id = path.into_inner();

    HttpResponse::Ok().body(format!(
        r#"
                    <html>
                    <body>
                        <p>Payment successful. Redirecting...</p>
                        <script>
                            // Automatically redirect the browser to the desired route
                            window.location.href = "/payment-successful/{}";
                        </script>
                    </body>
                    </html>
                "#,
        booking_id
    ))
}

pub async fn get_payment_success(
    req: HttpRequest,
    mongoc: web::Data<Client>,
    path: web::Path<String>,
    producer: web::Data<Arc<Mutex<Producer>>>,
    handlebars: web::Data<Handlebars<'_>>,
    session: actix_session::Session,
) -> impl Responder {
    let booking_id = path.into_inner();

    let bookings = BookingEntity::get_collection(&mongoc);
    let booking = match Database::find(bookings, &booking_id).await {
        EntityResult::Success(r) => r,
        EntityResult::Error(e) => {
            return HttpResponse::InternalServerError().json(json!({
                "error": format!("Failed to retrieve booking: {:?}", e)
            }));
        }
    };

    booking.set_status(&mongoc, &BookingStatus::Paid).await;
    let instructor_email = booking.get_instructor(&mongoc).await.unwrap().email;

    match PaymentEntity::update_status(&mongoc, PaymentStatus::Completed, &booking_id).await {
        EntityResult::Success(_) => {}
        EntityResult::Error(e) => {
            return HttpResponse::InternalServerError().json(json!({
                "error": format!("Failed to update payment status: {:?}", e)
            }));
        }
    }

    match get_user_info(session.clone()) {
        Some(student) => {
            send_emails_to_educator_and_learner(&producer, &booking_id, &student, &instructor_email);
        }
        None => {
            // probably needs login again
            return HttpResponse::Ok().body(
                r#"
                    <html>
                    <body>
                        <p>Payment successful. Redirecting...</p>
                        <script>
                            // Automatically redirect the browser to the desired route
                            window.location.href = "/";
                        </script>
                    </body>
                    </html>
                "#,
            );
        }
    };

    render_handlebars(
        req,
        &handlebars,
        "payment-successful",
        json!({
            "title": "Author Availability",
            "description":  "TODO!"
        }),
        session,
    )
    .await
}

struct MessageModel {
    producer: web::Data<Arc<Mutex<Producer>>>,
    booking_id: String,
    subject: String,
    header: String,
    message: String,
    email_to: Vec<String>,
    cta_link: String,
    cta_text: String,
}

fn produce_message(model: MessageModel) {
    model
        .producer
        .lock()
        .unwrap()
        .produce(
            NamedQueue::Email.as_str(),
            &json!(PaymentConfirmationModel {
                idempotent_key: model.booking_id.clone(),
                booking_id: model.booking_id.clone(),
                template_name: String::from("base.html"),
                header: model.header.clone(),
                subject: model.subject.clone(),
                message: model.message.clone(),
                cta_link: model.cta_link.clone(),
                cta_text: model.cta_text.clone(),
                email_to: model.email_to,
                ..Default::default()
            }),
        )
        .unwrap();
}

fn send_emails_to_educator_and_learner(
    producer: &web::Data<Arc<Mutex<Producer>>>,
    booking_id: &str,
    student: &GoogleUserModel,
    educator_email: &str,
) {
    let web_config: WebConfig = Environ::init();
    let learner_cta_link = format!("{}/account/sessions", web_config.allowed_origin);
    let educator_cta_link = format!("{}/account/sessions", web_config.allowed_origin);

    let student_model = MessageModel {
        producer: producer.clone(),
        booking_id: booking_id.to_string(),
        subject: format!("{}, your session is confirmed 💥", student.given_name),
        header: String::from("All the best for your session"),
        message: String::from("Your payment was successful!"),
        email_to: vec![student.email.clone()],
        cta_link: learner_cta_link,
        cta_text: String::from("View your Session Summary"),
    };

    // Email to student
    produce_message(student_model);

    let instructor_model = MessageModel {
        producer: producer.clone(),
        booking_id: booking_id.to_string(),
        subject: String::from("You have a new booking"),
        header: String::from("Prepare for your upcoming session"),
        message: String::from("A new session has been booked and confirmed."),
        email_to: vec![educator_email.to_string()],
        cta_link: educator_cta_link,
        cta_text: String::from("View and Manage Session"),
    };

    // Email to instructor
    produce_message(instructor_model);
}

pub async fn get_payment_canceled(
    req: HttpRequest,
    handlebars: web::Data<Handlebars<'_>>,
    path: web::Path<String>,
    session: actix_session::Session,
) -> impl Responder {
    let _author_id = path.into_inner();

    render_handlebars(
        req,
        &handlebars,
        "payment-canceled",
        json!({
            "title": "Author Availability",
            "description":  "TODO!"
        }),
        session,
    )
    .await
}
