pub mod admin;
pub mod blogs;
pub mod booking;
pub mod courses;
pub mod instructor;
pub mod pricing;
pub mod public;
