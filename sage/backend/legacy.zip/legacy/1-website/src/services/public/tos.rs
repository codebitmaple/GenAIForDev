use actix_web::{web, HttpRequest, Responder};
use handlebars::Handlebars;
use serde_json::json;

use crate::html_renderer::render_handlebars;

pub async fn get_tos_page(
    req: HttpRequest,
    handlebars: web::Data<Handlebars<'_>>,
    session: actix_session::Session,
) -> impl Responder {
    render_handlebars(
        req,
        &handlebars,
        "tos",
        json!({
            "title": "Terms of Service",
            "message":  "In development",
        }),
        session,
    )
    .await
}
