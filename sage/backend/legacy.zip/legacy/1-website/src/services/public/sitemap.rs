use std::{collections::HashMap, io::Cursor};

use aarya_entities::{
    course::course_entity::CourseEntity,
    openai::chat::{ChatEntity, ChatResponseModel},
    post::PostEntity,
    topic::topic_entity::TopicEntity,
    unit::unit_entity::UnitEntity,
};
use aarya_utils::{cache_ops, date_ops};
use actix_web::{web, HttpResponse, Responder};
use mongodb::Client;

use quick_xml::{
    events::{BytesEnd, BytesStart, BytesText, Event},
    Writer,
};
use serde::{Deserialize, Serialize};

#[derive(Debug, Serialize, Deserialize, PartialEq)]
#[serde(rename = "urlset", rename_all = "lowercase")]
pub struct UrlSet {
    #[serde(rename = "xmlns", default = "default_namespace")]
    pub namespace: String,
    pub url: Vec<UrlEntry>,
}

pub fn default_namespace() -> String {
    "http://www.sitemaps.org/schemas/sitemap/0.9".to_string()
}

#[derive(Debug, Serialize, Deserialize, PartialEq)]
pub struct UrlEntry {
    pub loc: String,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub lastmod: Option<String>, // e.g., "2024-10-31"
    #[serde(skip_serializing_if = "Option::is_none")]
    pub changefreq: Option<String>, // e.g., "daily"
    #[serde(skip_serializing_if = "Option::is_none")]
    pub priority: Option<f32>, // e.g., 0.8
}

fn generate_sitemap(entries: &[UrlEntry]) -> String {
    let mut writer = Writer::new(Cursor::new(Vec::new()));
    let mut urlset_start = BytesStart::new("urlset");
    urlset_start.push_attribute(("xmlns", "http://www.sitemaps.org/schemas/sitemap/0.9"));

    writer.write_event(Event::Start(urlset_start)).unwrap();

    for entry in entries {
        write_url_entry(&mut writer, entry).unwrap();
    }

    writer.write_event(Event::End(BytesEnd::new("urlset"))).unwrap();

    String::from_utf8(writer.into_inner().into_inner()).expect("Failed to convert to UTF-8")
}

// Modify your serialization function to use quick-xml for more controlled XML generation.
fn write_url_entry(
    writer: &mut Writer<Cursor<Vec<u8>>>,
    entry: &UrlEntry,
) -> Result<(), quick_xml::Error> {
    let start = BytesStart::new("url");
    writer.write_event(Event::Start(start.borrow()))?;

    // Write <loc>
    writer.write_event(Event::Start(BytesStart::new("loc")))?;
    writer.write_event(Event::Text(BytesText::new(entry.loc.as_str())))?;
    writer.write_event(Event::End(BytesEnd::new("loc")))?;

    // Optionally write other fields...
    if let Some(lastmod) = &entry.lastmod {
        writer.write_event(Event::Start(BytesStart::new("lastmod")))?;
        writer.write_event(Event::Text(BytesText::new(lastmod.as_str())))?;
        writer.write_event(Event::End(BytesEnd::new("lastmod")))?;
    }

    if let Some(priority) = &entry.priority {
        let priority_str = format!("{:.1}", priority);
        writer.write_event(Event::Start(BytesStart::new("priority")))?;
        writer.write_event(Event::Text(BytesText::new(priority_str.as_str())))?;
        writer.write_event(Event::End(BytesEnd::new("priority")))?;
    }

    if let Some(changefreq) = &entry.changefreq {
        writer.write_event(Event::Start(BytesStart::new("changefreq")))?;
        writer.write_event(Event::Text(BytesText::new(changefreq.as_str())))?;
        writer.write_event(Event::End(BytesEnd::new("changefreq")))?;
    }
    writer.write_event(Event::End(BytesEnd::new("url")))?;
    Ok(())
}

pub async fn get_sitemap(
    cache: web::Data<cache_ops::Cache>,
    mongoc: web::Data<Client>,
) -> impl Responder {
    let posts: Vec<PostEntity> = PostEntity::scan(&mongoc, &cache).await.unwrap();
    let courses: Vec<CourseEntity> = CourseEntity::scan(&mongoc, &cache).await.unwrap();
    let units = UnitEntity::scan(&mongoc, &cache).await.unwrap();
    let topics = TopicEntity::scan(&mongoc, &cache).await.unwrap();
    let chats = ChatEntity::default().scan(&mongoc).await.unwrap();

    let mut url_entries = Vec::new();
    let base_url = "https://aarya.ai";

    // chats
    for chat in chats {
        let model = ChatResponseModel::from(chat.clone());
        let chat_url = format!("{}/social/{}", base_url, model.id);
        url_entries.push(UrlEntry {
            loc: chat_url,
            lastmod: Some(date_ops::from(chat.timestamp).format("%Y-%m-%d").to_string()),
            changefreq: Some("daily".to_string()),
            priority: Some(0.8),
        });
    }

    // Map posts to their URLs
    for post in posts {
        let post_url = format!("{}/posts/{}", base_url, post.permalink);
        url_entries.push(UrlEntry {
            loc: post_url,
            lastmod: Some(date_ops::from(post.modified_date).format("%Y-%m-%d").to_string()),
            changefreq: Some("weekly".to_string()),
            priority: Some(0.8),
        });
    }

    // Map units to their courses
    let units_map: HashMap<String, Vec<UnitEntity>> = {
        let mut map = HashMap::new();
        for unit in units {
            map.entry(unit.clone().course_id).or_insert_with(Vec::new).push(unit);
        }
        map
    };

    // Map topics to their units
    let topics_map: HashMap<String, Vec<TopicEntity>> = {
        let mut map = HashMap::new();
        for topic in topics {
            map.entry(topic.clone().unit_id).or_insert_with(Vec::new).push(topic);
        }
        map
    };

    for course in courses {
        let course_url = format!("{}/courses/{}", base_url, course.slug);
        url_entries.push(UrlEntry {
            loc: course_url.clone(),
            lastmod: Some(date_ops::from(course.updated).format("%Y-%m-%d").to_string()),
            changefreq: Some("weekly".to_string()),
            priority: Some(0.9),
        });

        if let Some(units) = units_map.get(&course._id.to_hex()) {
            for unit in units {
                if let Some(topics) = topics_map.get(&unit._id.to_hex()) {
                    for topic in topics {
                        let topic_url = format!("{}/courses/{}/{}/{}", base_url, course.slug, unit.slug, topic.slug);
                        url_entries.push(UrlEntry {
                            loc: topic_url,
                            lastmod: Some(date_ops::from(topic.updated_at).format("%Y-%m-%d").to_string()),
                            changefreq: Some("weekly".to_string()),
                            priority: Some(0.5),
                        });
                    }
                }
            }
        }
    }

    let sitemap = generate_sitemap(&url_entries);

    HttpResponse::Ok().content_type("application/xml").body(sitemap)
}
