use aarya_entities::instructor::{entity::InstructorEntity, response::InstructorResponseModel};
use aarya_utils::environ::{Environ, WebConfig};
use actix_web::{web, HttpRequest, HttpResponse, Responder};

use handlebars::Handlebars;
use log::{debug, error};
use mongodb::Client;
use serde_json::json;

use crate::html_renderer::render_handlebars;

pub async fn get_instructor_public_profile(
    req: HttpRequest,
    handlebars: web::Data<Handlebars<'_>>,
    mongoc: web::Data<Client>,
    path: web::Path<String>,
    session: actix_session::Session,
) -> impl Responder {
    let instructor_id = path.into_inner();
    debug!("Fetching instructor public profile for {}", instructor_id);
    let instructor = InstructorResponseModel::from_google_id(&mongoc, &instructor_id).await.unwrap();
    let web_config: WebConfig = Environ::init();
    let profile_photo = format!("{}{}", web_config.images_domain, instructor.profile_photo);
    debug!("Rendering instructor public profile for {}", instructor.first_name);
    render_handlebars(
        req,
        &handlebars,
        "instructor-public-profile",
        json!({
            "title": format!("Learn with: {}", instructor.first_name),
            "instructor": instructor,
            "profile_photo": profile_photo,
        }),
        session,
    )
    .await
}

pub async fn get_instructors_public(mongoc: web::Data<Client>) -> impl Responder {
    // there is only one instructor in the system (for now)
    let instructor = match InstructorEntity::scan(&mongoc).await {
        Some(i) => i.into_iter().next().unwrap(),
        None => {
            error!("Failed to find instructors");
            return HttpResponse::NotFound().body("Error finding instructors");
        }
    };

    let path = format!("/instructors/{}", instructor.user_id);

    debug!("Redirecting to {}", path);

    HttpResponse::TemporaryRedirect().append_header(("Location", path)).finish()
}
