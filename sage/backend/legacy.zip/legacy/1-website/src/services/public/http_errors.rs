use actix_web::{web, HttpRequest, Responder};
use handlebars::Handlebars;
use serde_json::json;

use crate::html_renderer::render_handlebars;

pub async fn get_500(
    req: HttpRequest,
    handlebars: web::Data<Handlebars<'_>>,
    session: actix_session::Session,
) -> impl Responder {
    render_handlebars(
        req,
        &handlebars,
        "500",
        json!({
            "title": "Server Error",
            "message":  "We have been notified of the error and will fix it as soon as possible.",
        }),
        session,
    )
    .await
}

pub async fn get_404(
    req: HttpRequest,
    handlebars: web::Data<Handlebars<'_>>,
    session: actix_session::Session,
) -> impl Responder {
    render_handlebars(
        req,
        &handlebars,
        "404",
        json!({
            "title": "Page Not Found",
            "message":  "The page you are looking for is either under construction or does not exist.",
        }),
        session,
    )
    .await
}
