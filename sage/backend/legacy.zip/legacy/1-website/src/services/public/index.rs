use aarya_entities::{course::course_entity::CourseEntity, models::req_res::PostResponseModel, post::PostEntity};
use aarya_utils::{
    cache_ops,
    environ::{Environ, WebConfig},
};
use actix_web::{web, HttpRequest, Responder};
use handlebars::Handlebars;
use log::warn;
use mongodb::Client;
use serde_json::json;

use crate::{html_renderer::render_handlebars, services::admin::course::CourseResponseModel};

async fn get_posts(
    mongoc: &mongodb::Client,
    cache: &cache_ops::Cache,
) -> Option<Vec<PostResponseModel>> {
    let mut posts = match PostEntity::scan(mongoc, cache).await {
        Some(p) => p,
        None => {
            warn!("Failed to get posts from database");
            vec![]
        }
    };

    posts.sort_by(|a, b| b.modified_date.cmp(&a.modified_date));

    let post_response_models: Vec<PostResponseModel> = posts.iter().map(|post| PostResponseModel::from_entity(post.clone())).collect();

    if post_response_models.is_empty() {
        None
    } else if post_response_models.len() < 5 {
        return Some(post_response_models);
    } else {
        return Some(post_response_models[0..5].to_vec());
    }
}

async fn get_courses(
    mongoc: &mongodb::Client,
    cache: &cache_ops::Cache,
) -> Option<Vec<CourseResponseModel>> {
    let mut courses = match CourseEntity::scan(mongoc, cache).await {
        Some(c) => c,
        None => {
            warn!("Failed to get courses from database");
            vec![]
        }
    };

    courses.sort_by(|a, b| b.created.cmp(&a.created));

    let course_response_models: Vec<CourseResponseModel> = courses.iter().map(|course| CourseResponseModel::from(course.clone())).collect();

    if course_response_models.is_empty() {
        None
    } else if course_response_models.len() < 5 {
        return Some(course_response_models);
    } else {
        return Some(course_response_models[0..5].to_vec());
    }
}

pub async fn get_index(
    req: HttpRequest,
    handlebars: web::Data<Handlebars<'_>>,
    mongoc: web::Data<Client>,
    session: actix_session::Session,
    cache: web::Data<cache_ops::Cache>,
) -> impl Responder {
    let web_config: WebConfig = Environ::init();
    render_handlebars(
        req,
        &handlebars,
        "index-main",
        json!({
            "title": "Welcome to Aarya AI",
            "description":  "TODO",
            "model": "Welcome to Aarya AI",
            "posts": get_posts(&mongoc, &cache).await.unwrap_or_default(),
            "courses": get_courses(&mongoc, &cache).await.unwrap_or_default(),
            "app_url": web_config.app_url,
        }),
        session,
    )
    .await
}
