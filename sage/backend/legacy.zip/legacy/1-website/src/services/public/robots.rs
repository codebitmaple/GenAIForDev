use actix_web::{HttpResponse, Responder};

pub async fn get_robots() -> impl Responder {
    HttpResponse::Ok().content_type("text/plain").body("User-agent: *\nDisallow: app.aarya.ai\nDisallow: /admin")
}
