use aarya_entities::pricing::pricing_entity::PricingEntity;
use actix_web::{web, HttpRequest, Responder};
use handlebars::Handlebars;
use serde_json::json;

use crate::html_renderer::render_handlebars;

pub async fn get_pricing(
    req: HttpRequest,
    handlebars: web::Data<Handlebars<'_>>,
    session: actix_session::Session,
) -> impl Responder {
    let model = PricingEntity::default();
    render_handlebars(
        req,
        &handlebars,
        "pricing",
        json!({
            "title": "Pricing details",
            "description":  "TODO!",
            "student_pricing": model.student_pricing,
            "professional_pricing": model.professional_pricing,
        }),
        session,
    )
    .await
}
