use std::{future::Future, pin::Pin};

use aarya_entities::{booking::BookingEntity, session::SessionModel};
use mongodb::Client;

pub trait SessionStrategy {
    fn get_user_field(&self) -> String; // Get the field to filter by (e.g., educator_id, learner_id)
    fn get_session_page(&self) -> String; // Define the session page to render
    fn get_available_actions(
        &self,
        session_id: String,
    ) -> Vec<(String, String)>; // Define what actions are available for the user

    // Customize session data based on role, async method
    fn customize_session_view<'a>(
        &'a self,
        mongoc: &'a Client,
        sessions: Vec<BookingEntity>,
    ) -> Pin<Box<dyn Future<Output = Vec<SessionModel>> + 'a>>; // This ensures async compatibility
}
