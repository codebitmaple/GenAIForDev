use aarya_entities::{booking::BookingEntity, models::google::GoogleUserModel, session::SessionModel};
use aarya_utils::{db_ops::Database, result_types::EntityResult};
use log::error;
use mongodb::Client;

use super::session_trait::SessionStrategy;

pub struct SessionBuilder {
    strategy: Box<dyn SessionStrategy>, // The strategy is selected at runtime based on the user role
}

impl SessionBuilder {
    pub fn new(strategy: Box<dyn SessionStrategy>) -> Self {
        SessionBuilder { strategy }
    }

    pub fn get_session_page(&self) -> String {
        self.strategy.get_session_page()
    }

    pub async fn build_session(
        &self,
        mongoc: &Client,
        user_info: &GoogleUserModel,
    ) -> Vec<SessionModel> {
        let user_field = self.strategy.get_user_field();

        // Fetch sessions based on user role
        let bookings = BookingEntity::get_collection(mongoc);
        let sessions = match Database::filter(bookings, user_field, user_info.id.clone()).await {
            EntityResult::Success(r) => r,
            EntityResult::Error(e) => {
                error!("Failed to get bookings: {:?}", e);
                return Vec::new();
            }
        };

        // Customize the session data based on the strategy
        self.strategy.customize_session_view(mongoc, sessions).await
    }
}
