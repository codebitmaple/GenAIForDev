use std::{future::Future, pin::Pin};

use aarya_entities::{booking::BookingEntity, session::SessionModel};
use futures::{stream::FuturesUnordered, StreamExt};
use mongodb::Client;
use serde::{Deserialize, Serialize};

use super::session_trait::SessionStrategy;

#[derive(Serialize, Deserialize, Debug, Clone)]
pub struct StudentStrategy;

impl SessionStrategy for StudentStrategy {
    fn get_user_field(&self) -> String {
        "student_id".to_string()
    }

    fn get_session_page(&self) -> String {
        "student-sessions".to_string()
    }

    fn customize_session_view<'a>(
        &'a self,
        mongoc: &'a Client,
        sessions: Vec<BookingEntity>,
    ) -> Pin<Box<dyn Future<Output = Vec<SessionModel>> + 'a>> {
        Box::pin(async move {
            let futures = FuturesUnordered::new();
            for s in sessions.into_iter() {
                let mongoc_clone = mongoc.clone();
                let self_clone = self.clone(); // Ensure self can be moved into async block
                futures.push(async move {
                    let student = s.get_student(&mongoc_clone).await.unwrap();
                    let details = s.details.as_ref().unwrap().clone();
                    let appointment = s.appointment.as_ref().unwrap();
                    SessionModel {
                        with_field: student.full_name,
                        on_field: appointment.format_time_slots(),
                        for_field: details.booking_type.to_text(),
                        about_field: details.topic,
                        actions: self_clone.get_available_actions(s.get_id()),
                    }
                });
            }

            // Collect all futures into a Vec
            futures.collect().await
        })
    }

    fn get_available_actions(
        &self,
        session_id: String,
    ) -> Vec<(String, String)> {
        vec![
            ("View Feedback".to_string(), format!("/account/session/{}/feedback/view", session_id)),
            ("Reschedule Session".to_string(), format!("/account/session/{}/reschedule", session_id)),
            ("Cancel Session".to_string(), format!("/account/session/{}/cancel", session_id)),
            ("Resend Meeting Invite".to_string(), format!("/account/session/{}/resend-invite", session_id)),
        ]
    }
}
