use crate::html_renderer::{get_user_info, render_handlebars};
use actix_web::{web, HttpRequest, HttpResponse, Responder};
use handlebars::Handlebars;
use log::error;
use serde_json::json;

pub async fn get_session_feedback(
    req: HttpRequest,
    path: web::Path<String>,
    handlebars: web::Data<Handlebars<'_>>,
    session: actix_session::Session,
) -> impl Responder {
    let session_id = path.into_inner();
    if let Some(user_info) = get_user_info(session.clone()) {
        render_handlebars(
            req,
            &handlebars,
            "session-feedback",
            json!({
                "title": "Your sessions",
                "session": session_id,
                "user": user_info
            }),
            session,
        )
        .await
    } else {
        error!("Could not get user information");
        HttpResponse::NotFound().json(json!({"error": "User not found. Try login first"}))
    }
}
