use crate::html_renderer::{get_user_info, render_handlebars};
use aarya_entities::models::user_role::UserRole;
use actix_web::{web, HttpRequest, HttpResponse, Responder};
use handlebars::Handlebars;
use log::{debug, error};
use mongodb::Client;
use serde_json::json;

use super::strategies::session_strategy::{instructor_strategy::InstructorStrategy, session_builder::SessionBuilder, session_trait::SessionStrategy, student_strategy::StudentStrategy};

pub async fn get_account_sessions(
    req: HttpRequest,
    mongoc: web::Data<Client>,
    handlebars: web::Data<Handlebars<'_>>,
    session: actix_session::Session,
) -> impl Responder {
    if let Some(user_info) = get_user_info(session.clone()) {
        let strategy: Box<dyn SessionStrategy> = match user_info.role {
            Some(UserRole::Instructor) => Box::new(InstructorStrategy),
            Some(UserRole::Student) => Box::new(StudentStrategy),
            Some(UserRole::Admin) => Box::new(InstructorStrategy), // Admins can use the same strategy as teachers
            None => {
                error!("Could not get user role");
                return HttpResponse::NotFound().json(json!({"error": "User role not found"}));
            }
        };

        let builder = SessionBuilder::new(strategy);
        let sessions = builder.build_session(&mongoc, &user_info).await;
        let session_page = builder.get_session_page();
        // debug!("Sessions: {:?}", sessions);
        debug!("Session page: {}", session_page);

        render_handlebars(
            req,
            &handlebars,
            &session_page,
            json!({
                "title": "Your sessions",
                "count": sessions.len(),
                "all_sessions": sessions,
            }),
            session,
        )
        .await
    } else {
        error!("Could not get user information");
        HttpResponse::NotFound().json(json!({"error": "User not found. Try login first"}))
    }
}
