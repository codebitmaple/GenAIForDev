#[macro_use]
pub mod macros;
mod account;
pub mod api;
pub mod auth;
pub mod html_renderer;
pub mod interceptors;
pub mod landing;
pub mod services;
pub mod social;

use std::sync::{Arc, Mutex};

use crate::account::session_feedback::get_session_feedback;
use crate::account::sessions::get_account_sessions;
use aarya_utils::{
    cache_ops::Cache,
    environ::{AuthConfig, DatabaseConfig, Environ, Environment, RedisConfig, WebConfig},
    handlebars_ops::configure_handlebars,
    queue_ops::{Producer, RedisConnectionManager},
};
use actix_cors::Cors;
use actix_files as fs;
use actix_session::{storage::RedisSessionStore, SessionMiddleware};
use actix_web::{
    cookie::{Key, SameSite},
    middleware::Logger,
    web, App, HttpServer,
};
use api::{
    files::post_markdown_base64,
    openai::{
        chat::get_chats_by_user,
        course::{get_course_by_slug, get_courses, post_course_followup, post_describe_course},
        exercise::post_exercise_followup,
        get_test_results, post_answer_recommendations, post_followup_response, post_post_chat_completion,
        practice_test::{post_practice_answers, post_practice_questions},
        result::get_results_by_user,
        topic::{get_topic_by, get_tutorial, post_topic_explanation_followups, post_topic_followup},
        unit::get_units,
    },
    photos::{get_google_profile_pic, post_photo, post_photos},
    user::get_user_info,
};
use auth::{
    google::{auth_callback, auth_google, logout},
    login::get_login,
};

use interceptors::{admin_verifier::AdminVerifier, api_login_verifier::ApiLoginVerifier, instructor_verifier::InstructorVerifier, login_verifier::LoginVerifier};
use landing::{mentoring::get_mentoring_page, self_learning::get_self_learning_page, tutoring::get_tutoring_page};
use mongodb::Client;
use oauth2::{basic::BasicClient, AuthUrl, ClientId, ClientSecret, RedirectUrl, TokenUrl};
use services::{
    admin::{
        course::{get_course_edit, get_course_list, get_create_course, post_course_download_template, post_download_course_json, post_upload_course, put_upload_course},
        home::get_admin_home,
        user::{get_user_list, post_users_download},
    },
    blogs::{get_post, get_posts},
    booking::{
        appointment::{get_availability, post_appointment},
        checkout::{get_checkout, get_checkout_with_reload},
        details::{get_booking_details, post_booking_details},
        init::get_init_booking,
        landing::get_details_page,
        stripe_callback::{get_payment_success, get_payment_success_with_reload},
    },
    courses::course_home::{get_course, get_course_all, get_topic, get_unit},
    instructor::{
        post::{get_create_post, get_edit_post, get_post_download, get_post_download_template, get_post_list, get_post_markdown_download, post_upload_post, put_upload_post},
        profile::{get_instructor_card, get_instructor_edit, get_instructors_all, put_instructor_edit},
        question::{get_create_question, post_upload_questions},
        topic::{get_create_topic, get_topic_edit, get_topic_list, post_download_topic_json, post_upload_topics, put_upload_topics},
        unit::{get_create_unit, get_unit_edit, get_units_all, post_download_unit_json, post_upload_units, put_upload_units},
    },
    pricing::get_pricing,
    public::{
        about::get_about_page,
        http_errors::{get_404, get_500},
        index::get_index,
        instructor::{get_instructor_public_profile, get_instructors_public},
        privacy::get_privacy_page,
        robots::get_robots,
        sitemap::get_sitemap,
        subscription::get_subscription,
        tos::get_tos_page,
    },
};
use social::social_home::{get_social_page, get_social_question};

#[actix_web::main]
async fn main() -> std::io::Result<()> {
    Environ::load_env_file();
    let auth_config: AuthConfig = Environ::init();
    let db_config: DatabaseConfig = Environ::init();
    let web_config: WebConfig = Environ::init();
    let redis_config: RedisConfig = Environ::init();
    let log_level = web_config.log_level;
    env_logger::init_from_env(env_logger::Env::new().default_filter_or(log_level));

    let client_id = ClientId::new(auth_config.google_client_id);
    let client_secret = ClientSecret::new(auth_config.google_client_secret);
    let auth_url = AuthUrl::new(auth_config.google_auth_uri).expect("Invalid authorization endpoint URL");
    let token_url = TokenUrl::new(auth_config.google_token_uri).expect("Invalid token endpoint URL");
    let oauth_client = BasicClient::new(client_id, Some(client_secret), auth_url, Some(token_url)).set_redirect_uri(RedirectUrl::new(auth_config.google_callback_uri).expect("Invalid redirect URL"));
    let mongoc = Client::with_uri_str(db_config.db_connection_string).await.unwrap();
    let ip = web_config.web_app_ip;
    let port = web_config.web_app_port;
    let handlebars = configure_handlebars();
    let cache = Cache::default();

    let connection_manager = Arc::new(RedisConnectionManager::new(redis_config.redis_server.as_str()));
    let producer = Arc::new(Mutex::new(Producer::new(connection_manager.clone())));

    let secret_key = Key::generate();
    let redis_store = RedisSessionStore::new(redis_config.redis_server).await.unwrap();

    let server = HttpServer::new(move || {
        let cors = get_cors();

        App::new()
            .wrap(Logger::default())
            .wrap(cors)
            .wrap(get_session_middleware(redis_store.clone(), secret_key.clone()))
            .app_data(web::Data::new(cache.clone()))
            .app_data(web::Data::new(oauth_client.clone()))
            .app_data(web::Data::new(handlebars.clone()))
            .app_data(web::Data::new(mongoc.clone()))
            .app_data(web::Data::new(producer.clone()))
            .service(fs::Files::new("/assets", "./assets").show_files_listing())
            .service(web::resource("/").route(web::get().to(get_index)))
            .service(web::resource("/robots.txt").route(web::get().to(get_robots)))
            .service(web::resource("/sitemap.xml").route(web::get().to(get_sitemap)))
            .service(web::resource("/not-found").route(web::get().to(get_404)))
            .service(web::resource("/server-error").route(web::get().to(get_500)))
            .service(web::resource("/about").route(web::get().to(get_about_page)))
            .service(web::resource("/privacy").route(web::get().to(get_privacy_page)))
            .service(web::resource("/tos").route(web::get().to(get_tos_page)))
            .service(web::resource("/posts/{permalink}").route(web::get().to(get_post)))
            .service(web::resource("/login").route(web::get().to(get_login)))
            .service(web::resource("/pricing").route(web::get().to(get_pricing)))
            .service(web::resource("/courses").route(web::get().to(get_course_all)))
            .service(web::resource("/instructors").route(web::get().to(get_instructors_public)))
            .service(web::resource("/subscribe").route(web::get().to(get_subscription)))
            .service(web::resource("/posts").route(web::get().to(get_posts)))
            .service(web::resource("/tutoring").route(web::get().to(get_tutoring_page)))
            .service(web::resource("/mentoring").route(web::get().to(get_mentoring_page)))
            .service(web::resource("/self-learning").route(web::get().to(get_self_learning_page)))
            .service(web::resource("/payment-successful/{booking_id}").route(web::get().to(get_payment_success)))
            .service(web::resource("/payment-successful/{booking_id}/reload").route(web::get().to(get_payment_success_with_reload)))
            .service(web::resource("/instructors/{user_key}").route(web::get().to(get_instructor_public_profile)))
            .service(web::resource("/social").route(web::get().to(get_social_page)))
            .service(web::resource("/social/{id}").route(web::get().to(get_social_question)))
            .service(
                web::scope("/auth")
                    .route("/google", web::get().to(auth_google))
                    .route("/callback", web::get().to(auth_callback))
                    .route("/logout/{user_key}", web::get().to(logout)),
            )
            .service(
                web::scope("/account")
                    .wrap(LoginVerifier)
                    .route("/sessions", web::get().to(get_account_sessions))
                    .route("/session/{session_id}/feedback", web::get().to(get_session_feedback)),
            )
            .service(
                web::scope("/admin")
                    .wrap(AdminVerifier) // then this is called
                    .wrap(LoginVerifier) // do not change the order of these two interceptors -- this is called first
                    .route("/home", web::get().to(get_admin_home))
                    .route("/course/download/template", web::post().to(post_course_download_template))
                    .route("/course/download/{course_id}", web::post().to(post_download_course_json))
                    .route("/course/upload", web::post().to(post_upload_course))
                    .route("/course/upload", web::put().to(put_upload_course))
                    .route("/course/{course_id}", web::get().to(get_course_edit))
                    .route("/course", web::get().to(get_create_course))
                    .route("/courses", web::get().to(get_course_list))
                    .route("/users", web::get().to(get_user_list))
                    .route("/users/download", web::post().to(post_users_download)),
            )
            .service(
                web::scope("/instructor")
                    .wrap(InstructorVerifier) // then this is called
                    .wrap(LoginVerifier) // do not change the order of these two interceptors -- this is called first
                    .route("/post/download/template", web::post().to(get_post_download_template))
                    .route("/post/upload", web::post().to(post_upload_post))
                    .route("/post/upload", web::put().to(put_upload_post))
                    .route("/post", web::get().to(get_create_post))
                    .route("/posts", web::get().to(get_post_list))
                    .route("/unit/upload", web::post().to(post_upload_units))
                    .route("/unit/upload", web::put().to(put_upload_units))
                    .route("/unit", web::get().to(get_create_unit))
                    .route("/units", web::get().to(get_units_all))
                    .route("/topic/upload", web::post().to(post_upload_topics))
                    .route("/topic/upload", web::put().to(put_upload_topics))
                    .route("/topic", web::get().to(get_create_topic))
                    .route("/topics", web::get().to(get_topic_list))
                    .route("/question/upload", web::post().to(post_upload_questions))
                    .route("/question", web::get().to(get_create_question))
                    .route("/profiles", web::get().to(get_instructors_all))
                    .route("/profile", web::put().to(put_instructor_edit))
                    .route("/edit/{instructor_id}", web::get().to(get_instructor_edit))
                    .route("/topic/{topic_id}", web::get().to(get_topic_edit))
                    .route("/topic/download/{topic_id}", web::post().to(post_download_topic_json))
                    .route("/unit/{unit_id}", web::get().to(get_unit_edit))
                    .route("/unit/download/{unit_id}", web::post().to(post_download_unit_json))
                    .route("/post/{id}", web::get().to(get_edit_post))
                    .route("/post/download/{post_id}", web::post().to(get_post_download))
                    .route("/post/download/markdown/{post_id}", web::post().to(get_post_markdown_download))
                    .route("/profile/{instructor_id}", web::get().to(get_instructor_card)),
            )
            .service(
                web::scope("/api")
                    .wrap(ApiLoginVerifier)
                    .route("/google/picture", web::get().to(get_google_profile_pic))
                    .route("/photo", web::post().to(post_photo))
                    .route("/photos", web::post().to(post_photos))
                    .route("/courses", web::get().to(get_courses))
                    .route("/course/describe", web::post().to(post_describe_course))
                    .route("/course/followup", web::post().to(post_course_followup))
                    .route("/markdown", web::post().to(post_markdown_base64))
                    .route("/topic/followup", web::post().to(post_topic_followup))
                    .route("/topic/followup/answer", web::post().to(post_topic_explanation_followups))
                    .route("/chats", web::get().to(get_chats_by_user))
                    .route("/answer/followup", web::post().to(post_exercise_followup))
                    .route("/answer/followup/response", web::post().to(post_followup_response))
                    .route("/answer/recommendations", web::post().to(post_answer_recommendations))
                    .route("/test/results/{test_type}/{test_id}", web::get().to(get_test_results))
                    .route("/practice-test/questions", web::post().to(post_practice_questions))
                    .route("/practice-test/answers", web::post().to(post_practice_answers))
                    .route("/results", web::get().to(get_results_by_user))
                    .route("/user", web::get().to(get_user_info))
                    .route("/units/{course_id}", web::get().to(get_units))
                    .route("/completion", web::post().to(post_post_chat_completion))
                    .route("/topic/{topic_id}", web::get().to(get_tutorial))
                    .route("/course/{slug}", web::get().to(get_course_by_slug))
                    .route("/topic/{course_slug}/{unit_slug}/{topic_slug}", web::get().to(get_topic_by)),
            )
            .service(
                web::scope("/courses")
                    .route("/{slug}", web::get().to(get_course))
                    .route("/{course_slug}/{unit_slug}", web::get().to(get_unit))
                    .route("/{course_slug}/{unit_slug}/{topic_slug}", web::get().to(get_topic)),
            )
            .service(
                web::scope("/booking")
                    .wrap(LoginVerifier)
                    .route("/landing", web::get().to(get_details_page))
                    .route("/init/{instructor_id}", web::get().to(get_init_booking))
                    .route("/details/{booking_id}", web::get().to(get_booking_details))
                    .route("/details/{booking_id}", web::post().to(post_booking_details))
                    .route("/availability/{booking_id}", web::get().to(get_availability))
                    .route("/appointment/{booking_id}", web::post().to(post_appointment))
                    .route("/checkout/{booking_id}", web::get().to(get_checkout))
                    .route("/checkout/{booking_id}/reload", web::get().to(get_checkout_with_reload)),
            )
    })
    .bind((ip.clone(), port))?
    .run();

    println!("Actix running at http://{ip}:{port}");

    server.await
}

pub fn get_cors() -> Cors {
    let web_config: WebConfig = Environ::init();
    let cors = match Environment::get_env() {
        Environment::Prod => Cors::default()
            .allowed_origin(web_config.app_url.as_str())
            .allow_any_header()
            .allow_any_method()
            .supports_credentials()
            .max_age(3600),
        Environment::Dev => Cors::default()
            .allowed_origin(&web_config.app_url)
            .allow_any_header()
            .allow_any_method()
            .supports_credentials()
            .max_age(3600),
    };

    // debug!("CORS {:?}", cors);

    cors
}

pub fn get_session_middleware(
    redis_store: RedisSessionStore,
    secret_key: Key,
) -> SessionMiddleware<RedisSessionStore> {
    match Environment::get_env() {
        Environment::Prod => SessionMiddleware::builder(redis_store, secret_key).build(),
        Environment::Dev => SessionMiddleware::builder(redis_store, secret_key).cookie_same_site(SameSite::None).build(),
    }
}

#[cfg(test)]

mod tests {
    use actix_web::http::StatusCode;
    use actix_web::{test, App};
    use actix_web::{web, HttpResponse, Responder};

    async fn mock_get_posts() -> impl Responder {
        HttpResponse::Ok().body("All posts")
    }

    async fn mock_get_post(permalink: web::Path<String>) -> impl Responder {
        HttpResponse::Ok().body(format!("Post: {}", permalink))
    }

    #[actix_web::test]
    async fn test_get_posts() {
        let app = test::init_service(App::new().route("/", web::get().to(mock_get_posts)).route("/blog/{permalink}", web::get().to(mock_get_post))).await;
        let req = test::TestRequest::get().uri("/").to_request();
        let resp = test::call_service(&app, req).await;

        assert_eq!(resp.status(), StatusCode::OK);
        let body = test::read_body(resp).await;
        assert_eq!(body, "All posts");
        assert_ne!(body, "/blog/test-post");
    }

    #[actix_web::test]
    async fn test_get_post() {
        let app = test::init_service(App::new().route("/blog/{permalink}", web::get().to(mock_get_post))).await;
        let req = test::TestRequest::get().uri("/blog/test-post").to_request();
        let resp = test::call_service(&app, req).await;

        assert_eq!(resp.status(), StatusCode::OK);
        let body = test::read_body(resp).await;
        assert_eq!(body, "Post: test-post");
    }

    #[actix_web::test]
    async fn test_not_found() {
        let app = test::init_service(App::new().route("/", web::get().to(mock_get_posts))).await;
        let req = test::TestRequest::get().uri("/non-existent-route").to_request();
        let resp = test::call_service(&app, req).await;

        assert_eq!(resp.status(), StatusCode::NOT_FOUND);
    }
}
