use actix_session::Session;
use actix_web::{web, HttpRequest, HttpResponse, Responder};
use handlebars::Handlebars;
use log::error;
use serde_json::json;

use crate::auth::user::UserAuth;

pub async fn get_login(
    handlebars: web::Data<Handlebars<'_>>,
    req: HttpRequest,
    session: Session,
) -> impl Responder {
    let mut user_auth = UserAuth::from(session.clone());
    let mut referrer = match req.headers().get("Referer") {
        Some(r) => r.to_str().unwrap(),
        None => "/",
    };

    if referrer.contains("/login") {
        error!("Infinite redirect loop detected");
        referrer = "/";
    }

    user_auth.set_referrer(&referrer.to_string());

    render_template!(
        handlebars,
        "auth-login",
        json!({
            "title": "Login",
            "description":  "TODO!"
        })
    )
}
