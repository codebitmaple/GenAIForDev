use std::str::FromStr;

use aarya_entities::openai::chat::{ChatEntity, ChatResponseModel};
use actix_web::{web, HttpRequest, HttpResponse, Responder};
use handlebars::Handlebars;
use log::debug;
use mongodb::bson::oid::ObjectId;
use serde_json::json;

use crate::html_renderer::render_handlebars;

pub async fn get_social_page(
    req: HttpRequest,
    mongoc: web::Data<mongodb::Client>,
    handlebars: web::Data<Handlebars<'_>>,
    session: actix_session::Session,
) -> impl Responder {
    let chat_entity = ChatEntity::default();
    let chats = match chat_entity.scan(&mongoc).await {
        Some(c) => c,
        None => {
            debug!("No chats found");
            return HttpResponse::NotFound().finish();
        }
    };

    let chats = chats.iter().map(|c| ChatResponseModel::from(c.clone())).collect::<Vec<ChatResponseModel>>();

    render_handlebars(
        req,
        &handlebars,
        "social-home",
        json!({
            "title": "Social",
            "chats": chats
        }),
        session,
    )
    .await
}

pub async fn get_social_question(
    req: HttpRequest,
    handlebars: web::Data<Handlebars<'_>>,
    path: web::Path<String>,
    mongoc: web::Data<mongodb::Client>,
    session: actix_session::Session,
) -> impl Responder {
    let chat_id = path.into_inner();
    let chat_id = match ObjectId::from_str(&chat_id) {
        Ok(id) => id.to_hex(),
        Err(_) => {
            debug!("Invalid chat id");
            return HttpResponse::NotFound().finish();
        }
    };
    let chat = ChatEntity {
        _id: ObjectId::from_str(&chat_id).unwrap(),
        ..Default::default()
    };
    let chat = match chat.find(&mongoc).await {
        Some(c) => c,
        None => {
            debug!("No chat found");
            return HttpResponse::NotFound().finish();
        }
    };

    let model = ChatResponseModel::from(chat);

    render_handlebars(
        req,
        &handlebars,
        "question-home",
        json!({
            "title": model.clone().title.unwrap_or_default(),
            "description": model.clone().summary.unwrap_or_default(),
            "chat": model
        }),
        session,
    )
    .await
}
