use aarya_utils::environ::{Environ, WebConfig};
use actix_web::{web, HttpRequest, Responder};
use handlebars::Handlebars;
use serde_json::json;

use crate::html_renderer::render_handlebars;

pub async fn get_tutoring_page(
    req: HttpRequest,
    handlebars: web::Data<Handlebars<'_>>,
    session: actix_session::Session,
) -> impl Responder {
    let web_config: WebConfig = Environ::init();
    render_handlebars(
        req,
        &handlebars,
        "landing-tutoring",
        json!({
            "title": "Tutoring",
            "app_url": web_config.app_url,
        }),
        session,
    )
    .await
}
