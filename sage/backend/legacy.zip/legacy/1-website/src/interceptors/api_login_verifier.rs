use aarya_utils::{
    environ::{AuthConfig, Environ, Environment},
    jwt_ops::{get_claims_from, validate_jwt},
};
use actix_service::{Service, Transform};
use actix_session::SessionExt;
use actix_web::{
    body::BoxBody,
    dev::{ServiceRequest, ServiceResponse},
    Error, HttpResponse,
};
use futures::future::{ok, LocalBoxFuture, Ready};
use futures::FutureExt;
use log::{debug, info};

use crate::auth::user::UserAuth;

pub struct ApiLoginVerifier;

impl<S> Transform<S, ServiceRequest> for ApiLoginVerifier
where
    S: Service<ServiceRequest, Response = ServiceResponse<BoxBody>, Error = Error> + 'static,
{
    type Response = ServiceResponse<BoxBody>;
    type Error = Error;
    type InitError = ();
    type Transform = AuthMiddlewareService<S>;
    type Future = Ready<Result<Self::Transform, Self::InitError>>;

    fn new_transform(
        &self,
        service: S,
    ) -> Self::Future {
        ok(AuthMiddlewareService { service })
    }
}

pub struct AuthMiddlewareService<S> {
    service: S,
}

impl<S> Service<ServiceRequest> for AuthMiddlewareService<S>
where
    S: Service<ServiceRequest, Response = ServiceResponse<BoxBody>, Error = Error> + 'static,
{
    type Response = ServiceResponse<BoxBody>;
    type Error = S::Error;
    type Future = LocalBoxFuture<'static, Result<Self::Response, Self::Error>>;

    fn poll_ready(
        &self,
        cx: &mut std::task::Context<'_>,
    ) -> std::task::Poll<Result<(), Self::Error>> {
        self.service.poll_ready(cx)
    }

    fn call(
        &self,
        service_req: ServiceRequest,
    ) -> Self::Future {
        let auth_config: AuthConfig = Environ::init();
        if Environment::get_env() == Environment::Dev && auth_config.auth_disabled {
            return self.service.call(service_req).boxed_local();
        }

        info!("APILoginVerifier");
        let session = service_req.get_session();
        let user_auth = UserAuth::from(session);
        match user_auth.jwt.clone() {
            Some(jwt) => {
                debug!("JWT found in session");
                if validate_jwt(&jwt).is_some() {
                    // Extract claims from the token
                    debug!("Valid JWT, extracting claims");
                    if get_claims_from(&jwt).is_none() {
                        debug!("Failed to extract claims from JWT, unauthorized");
                        return unauthorized(service_req);
                    }

                    debug!("JWT validation successful, proceeding with request");
                    self.service.call(service_req).boxed_local()
                } else {
                    debug!("JWT validation failed, unauthorized");
                    // JWT validation failed, redirect to login
                    unauthorized(service_req)
                }
            }
            None => {
                debug!("JWT not found in session, unauthorized");
                unauthorized(service_req)
            }
        }
    }
}

// Function to redirect the user to the login page
fn unauthorized(service_req: ServiceRequest) -> LocalBoxFuture<'static, Result<ServiceResponse<BoxBody>, Error>> {
    // Create the HTTP redirect response
    let response = HttpResponse::Unauthorized().finish().map_into_boxed_body();

    // Split the ServiceRequest into parts to create the ServiceResponse
    let (request, _payload) = service_req.into_parts();
    let service_response = ServiceResponse::new(request, response);

    // Return the ServiceResponse in an async block
    async { Ok(service_response) }.boxed_local()
}
