use aarya_entities::models::user_role::UserRole;
use aarya_utils::jwt_ops::get_claims_from;
use actix_service::{Service, Transform};
use actix_session::SessionExt;
use actix_web::{
    body::BoxBody,
    dev::{ServiceRequest, ServiceResponse},
    Error, HttpResponse,
};
use futures::future::{ok, LocalBoxFuture, Ready};
use futures::FutureExt;
use log::{debug, info, warn};

use crate::auth::user::UserAuth;

pub struct InstructorVerifier;

impl<S> Transform<S, ServiceRequest> for InstructorVerifier
where
    S: Service<ServiceRequest, Response = ServiceResponse<BoxBody>, Error = Error> + 'static,
{
    type Response = ServiceResponse<BoxBody>;
    type Error = Error;
    type InitError = ();
    type Transform = AuthMiddlewareService<S>;
    type Future = Ready<Result<Self::Transform, Self::InitError>>;

    fn new_transform(
        &self,
        service: S,
    ) -> Self::Future {
        ok(AuthMiddlewareService { service })
    }
}

pub struct AuthMiddlewareService<S> {
    service: S,
}

impl<S> Service<ServiceRequest> for AuthMiddlewareService<S>
where
    S: Service<ServiceRequest, Response = ServiceResponse<BoxBody>, Error = Error> + 'static,
{
    type Response = ServiceResponse<BoxBody>;
    type Error = S::Error;
    type Future = LocalBoxFuture<'static, Result<Self::Response, Self::Error>>;

    fn poll_ready(
        &self,
        cx: &mut std::task::Context<'_>,
    ) -> std::task::Poll<Result<(), Self::Error>> {
        self.service.poll_ready(cx)
    }

    fn call(
        &self,
        service_req: ServiceRequest,
    ) -> Self::Future {
        info!("InstructorVerifier");
        // retrieve user from the cache
        // this interceptor is called after LoginVerifier
        // so we can assume that the user is logged in
        let session = service_req.get_session();
        let user_auth = UserAuth::from(session);
        let jwt = match user_auth.jwt.clone() {
            Some(j) => j,
            None => {
                warn!("Failed to get jwt from session");
                return redirect_to(service_req, "/");
            }
        };
        let user = get_claims_from(jwt.as_str()).unwrap();
        debug!("User: {:?}", user);
        let role = UserRole::from_email(&user.sub);
        let requires_instructor = service_req.path().contains("/instructor/");
        match role {
            UserRole::Admin | UserRole::Instructor => {
                if requires_instructor {
                    return self.service.call(service_req).boxed_local();
                } else {
                    // if the user is an admin, but the route does not require admin access, redirect to the home page
                    return redirect_to(service_req, "/");
                }
            }
            _ => {
                // if the user is not an admin, redirect to the login page
                if requires_instructor {
                    warn!("{:?} is not an instructor or admin, redirecting to login", user);
                    return redirect_to(service_req, "/");
                }
            }
        }
        self.service.call(service_req).boxed_local()
    }
}

// Function to redirect the user to the login page
fn redirect_to(
    service_req: ServiceRequest,
    location: &str,
) -> LocalBoxFuture<'static, Result<ServiceResponse<BoxBody>, Error>> {
    // Create the HTTP redirect response
    let response = HttpResponse::Found().append_header(("Location", location)).finish().map_into_boxed_body();

    // Split the ServiceRequest into parts to create the ServiceResponse
    let (request, _payload) = service_req.into_parts();
    let service_response = ServiceResponse::new(request, response);

    // Return the ServiceResponse in an async block
    async { Ok(service_response) }.boxed_local()
}
