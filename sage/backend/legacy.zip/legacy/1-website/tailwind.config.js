/** @type {import('tailwindcss').Config} */
module.exports = {
	darkMode: "selector",
	content: ["./assets/pages/**/*.hbs", "./assets/styles/**/*.css"],
	theme: {
		extend: {
			colors: {
				accent: "#D8B43B",
				beige: "#DCCBB2",
				blue: "#4867AA",
				red: "#B96659",
				purple: "#AB7FCD",
			},
			fontFamily: {
				body: ['"Spectral"', "serif"],
				mono: ['"Fira Code"', "monospace"],
				serif: ['"Bitter"', "serif"],
				sans: ['"Noto Sans"', "sans-serif"],
			},
		},
	},
	plugins: [require("@tailwindcss/typography")],
};
