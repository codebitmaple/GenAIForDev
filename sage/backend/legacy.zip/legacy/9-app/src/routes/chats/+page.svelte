<script lang="ts">
	import type { ChatModel } from '$lib/models/chat-models';
	import type { SidebarModel } from '$lib/models/sidebar-model';
	import { ChatStore, SidebarStore } from '$lib/stores';
	import { onDestroy } from 'svelte';

	let groupedChats: Record<string, ChatModel[]>[] | undefined = $state(undefined);

	let unsubChat = ChatStore.subscribe((value) => {
		if (value) {
			groupedChats = value;
		}
	});

	const formatSource = (source: string, chat: ChatModel) => {
		switch (source) {
			case 'topic-followup':
				return `${chat.courseName}: ${chat.unitName}/${chat.topicName}`.replace(/-/g, ' ');
			case 'practice':
				return 'Practice Test';
			case 'answer-recommendations':
				return 'Answer clarifications';
			default:
				return 'Unknown';
		}
	};

	const toSidebarModel = (keys: any) => {
		let sidebarModel: SidebarModel = { h1: [] };
		console.log(keys);
		sidebarModel.h1 = keys.map((key: any) => {
			return {
				title: key,
				link: `#${key}`,
				h2: undefined
			};
		});
		return sidebarModel;
	};

	function getAllKeysFromGroupedChats(
		groupedChats: Record<string, ChatModel[]>[] | undefined
	): string[] {
		if (!groupedChats) {
			return [];
		}

		// Collect keys from each record in the array
		const keys = groupedChats.flatMap((record) => Object.keys(record));
		return keys;
	}

	$effect(() => {
		SidebarStore.set(toSidebarModel(getAllKeysFromGroupedChats(groupedChats)));
	});

	onDestroy(() => {
		unsubChat();
	});
</script>

{#if groupedChats && groupedChats.length > 0}
	{#each groupedChats as group}
		{#each Object.entries(group) as [date, chats]}
			<h2 class="scrollable text-lg font-bold" id={date}>{date}</h2>
			{#each chats as chat}
				<div class="mt-8 flex flex-col gap-8 border-b-2 border-gray-100 dark:border-gray-700">
					<div class="text-xs uppercase text-gray-500 dark:text-gray-400">
						{formatSource(chat.source, chat)}
					</div>
					<div class="flex flex-col gap-4">
						<div class="prose prose-base dark:prose-invert prose-headings:text-base max-w-none">
							{@html chat.question}
						</div>
						<div class="prose prose-base dark:prose-invert prose-headings:text-base max-w-none">
							{@html chat.context}
						</div>
						<div class="prose prose-base dark:prose-invert prose-headings:text-base max-w-none">
							{@html chat.response}
						</div>
					</div>
				</div>
			{/each}
		{/each}
	{/each}
{:else}
	<p>
		<a
			href="/courses"
			class="text-sky-700 hover:text-sky-600 dark:text-sky-500 dark:hover:text-sky-400"
			>Start learning</a
		> to see chats on this page.
	</p>
{/if}
