<script lang="ts">
	import { goto } from '$app/navigation';
	import type { CourseModel } from '$lib/models/course-model.js';
	import type { SidebarModel } from '$lib/models/sidebar-model';
	import { CourseStore, CurrentCourseStore, SidebarStore } from '$lib/stores';

	let courses: CourseModel[] = $state([]);

	CourseStore.subscribe((value) => {
		if (value) {
			courses = value;
		}
	});

	const toSidebarModel = (courses: CourseModel[]) => {
		let sidebarModel: SidebarModel = { h1: [] };

		sidebarModel.h1 = courses.map((course) => {
			return {
				title: course.name,
				link: `#${course.slug}`,
				h2: undefined
			};
		});

		return sidebarModel;
	};

	$effect(() => {
		SidebarStore.set(toSidebarModel(courses));
	});

	const toToc = (course: CourseModel) => {
		if (!course) return;
		CurrentCourseStore.set(course);
		goto(`/units/${course.slug}`);
	};

	const toPractice = (course: CourseModel) => {
		if (!course) return;
		CurrentCourseStore.set(course);
		goto(`/practice/${course.slug}`);
	};
</script>

{#if courses.length === 0}
	<p>Loading...</p>
{:else}
	<div class="flex flex-col gap-16">
		{#each courses as course}
			<div class="flex flex-col gap-2">
				<h1 class="scrollable text-2xl font-semibold uppercase" id={course.slug}>{course.name}</h1>
				<small class="text-gray-500 dark:text-gray-400">Updated: {course.updated}</small>
				<div class="mb-4 mt-4 flex flex-wrap items-center gap-8 text-sm">
					<p class="flex items-center gap-2 border-l-4 border-sky-300 px-2">
						<span class="material-symbols-outlined text-base">group</span>
						{course.students} students
					</p>
					<p class="flex items-center gap-2 border-l-4 border-sky-300 px-2">
						<span class="material-symbols-outlined"> checklist </span>
						{course.units} units
					</p>
					<p class="flex items-center gap-2 border-l-4 border-sky-300 px-2">
						<span class="material-symbols-outlined"> laptop_chromebook </span>
						{course.topics} topics
					</p>
					<p class="flex items-center gap-2 border-l-4 border-sky-300 px-2">
						<span class="material-symbols-outlined">pool</span>
						{course.exams}+ practice tests
					</p>
				</div>
				<p class="italic text-gray-600 dark:text-gray-300">{course.description}</p>
				<p class="mt-4 text-gray-700 dark:text-gray-300">{course.summary}</p>
				<div class="flex gap-4">
					<button
						class="button-primary mt-4 flex items-center gap-2"
						type="button"
						onclick={() => toToc(course)}
					>
						<span class="material-symbols-outlined text-base">owl</span>
						<span>Learn</span>
					</button>
					<button
						class="button-primary mt-4 flex items-center gap-2"
						type="button"
						onclick={() => toPractice(course)}
					>
						<span class="material-symbols-outlined text-base">pool</span>
						<span>Practice Test</span>
					</button>
				</div>
			</div>
		{/each}
	</div>
{/if}
