import ApiCalls from '$lib/api';
import type { UserInfo } from '$lib/models/user-model.js';
import { UserInfoStore } from '$lib/stores.js';

const apiUrl = import.meta.env.VITE_API_BASE_URL;
const baseUrl = import.meta.env.VITE_BASE_URL;
let userInfo: UserInfo | undefined = undefined;

UserInfoStore.subscribe((value) => {
	if (value) userInfo = value;
});

export async function load({ fetch }) {
	if (userInfo) return;
	let response = await ApiCalls.get(`${apiUrl}/user`, fetch);
	if (response.ok) {
		let data = await response.json();
		let userInfo = {
			userKey: data.user_key,
			firstName: data.first_name,
			lastName: data.last_name,
			userAuthenticated: true,
			email: data.email,
			pictureUrl: `${apiUrl}/google/picture`
		};
		UserInfoStore.set(userInfo);
	} else {
		console.error('Failed to load user info');
		if (response.status === 401) {
			window.location.href = `${baseUrl}/login`;
		}
	}
}
