import ApiCalls from '$lib/api';
import { PracticeTestStore, QuestionsStore } from '$lib/stores.js';

const apiUrl = import.meta.env.VITE_API_BASE_URL;
const devEnv = import.meta.env.VITE_ENV_DEV;

export async function load({ fetch, params }) {
	// let questionCount = devEnv ? 3 : 25;
	let questionCount = 25;
	let response = await ApiCalls.post(
		`${apiUrl}/practice-test/questions`,
		{
			course_slug: params.slug,
			question_count: questionCount
		},
		fetch
	);

	if (response.ok) {
		let data = await response.json();
		// console.log(data);
		const questions: any = [];
		let index = 1;
		data.questions.map((question: any) => {
			questions.push({
				index: index++,
				id: question.id,
				question: question.question,
				choices: question.choices,
				difficulty: question.difficulty,
				questionType: question.question_type,
				userAnswers: []
			});
		});
		QuestionsStore.set(questions);
		PracticeTestStore.set({
			questions: questions,
			courseSlug: params.slug,
			questionCount: questionCount,
			courseId: data.course_id,
			practiceId: data.practice_id,
			courseName: data.course_name
		});
	}
}
