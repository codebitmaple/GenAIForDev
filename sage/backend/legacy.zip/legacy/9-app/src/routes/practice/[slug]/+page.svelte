<script lang="ts">
	import { goto } from '$app/navigation';
	import ApiCalls from '$lib/api';
	import Question from '$lib/components/question/question.svelte';
	import type { PracticeTestModel, QuestionModel } from '$lib/models/practice-models';
	import { AnsweredQuestionsStore, PracticeTestStore, QuestionsStore } from '$lib/stores';
	import { onDestroy } from 'svelte';

	const apiUrl = import.meta.env.VITE_API_BASE_URL;

	let practiceTest: PracticeTestModel | undefined = $state(undefined);
	let questions: QuestionModel[] | undefined = $state(undefined);
	let answeredQuestions: QuestionModel[] = $state([]);

	const unsubQuestions = QuestionsStore.subscribe((value) => {
		if (value) {
			questions = value;
		}
	});

	const unsubPractice = PracticeTestStore.subscribe((value) => {
		if (value) {
			practiceTest = value;
		}
	});

	const unsubAnswered = AnsweredQuestionsStore.subscribe((value) => {
		if (value) {
			answeredQuestions = value;
		}
	});

	const onSubmit = () => {
		if (questions === undefined) return;
		if (practiceTest === undefined) return;

		const userAnswers = answeredQuestions.map((question) => {
			return {
				question_id: question.id,
				answers: question.userAnswers
			};
		});
		console.log(userAnswers);

		ApiCalls.post(
			`${apiUrl}/practice-test/answers`,
			{
				test_id: practiceTest.practiceId,
				answers: userAnswers
			},
			fetch
		).then((response) => {
			if (response.ok) {
				console.log('Practice test submitted successfully');
				goto(`/result/practice/${practiceTest?.practiceId}`);
			} else {
				console.log('Error submitting practice test');
			}
		});
	};

	const onExit = () => {
		goto('/courses');
	};

	onDestroy(() => {
		unsubPractice();
		unsubQuestions();
		unsubAnswered();
	});
</script>

<!-- header -->

<section class="mb-8">
	{#if practiceTest}
		<div
			class="items-left flex flex-col gap-2 text-base uppercase text-gray-400 md:ml-[-0.65em] md:flex-row"
		>
			<span class="material-symbols-outlined">pool</span>
			<span class="">Practice Test</span>
			<span class="text-gray-500 dark:text-gray-300">{practiceTest.courseName}</span>
		</div>

		<p class="ml-0 mt-4 border-l-4 border-cyan-400 pl-4 text-sm italic">
			Answer the following {questions?.length} questions
		</p>
	{/if}
</section>

<Question />

<!-- footer -->
<section class="mt-8 flex justify-between">
	{#if answeredQuestions && questions}
		<button class="outline-button" onclick={onExit}>Leave Exercise</button>
		<button
			onclick={onSubmit}
			class="action-button"
			disabled={answeredQuestions.length !== questions.length}>Submit Test</button
		>
	{/if}
</section>
