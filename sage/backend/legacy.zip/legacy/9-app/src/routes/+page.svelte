<script lang="ts">
	import type { UserInfo } from '$lib/models/user-model';
	import { SidebarStore, UserInfoStore } from '$lib/stores';
	let userInfo: UserInfo | undefined = $state(undefined);

	SidebarStore.set({
		h1: []
	});

	UserInfoStore.subscribe((value) => {
		if (value) userInfo = value;
	});
</script>

{#if userInfo}
	<h1>Hello, {userInfo.firstName}</h1>
	<p>
		<a
			href="/courses"
			class="text-sky-700 hover:text-sky-600 dark:text-sky-500 dark:hover:text-sky-400"
			>Go to Courses</a
		>
	</p>
{/if}
