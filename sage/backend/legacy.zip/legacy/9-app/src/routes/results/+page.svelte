<script lang="ts">
	import type { ResultEntry } from '$lib/models/result-model';
	import { GropuedResultsStore, SidebarStore } from '$lib/stores';
	import { onDestroy } from 'svelte';

	let keys: ResultEntry[] | undefined = $state(undefined);

	let unsubscribeGropuedResultsStore = GropuedResultsStore.subscribe((value) => {
		keys = value;
		SidebarStore.set({
			h1: []
		});
	});

	onDestroy(() => {
		unsubscribeGropuedResultsStore();
	});
</script>

{#if keys}
	{#each keys as key}
		<div class="mb-8 flex flex-col">
			<div class="flex flex-col gap-1">
				<p class="uppercase">{key.value.courseName}</p>
				<small>{key.value.questions} questions on {key.value.dateTaken}</small>
			</div>
			<a href="/result/practice/{key.key}" class="dark:text-sky-500 dark:hover:text-sky-400"
				>See result</a
			>
		</div>
	{/each}
{:else}
	<p>
		<a
			href="/courses"
			class="text-sky-700 hover:text-sky-600 dark:text-sky-500 dark:hover:text-sky-400"
			>Start learning</a
		> to see results on this page.
	</p>
{/if}
