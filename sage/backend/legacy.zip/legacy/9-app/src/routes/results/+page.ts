import ApiCalls from '$lib/api';
import type { ResultEntry } from '$lib/models/result-model';
import { GropuedResultsStore } from '$lib/stores';

const apiUrl = import.meta.env.VITE_API_BASE_URL;

export async function load({ fetch }) {
	let response = await ApiCalls.get(`${apiUrl}/results`, fetch);
	if (response.ok) {
		let data = await response.json();
		const keys = Object.keys(data);
		const results: ResultEntry[] = []; // Properly typed array
		keys.forEach((key) => {
			// console.log(data[key]);
			results.push({
				key,
				value: {
					courseName: data[key][0].course_slug,
					questions: data[key].length,
					dateTaken: data[key][0].date_created
				}
			});
		});
		GropuedResultsStore.set(results);
	}
}
