<script lang="ts">
	import { goto } from '$app/navigation';
	import type { CourseModel, TopicModel, UnitModel } from '$lib/models/course-model.js';
	import type { SidebarModel } from '$lib/models/sidebar-model';
	import {
		CurrentCourseStore,
		SidebarStore,
		TopicStore,
		UnitAllStore,
		UnitStore
	} from '$lib/stores';
	import { onDestroy } from 'svelte';
	let units: any = $state();
	let course: CourseModel | undefined = $state();

	let unsubUnit = UnitAllStore.subscribe((value) => {
		units = value;
	});

	let unsubCourse = CurrentCourseStore.subscribe((value) => {
		course = value;
	});

	const onTopicClick = (unit: UnitModel, topic: TopicModel) => {
		if (!course) return;
		TopicStore.set(topic);
		UnitStore.set(unit);
		goto(`/topic/${course.slug}/${unit.slug}/${topic.slug}`);
	};

	const toSidebarModel = (units: UnitModel[], course: CourseModel | undefined) => {
		let sidebarModel: SidebarModel = { h1: [] };

		if (course === undefined) return sidebarModel;

		sidebarModel.h1 = [
			{
				title: course.name,
				link: `/courses`,
				h2: units.map((unit: UnitModel) => {
					return {
						title: unit.name,
						link: `/units/${course.slug}#${unit.slug}`,
						h3: unit.topics.map((topic: TopicModel) => {
							return {
								title: topic.name,
								link: `/topic/${course.slug}/${unit.slug}/${topic.slug}`
							};
						})
					};
				})
			}
		];

		return sidebarModel;
	};

	$effect(() => {
		SidebarStore.set(toSidebarModel(units, course));
	});

	onDestroy(() => {
		unsubCourse();
		unsubUnit();
	});
</script>

{#if units && units.length === 0}
	<p>Loading...</p>
{:else}
	<div class="content flex flex-col gap-8">
		{#if course}
			<a href="/courses"
				><small id={course.slug} class="text-sm uppercase text-sky-500">
					{course.name}
				</small></a
			>
		{/if}
		{#each units as unit}
			<div class="flex flex-col gap-4">
				<h2
					class="text-basse border-b-2 border-gray-200 uppercase text-gray-600 dark:border-gray-800 dark:text-gray-400"
					id={unit.slug}
				>
					{unit.index}: {unit.name}
				</h2>
				{#each unit.topics as topic}
					<div class="flex flex-col gap-4">
						<h3
							class="text-lg capitalize text-gray-700 dark:text-gray-300"
							id="{unit.slug}-{topic.slug}"
						>
							{unit.index}.{topic.index}: {topic.name}
						</h3>
						<p class="text-base text-gray-600 dark:text-gray-400">{topic.description}</p>
						<div class="flex gap-4">
							<button
								onclick={() => onTopicClick(unit, topic)}
								class="flex items-center justify-center gap-2 rounded border border-sky-600 bg-sky-600 p-1 px-4 text-xs text-white shadow"
							>
								<span class="material-symbols-outlined text-base">laptop_chromebook</span><span
									>Study</span
								>
							</button>
							<!-- <button
								class="flex items-center justify-center gap-2 rounded border border-sky-600 bg-sky-600 p-1 px-4 text-xs text-white shadow"
							>
								<span class="material-symbols-outlined text-base"> pool </span><span>Exercise</span>
							</button> -->
						</div>
					</div>
				{/each}
			</div>
		{/each}
	</div>
{/if}

<style>
	[id] {
		scroll-margin-top: 8rem; /* Adjust this value to match your navbar's height */
	}
</style>
