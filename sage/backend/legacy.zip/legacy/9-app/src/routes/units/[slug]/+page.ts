import ApiCalls from '$lib/api';
import type { CourseModel, TopicModel, UnitModel } from '$lib/models/course-model';
import { CurrentCourseStore, SidebarStore, UnitAllStore } from '$lib/stores.js';

const apiUrl = import.meta.env.VITE_API_BASE_URL;
let currentCourse: CourseModel;

CurrentCourseStore.subscribe((value) => {
	if (value) currentCourse = value;
});

export async function load({ fetch, params }) {
	let courseSlug = params.slug;

	let response = await ApiCalls.get(`${apiUrl}/units/${courseSlug}`, fetch);
	if (response.ok) {
		let data = await response.json();
		console.log(data);
		const units: UnitModel[] = [];
		const course: CourseModel = data.course;
		let unitCount = 1;
		console.log(course);

		data.units.forEach((d: any) => {
			let topicIndex = 1;
			units.push({
				index: unitCount++,
				id: d.id,
				name: d.name,
				description: d.description,
				course: course.id,
				slug: d.slug,
				topics: d.topics.map((t: any) => {
					return {
						index: topicIndex++,
						id: t.id,
						name: t.name,
						description: t.description,
						unit: d.id,
						slug: t.slug
					} as TopicModel;
				})
			});
		});
		UnitAllStore.set(units);
		CurrentCourseStore.set(course);
		SidebarStore.set(data.links);
	}

	return null;
}
