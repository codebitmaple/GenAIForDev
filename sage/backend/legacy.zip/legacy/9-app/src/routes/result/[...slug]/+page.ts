import ApiCalls from '$lib/api';
import type { ResultResponse } from '$lib/models/practice-models';
import { ResultStore } from '$lib/stores';

const apiUrl = import.meta.env.VITE_API_BASE_URL;

function getAllValues(map: any) {
	return Array.from(map.values());
}

const toMap = (choices: any) => {
	const map = new Map();
	choices.forEach((choice: any) => {
		map.set(choice.key, choice.value);
	});
	return map;
};

export async function load({ fetch, params }) {
	let parts = params.slug.split('/');
	if (parts.length !== 2) {
		return null;
	}

	let testType = parts[0];
	let testId = parts[1];

	let response = await ApiCalls.get(`${apiUrl}/test/results/${testType}/${testId}`, fetch);
	if (response.ok) {
		let data = await response.json();
		const results: ResultResponse[] = [];
		data.map((result: any) => {
			let choices = toMap(result.choices);
			let choicesArray = getAllValues(choices);
			let userAnswers = result.user_answers.map((answer: any) => choices.get(answer)).join(', ');
			let fullText = {
				Question: result.question,
				Choices: choicesArray.join(', '),
				AnswerExplanation: result.answer_explanation,
				KeyConcept: result.key_concept,
				UserResponse: userAnswers,
				Result: result.correct
			};
			results.push({
				Question: result.question,
				AnswerExplanation: result.answer_explanation,
				Choices: choices,
				CorrectAnswers: result.correct_answers,
				Correct: result.correct,
				UserAnswers: result.user_answers,
				QuestionDifficulty: result.question_difficulty,
				Score: result.score,
				KeyConcept: result.key_concept,
				FullText: JSON.stringify(fullText),
				ExerciseId: result.exercise_id,
				QuestionId: result.question_id,
				CourseSlug: result.course_slug
			});
		});
		ResultStore.set(results);
	}
}
