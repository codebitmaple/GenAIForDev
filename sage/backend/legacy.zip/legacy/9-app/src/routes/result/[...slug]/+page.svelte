<script lang="ts">
	import { goto } from '$app/navigation';
	import ResultFollowup from '$lib/components/followup/result-followup.svelte';
	import type { ResultResponse } from '$lib/models/practice-models';
	import { ResultStore } from '$lib/stores';
	import { onDestroy } from 'svelte';

	let results: ResultResponse[] = $state([]);

	let unsubStore = ResultStore.subscribe((value) => {
		if (value) {
			results = value;
		}
	});

	const onNext = () => {
		goto(`/practice/${results[0].CourseSlug}`);
	};

	const onBack = () => {
		goto('/courses');
	};

	onDestroy(() => {
		unsubStore();
	});
</script>

<div class="flex flex-col gap-8">
	{#each results as result}
		<div class="rounded px-8 py-6 shadow dark:bg-gray-900">
			<div
				class="flex items-center justify-between gap-2 border-b border-gray-200 dark:border-gray-600"
			>
				{#if result.Correct}
					<p class="text-sm font-semibold uppercase text-green-600 dark:text-green-400">Correct</p>
				{:else}
					<p class="text-sm font-semibold uppercase text-red-600 dark:text-red-400">InCorrect</p>
				{/if}
				<div class="mb-2">
					<p class="text-right text-xs uppercase text-gray-400 dark:text-gray-500">🔑 concept</p>
					<p class="text-sm uppercase dark:text-gray-400">{result.KeyConcept}</p>
				</div>
			</div>
			<div class="prose prose-base dark:prose-invert max-w-none pt-4">{@html result.Question}</div>
			<div class="mt-8">
				<p
					class="border-b border-gray-200 pb-2 text-xs font-semibold uppercase dark:border-gray-600"
				>
					Answer
				</p>
				<div class="mt-4">
					{#each Array.from(result.Choices.keys()) as choice}
						<div class="flex items-center gap-2 py-1">
							<div class="w-4">
								{#if result.UserAnswers.includes(choice)}
									{#if result.CorrectAnswers.includes(choice)}
										<p class="">✅</p>
									{:else}
										<p class="">❌</p>
									{/if}
								{/if}
								{#if result.CorrectAnswers.includes(choice) && !result.UserAnswers.includes(choice)}
									<p class="">✅</p>
								{/if}
							</div>
							<div class="prose pros-sm dark:prose-invert">{@html result.Choices.get(choice)}</div>
						</div>
					{/each}
				</div>
			</div>
			<div class="mt-8">
				<p
					class="border-b border-gray-200 pb-2 text-xs font-semibold uppercase dark:border-gray-600"
				>
					reason
				</p>
				<p class="prose prose-sm dark:prose-invert max-w-none pt-4">
					{@html result.AnswerExplanation}
				</p>
			</div>
			<div class="mt-8">
				<ResultFollowup
					markdown={result.FullText}
					followupArgs={{
						IsCorrect: result.Correct,
						FullText: result.FullText,
						TestId: result.ExerciseId,
						QuestionId: result.QuestionId,
						CourseName: result.CourseSlug,
						UnitName: '',
						TopicName: '',
						UserType: 'student',
						TestType: 'practice'
					}}
				/>
			</div>
		</div>
	{/each}
	<div class="flex justify-between">
		<button class="outline-button pb-2" onclick={onBack}>Back to Courses</button>
		<button class="action-button pb-2" onclick={onNext}> Start Over</button>
	</div>
</div>
