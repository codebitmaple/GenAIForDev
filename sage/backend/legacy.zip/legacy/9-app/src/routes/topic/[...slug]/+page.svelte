<script lang="ts">
	import Followup from '$lib/components/followup/followup.svelte';
	import { UserLevel, UserType } from '$lib/models/followup-model';
	import type { SidebarModel } from '$lib/models/sidebar-model';
	import { SidebarStore, TopicAllStore } from '$lib/stores';
	import { mount, tick } from 'svelte';
	import Highlight from 'svelte-highlight';
	import java from 'svelte-highlight/languages/java';
	import atomOneDark from 'svelte-highlight/styles/atom-one-dark';

	let topic: any = $state();
	let contentRef: HTMLDivElement | null = $state(null);
	let extractedHeaders: any[] = $state([]);

	const extractEls = async () => {
		await tick();

		if (!contentRef) {
			return;
		}

		const paragraphs = Array.from(contentRef.querySelectorAll('p:not(ul p)'));

		const pres = Array.from(contentRef.querySelectorAll('pre'));

		const codes = Array.from(contentRef.querySelectorAll('pre code'));

		const uls = Array.from(contentRef.querySelectorAll('ul:not(ul ul)'));

		const headers = Array.from(contentRef.querySelectorAll('h1, h2, h3'));

		paragraphs.forEach((p: any) => insertFollowupAfterElement(p));

		uls.forEach((ul: any) => {
			insertFollowupAfterElement(ul);
		});

		pres.forEach((codeBlock: any) => {
			insertFollowupAfterElement(codeBlock);
		});

		codes.forEach((codeBlock: any) => {
			replaceCode(codeBlock);
		});

		headers.forEach((header: any) => {
			insertAttr(header, 'id', header.innerText.replace(/\s/g, '-').toLowerCase());
		});
	};

	function insertAttr(element: HTMLElement, attr: string, value: string) {
		element.setAttribute(attr, value);
		element.setAttribute('class', 'scrollable');
		extractedHeaders.push({ level: element.tagName, text: element.innerText, id: value });
	}

	function replaceCode(element: HTMLElement) {
		const codeContent = element.innerHTML;
		// Create a placeholder div to mount the Svelte component
		const highlightContainer = document.createElement('div');
		element.replaceWith(highlightContainer);

		mount(Highlight, {
			target: highlightContainer,
			props: { code: codeContent, language: java }
		});
	}

	function insertFollowupAfterElement(element: HTMLElement) {
		let words = element.innerText.split(' ');

		if (words.length < 24) {
			return;
		}

		const followupContainer = document.createElement('div'); // Placeholder div
		element.insertAdjacentElement('afterend', followupContainer);

		let html: any = element.closest('p')?.outerHTML || element.closest('pre')?.outerHTML;

		if (!html) {
			html = element.outerHTML;
		}

		mount(Followup, {
			target: followupContainer,
			props: {
				markdown: html,
				followupArgs: {
					FullText: topic.markdown,
					CourseName: topic.courseSlug,
					UserType: UserType[UserType.HighSchool],
					UserLevel: UserLevel[UserLevel.Intermediate],
					UnitName: topic.unitSlug,
					TopicName: topic.name
				}
			}
		});
	}

	const toSidebarModel = (course: any) => {
		let sidebarModel: SidebarModel = { h1: [] };
		sidebarModel.h1 = extractedHeaders.map((header) => {
			return { title: header.text, link: `#${header.id}`, h2: undefined };
		});
		return sidebarModel;
	};

	TopicAllStore.subscribe((value) => {
		if (value) {
			topic = value;
			console.log('topic state set', topic);
			extractEls();
		}
	});

	$effect(() => {
		SidebarStore.set(toSidebarModel(topic));
	});
</script>

<svelte:head>
	{@html atomOneDark}
</svelte:head>

{#if topic}
	<div class="mb-8 flex items-center gap-2 uppercase">
		<a href="/courses"><small class="text-sky-500">{topic.courseSlug}</small></a>
		<small>&rarr;</small>
		<a href="/units/{topic.courseSlug}"><small class="text-sky-500">{topic.unitSlug}</small></a>
	</div>
	<h1 class="mb-8 text-2xl">{topic.name}</h1>
	<div
		class="prose prose-sm dark:prose-invert prose-pre:p-0 prose-pre:m-0 prose-code:text-base max-w-none"
		bind:this={contentRef}
	>
		{@html topic.markdown}
	</div>
{/if}
