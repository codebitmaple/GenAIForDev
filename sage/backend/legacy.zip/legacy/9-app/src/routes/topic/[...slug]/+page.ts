import ApiCalls from '$lib/api';
import { TopicAllStore } from '$lib/stores.js';
const apiUrl = import.meta.env.VITE_API_BASE_URL;

export async function load({ fetch, params }) {
	if (params.slug) {
		let parts = params.slug.split('/');
		if (parts.length !== 3) {
			return null;
		}

		let courseSlug = parts[0];
		let unitSlug = parts[1];
		let topicSlug = parts[2];

		let response = await ApiCalls.get(
			`${apiUrl}/topic/${courseSlug}/${unitSlug}/${topicSlug}`,
			fetch
		);
		if (response.ok) {
			let data = await response.json();
			// console.log('loading topic:', data);
			let topic = {
				id: data.id,
				description: data.description,
				name: data.name,
				markdown: data.markdown,
				courseSlug: data.course_slug,
				unitSlug: data.unit_slug,
				courseAll: data.course_all
			};
			TopicAllStore.set(topic);
		}
	}
}
