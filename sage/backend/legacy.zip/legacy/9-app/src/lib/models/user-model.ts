export interface UserInfo {
	firstName: string;
	lastName: string;
	userKey: string;
	userAuthenticated: boolean;
	email: string;
	pictureUrl: string;
}
