export interface CourseModel {
	id: string;
	name: string;
	description: string;
	updated: string;
	summary: string;
	disclaimer: string;
	students: number;
	units: number;
	topics: number;
	exercises: number;
	exams: number;
	slug: string;
}

export interface TopicModel {
	index: number;
	id: string;
	name: string;
	description: string;
	course: string;
	unit: string;
	slug: string;
}

export interface UnitModel {
	index: number;
	id: string;
	name: string;
	course: string;
	description: string;
	topics: TopicModel[];
	slug: string;
}

export interface CourseTocModel {
	name: string;
	slug: string;
	id: string;
	description: string;
	units: {
		id: string;
		name: string;
		description: string;
		slug: string;
		topics: {
			id: string;
			name: string;
			description: string;
			slug: string;
		}[];
	}[];
}
