export interface KeyValue {
	key: string;
	value: string;
}

export interface QuestionModel {
	choices: KeyValue[];
	difficulty: string;
	question: string;
	questionType: string;
	id: string;
	index: number;
	userAnswers: string[];
}

export interface PracticeTestModel {
	questions: QuestionModel[];
	courseSlug: string;
	questionCount: number;
	courseId: string;
	practiceId: string;
	courseName: string;
}

export interface ResultResponse {
	Question: string;
	AnswerExplanation: string;
	Choices: Map<string, string>;
	CorrectAnswers: string[];
	Correct: boolean;
	UserAnswers: string[];
	QuestionDifficulty: string;
	Score: number;
	KeyConcept: string;
	FullText: string;
	ExerciseId: string;
	QuestionId: string;
	CourseSlug: string;
}

export interface QuestionResult {
	question: string;
	choices: string[];
	answerExplanation: string;
	keyConcepts: string;
	userResponse: string;
	result: boolean;
}
