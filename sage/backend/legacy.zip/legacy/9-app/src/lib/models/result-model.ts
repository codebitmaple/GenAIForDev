export interface ResultItemModel {
	courseName: string;
	questions: number;
	dateTaken: string;
}

export interface ResultEntry {
	key: string;
	value: ResultItemModel;
}
