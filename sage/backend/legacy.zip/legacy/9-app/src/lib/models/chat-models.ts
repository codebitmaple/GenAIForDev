export interface ChatModel {
	id: string; // MongoDB ObjectId type
	userId: string; // User ID
	timestamp: number; // Unix timestamp in milliseconds
	source: string; // Source identifier
	courseName?: string; // Optional course name
	unitName?: string; // Optional unit name
	topicName?: string; // Optional topic name
	question: string; // Question asked
	context?: string; // Optional context
	response: string; // Response to the question
	date: string;
}
