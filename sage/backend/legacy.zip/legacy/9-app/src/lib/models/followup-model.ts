export enum UserLevel {
	Unknown = -1,
	Beginner = 0,
	Intermediate = 1,
	Advanced = 2
}

export enum UserType {
	Unknown = -1,
	HighSchool = 0,
	Professional = 1
}

export interface FollowupArgs {
	FullText: string;
	CourseName: string;
	UserType: string;
	UserLevel: string;
	UnitName: string;
	TopicName: string;
}

export interface ExerciseFollowupArgs {
	FullText: string;
	TestId: string;
	QuestionId: string;
	CourseName: string;
	UserType: string;
	UnitName?: string;
	TopicName?: string;
	IsCorrect: boolean;
	TestType: string;
}

export interface FollowupModel {
	description: string;
	followups: string[];
	summary: string;
}

export interface FollowupQuestionModel {
	question: string | undefined;
}
