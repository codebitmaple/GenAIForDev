export interface SidebarModel {
	h1: {
		title: string | undefined;
		link: string | undefined;
		h2:
			| {
					title: string;
					link: string;
					h3:
						| {
								title: string;
								link: string;
						  }[]
						| undefined;
			  }[]
			| undefined;
	}[];
}
