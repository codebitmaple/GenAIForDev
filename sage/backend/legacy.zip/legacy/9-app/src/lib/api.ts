const baseUrl = import.meta.env.VITE_BASE_URL;

const ApiCalls = {
	get: async (url: string, fetch: any) => {
		console.log('GET call:', url);
		const response = await fetch(url, {
			method: 'GET',
			credentials: 'include',
			headers: {
				'Content-Type': 'application/json'
			}
		});

		if (response.status === 401) {
			window.location.href = `${baseUrl}/login`;
		}

		return response;
	},
	post: async (url: string, data: any = {}, fetch: any) => {
		console.log('POST call:', url);
		const response = await fetch(url, {
			method: 'POST',
			credentials: 'include',
			headers: {
				'Content-Type': 'application/json'
			},
			body: JSON.stringify(data)
		});

		if (response.status === 401) {
			window.location.href = `${baseUrl}/login`;
		}

		return response;
	}
};

export default ApiCalls;
