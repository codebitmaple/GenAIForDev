<script lang="ts">
	import type { QuestionModel } from '$lib/models/practice-models';
	import { AnsweredQuestionsStore, QuestionsStore } from '$lib/stores';
	import { onDestroy } from 'svelte';

	let questions: QuestionModel[] | undefined = $state(undefined);
	let answeredQuestions: QuestionModel[] = $state([]);

	const unsubQuestions = QuestionsStore.subscribe((value) => {
		if (value) {
			questions = value;
		}
	});

	const unsubAnswered = AnsweredQuestionsStore.subscribe((value) => {
		if (value) {
			answeredQuestions = value;
		}
	});

	onDestroy(() => {
		unsubQuestions();
		unsubAnswered();
	});

	const onCheckboxClick = (question: QuestionModel, key: string, e: MouseEvent) => {
		if (!(e.target instanceof HTMLInputElement)) return;

		const isChecked = e.target.checked;

		// Update userAnswers based on the checkbox state
		if (isChecked) {
			if (!question.userAnswers.includes(key)) {
				question.userAnswers = [...question.userAnswers, key];
			}
		} else {
			question.userAnswers = question.userAnswers.filter((k) => k !== key);
		}

		// Update answeredQuestions list
		if (question.userAnswers.length > 0) {
			if (!answeredQuestions.some((q) => q.id === question.id)) {
				answeredQuestions = [...answeredQuestions, question];
			}
		} else {
			answeredQuestions = answeredQuestions.filter((q) => q.id !== question.id);
		}
		console.log($state.snapshot(answeredQuestions).length, $state.snapshot(questions)?.length);
		AnsweredQuestionsStore.set(answeredQuestions);
	};

	const onRadioClick = (question: QuestionModel, key: string) => {
		question.userAnswers = [key];
		if (answeredQuestions.findIndex((q) => q.id === question.id) !== -1) {
			answeredQuestions = answeredQuestions.filter((q) => q.id !== question.id);
		}
		answeredQuestions = [...answeredQuestions, question];
		console.log($state.snapshot(answeredQuestions).length, $state.snapshot(questions)?.length);
		AnsweredQuestionsStore.set(answeredQuestions);
	};
</script>

<!-- body -->
<section>
	{#if questions}
		{#each questions as question}
			<div class="mt-8 border-b-2 border-gray-100 py-2 dark:border-gray-700">
				<div class="mb-8">
					<p class="text-xs uppercase text-gray-400">
						Question {question.index}
					</p>
					<div class="prose prose-lg dark:prose-invert max-w-none">
						{@html question.question}
					</div>
				</div>
				<div class="mb-8">
					{#each question.choices as choice}
						<div class="mb-4">
							{#if question.questionType === 'MultipleChoice'}
								<label class="flex items-center">
									<input
										type="checkbox"
										name={question.id}
										value={choice.key}
										class="mr-2"
										onclick={(e) => onCheckboxClick(question, choice.key, e)}
									/>
									<span class="prose prose-lg dark:prose-invert max-w-none"
										>{@html choice.value}</span
									>
								</label>
							{:else}
								<label class="flex items-center">
									<input
										type="radio"
										name={question.id}
										value={choice.key}
										class="mr-2"
										onclick={() => onRadioClick(question, choice.key)}
									/>
									<span class="prose prose-lg dark:prose-invert max-w-none"
										>{@html choice.value}</span
									>
								</label>
							{/if}
						</div>
					{/each}
				</div>
			</div>
		{/each}
	{/if}
</section>
