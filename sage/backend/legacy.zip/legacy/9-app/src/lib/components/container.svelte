<script lang="ts">
	import Navbar from './sidebar/navbar.svelte';
</script>

<Navbar />

<div class="p-4 sm:ml-64 sm:mr-64 xl:mr-72">
	<div class="mx-auto max-w-screen-lg">
		<div class="mt-14 rounded-lg p-4">
			<slot />
		</div>
	</div>
</div>
