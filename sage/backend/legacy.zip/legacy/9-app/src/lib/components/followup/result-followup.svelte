<script lang="ts">
	import ApiCalls from '$lib/api';
	import type { ExerciseFollowupArgs, FollowupModel } from '$lib/models/followup-model';
	import Loading from '../loading.svelte';

	const apiUrl = import.meta.env.VITE_API_BASE_URL;

	let { followupArgs, markdown }: { followupArgs: ExerciseFollowupArgs; markdown: string } =
		$props();

	let isLoading = $state(false);
	let questions = $state<string[]>([]);
	let showAsk = $state(true);
	let showRecommendation = $state(true);
	let recommendation = $state<string>('');
	let followups = $state<FollowupModel[]>([]);
	let latestDivRef = $state<HTMLDivElement | null>(null);

	$effect(() => {
		latestDivRef?.scrollIntoView({ behavior: 'smooth' });
	});

	const generateRecommendations = async () => {
		isLoading = true;
		let body = {
			question: markdown,
			context: followupArgs.FullText,
			test_id: followupArgs.TestId,
			question_id: followupArgs.QuestionId,
			course_name: followupArgs.CourseName,
			unit_name: followupArgs.UnitName,
			topic_name: followupArgs.TopicName,
			user_type: followupArgs.UserType,
			is_correct: followupArgs.IsCorrect,
			test_type: followupArgs.TestType
		};

		let response = await ApiCalls.post(`${apiUrl}/answer/recommendations`, body, fetch);

		if (response.ok) {
			let data = await response.json();
			// console.log(data);
			recommendation = data;
			isLoading = false;
			showRecommendation = false;
		} else {
			console.log('Error loading tutorial');
			isLoading = false;
		}
	};

	const generateFollowupQuestions = async () => {
		isLoading = true;
		let body = {
			question: markdown,
			context: followupArgs.FullText,
			test_id: followupArgs.TestId,
			question_id: followupArgs.QuestionId,
			course_name: followupArgs.CourseName,
			unit_name: followupArgs.UnitName,
			topic_name: followupArgs.TopicName,
			user_type: followupArgs.UserType,
			is_correct: followupArgs.IsCorrect,
			test_type: followupArgs.TestType
		};

		let response = await ApiCalls.post(`${apiUrl}/answer/followup`, body, fetch);

		if (response.ok) {
			let data = await response.json();
			data = JSON.parse(data);
			questions = data.followups;
			isLoading = false;
			showAsk = false;
		} else {
			console.log('Error loading tutorial');
			isLoading = false;
		}
	};

	const generateExplanationWithFollowups = async (question: string, e: any) => {
		isLoading = true;
		let body = {
			question: question,
			context: markdown,
			test_id: followupArgs.TestId,
			question_id: followupArgs.QuestionId,
			course_name: followupArgs.CourseName,
			unit_name: followupArgs.UnitName,
			topic_name: followupArgs.TopicName,
			user_type: followupArgs.UserType,
			is_correct: followupArgs.IsCorrect,
			test_type: followupArgs.TestType
		};

		let response = await ApiCalls.post(`${apiUrl}/answer/followup/response`, body, fetch);

		if (response.ok) {
			let data = await response.json();
			data = JSON.parse(data);
			followups.push(data);
			isLoading = false;
			followups = [...followups];
			e.target.style.display = 'none';
		} else {
			console.log('Error loading tutorial');
			isLoading = false;
		}
	};
</script>

<div>
	<div class="flex flex-col gap-2">
		{#each questions as question}
			<button
				class="follow-button flex items-center gap-1 text-sm"
				disabled={isLoading}
				onclick={(e) => generateExplanationWithFollowups(question, e)}
			>
				<span class="material-symbols-outlined text-base">owl</span>{question}
			</button>
		{/each}
		{#if showAsk}
			<button
				class="follow-button flex items-center gap-1 text-sm"
				disabled={isLoading}
				onclick={generateFollowupQuestions}
			>
				<span class="material-symbols-outlined text-base">owl</span> Show Clarifying Questions
			</button>
		{/if}
		{#if showRecommendation}
			<button
				class="action-button flex items-center gap-1 text-sm"
				disabled={isLoading}
				onclick={generateRecommendations}
			>
				<span class="material-symbols-outlined text-base">book</span> Show Recommendations
			</button>
		{/if}
	</div>
	{#if recommendation}
		<div class="border-l-2 border-yellow-600 pl-4 dark:border-yellow-400">
			<div class="prose prose-base dark:prose-invert prose-headings:text-base mb-4 mt-8 max-w-none">
				{@html recommendation}
			</div>
		</div>
	{/if}
	{#each followups as followup}
		<div class="border-l-2 border-yellow-600 pl-4 dark:border-yellow-400">
			<div class="scrollable mt-16" bind:this={latestDivRef}></div>
			<div class="prose prose-base dark:prose-invert prose-headings:text-base mb-4 mt-8 max-w-none">
				{@html followup.description}
			</div>
			<div class="flex flex-col gap-2">
				{#each followup.followups as followupInner}
					<button
						class="follow-button flex items-center gap-2 text-sm"
						disabled={isLoading}
						onclick={(e) => generateExplanationWithFollowups(followupInner, e)}
					>
						<span class="material-symbols-outlined text-base">owl</span>{followupInner}
					</button>
				{/each}
			</div>
		</div>
	{/each}

	<Loading {isLoading} />
</div>

<style>
	.scrollable {
		scroll-margin-top: 8rem; /* Adjust this value to match your navbar's height */
	}
</style>
