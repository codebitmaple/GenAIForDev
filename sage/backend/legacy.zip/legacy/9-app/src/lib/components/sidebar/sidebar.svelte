<script lang="ts">
	import SidebarItem from './sidebar-item.svelte';
	import { page } from '$app/stores';
	let isCourseActive = $state(false);
	$effect(() => {
		isCourseActive =
			$page.url.pathname === '/courses' ||
			$page.url.pathname.includes('/units') ||
			$page.url.pathname.includes('/topic') ||
			$page.url.pathname.includes('/practice') ||
			$page.url.pathname.includes('/result/');
	});
</script>

<aside
	id="logo-sidebar"
	class="fixed left-0 top-0 z-40 h-screen w-64 -translate-x-full border-r border-gray-200 bg-white pt-20 transition-transform sm:translate-x-0 dark:border-gray-800 dark:bg-gray-900"
	aria-label="Sidebar"
>
	<div class="h-full overflow-y-auto bg-white px-3 pb-4 dark:bg-gray-900">
		<ul class="space-y-2 font-medium">
			<SidebarItem href="/" label="Home" icon="home" isActive={$page.url.pathname === '/'} />
			<SidebarItem href="/courses" label="Courses" icon="book" isActive={isCourseActive} />
			<SidebarItem
				href="/chats"
				label="Chats"
				icon="chat"
				isActive={$page.url.pathname === '/chats'}
			/>
			<SidebarItem
				href="/results"
				label="Results"
				icon="analytics"
				isActive={$page.url.pathname === '/results'}
			/>
			<!-- <SidebarItem
				href="/settings"
				label="Settings"
				icon="settings"
				isActive={$page.url.pathname === '/settings'}
			/> -->
		</ul>
	</div>
</aside>
