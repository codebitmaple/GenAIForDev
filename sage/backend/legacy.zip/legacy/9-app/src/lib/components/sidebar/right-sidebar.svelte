<script lang="ts">
	import type { SidebarModel } from '$lib/models/sidebar-model';
	import { SidebarStore } from '$lib/stores';
	import { onDestroy } from 'svelte';

	let sidebarData: SidebarModel | undefined = $state(undefined);

	let unsubscribeCourse = SidebarStore.subscribe((value: any) => {
		if (value) {
			sidebarData = value;
		}
	});

	onDestroy(() => {
		unsubscribeCourse();
	});
</script>

<aside
	id="logo-sidebar"
	class="fixed right-0 top-0 z-40 h-screen w-0 border-l border-gray-200 bg-white pt-20 transition-transform xl:w-72 dark:border-gray-800 dark:bg-gray-900"
	aria-label="Sidebar"
>
	<h2 class="flex items-center pb-4 pl-2 text-sm text-gray-400 dark:text-gray-500">
		<span class="material-symbols-outlined">list</span>
		<span class="ml-2">On this page</span>
	</h2>
	<div class="toc h-full overflow-y-auto bg-white px-3 pb-4 dark:bg-gray-900">
		{#if sidebarData?.h1 && sidebarData.h1.length > 0}
			<ul>
				{#each sidebarData.h1 as h1Item}
					<li>
						<a href={h1Item.link}>
							<small class="hover:text-sky-400 dark:text-gray-400 dark:hover:text-sky-300">
								{h1Item.title}
							</small>
						</a>

						<!-- Render h2 -->
						{#if h1Item.h2}
							<ul class="ml-2 mt-2">
								{#each h1Item.h2 as h2Item}
									<li>
										<a href={h2Item.link}>
											<small
												class="overflow-clip hover:text-sky-400 dark:text-gray-400 dark:hover:text-sky-300"
											>
												{h2Item.title}
											</small>
										</a>
									</li>

									<!-- Render h3 -->
									{#if h2Item.h3}
										<ul class="ml-2">
											{#each h2Item.h3 as h3Item}
												<li>
													<a href={h3Item.link}>
														<small
															class="line-clamp-1 hover:text-sky-400 dark:text-gray-400 dark:hover:text-sky-300"
														>
															{h3Item.title}
														</small>
													</a>
												</li>
											{/each}
										</ul>
									{/if}
								{/each}
							</ul>
						{/if}
					</li>
				{/each}
			</ul>
		{:else}
			<p class="text-xs text-gray-500 dark:text-gray-400">💭 Nothing to show yet</p>
		{/if}
	</div>
</aside>
