<script lang="ts">
	export let href = '/';
	export let label = '';
	export let icon = '';
	export let isActive = false;
</script>

<li>
	<a
		{href}
		class="group flex items-center rounded p-2 text-xs {isActive
			? 'active'
			: 'text-gray-900 dark:text-gray-300'}"
	>
		<span class="material-symbols-outlined text-sm">{icon}</span>
		<span class="ms-3">{label}</span>
	</a>
</li>
