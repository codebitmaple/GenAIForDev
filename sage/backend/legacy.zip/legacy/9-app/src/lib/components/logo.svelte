<script lang="ts">
	import { LogoStore } from '$lib/stores';
	import { onDestroy } from 'svelte';

	let image = '/aarya-w.svg';
	let alt = 'Aarya AI Logo';
	let href = '/';
	let text = 'Aarya AI';

	let unsubscribeLogoStore = LogoStore.subscribe((value) => {
		image = value;
	});

	onDestroy(() => {
		unsubscribeLogoStore();
	});
</script>

{#if image}
	<a {href} class="ms-2 flex items-center md:me-24">
		<img src={image} class="me-3 h-6" {alt} />
		<span class="self-center whitespace-nowrap text-lg font-semibold dark:text-white">{text}</span>
	</a>
{/if}
