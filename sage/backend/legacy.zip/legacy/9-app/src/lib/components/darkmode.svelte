<script lang="ts">
	import { LogoStore } from '$lib/stores';
	import { onMount } from 'svelte';

	let isDarkTheme = false;

	onMount(() => {
		const userPreference = localStorage.getItem('color-theme');
		const systemPrefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches;

		if (userPreference === 'dark' || (!userPreference && systemPrefersDark)) {
			document.documentElement.classList.add('dark');
			isDarkTheme = true;
			LogoStore.set('/aarya-w.svg');
		} else {
			LogoStore.set('/aarya.svg');
		}
	});

	function toggleTheme() {
		isDarkTheme = !isDarkTheme;
		if (isDarkTheme) {
			document.documentElement.classList.add('dark');
			localStorage.setItem('color-theme', 'dark');
			LogoStore.set('/aarya-w.svg');
		} else {
			document.documentElement.classList.remove('dark');
			localStorage.setItem('color-theme', 'light');
			LogoStore.set('/aarya.svg');
		}
	}
</script>

<!-- Theme toggle button -->
<button id="theme-toggle" on:click={toggleTheme} class="ml-4 flex items-center">
	<!-- Dark Icon -->
	{#if !isDarkTheme}
		<span class="material-symbols-outlined"> light_mode </span>
	{/if}

	<!-- Light Icon -->
	{#if isDarkTheme}
		<span class="material-symbols-outlined"> dark_mode </span>
	{/if}
</button>
