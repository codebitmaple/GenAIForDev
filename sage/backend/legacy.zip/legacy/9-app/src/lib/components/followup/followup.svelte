<script lang="ts">
	import ApiCalls from '$lib/api';
	import { mount, tick } from 'svelte';
	import Loading from '../loading.svelte';
	import Highlight from 'svelte-highlight';
	import java from 'svelte-highlight/languages/java';
	import type { FollowupArgs, FollowupModel } from '$lib/models/followup-model';

	let contentRef: HTMLDivElement | null = $state(null);

	let { followupArgs, markdown }: { followupArgs: FollowupArgs; markdown: string } = $props();

	const apiUrl = import.meta.env.VITE_API_BASE_URL;

	let isLoading = $state(false);
	let questions: string[] = $state([]);
	let showAsk = $state(true);
	let followups: FollowupModel[] = $state([]);
	let latestDivRef: HTMLDivElement | null = $state(null);

	const extractEls = async () => {
		await tick();

		if (!contentRef) {
			return;
		}

		const codes = Array.from(contentRef.querySelectorAll('pre code'));

		codes.forEach((codeBlock: any) => {
			replaceCode(codeBlock);
		});
	};

	function replaceCode(element: HTMLElement) {
		const codeContent = element.innerHTML;
		// Create a placeholder div to mount the Svelte component
		const highlightContainer = document.createElement('div');
		element.replaceWith(highlightContainer);

		mount(Highlight, {
			target: highlightContainer,
			props: { code: codeContent, language: java }
		});
	}

	$effect(() => {
		if (latestDivRef) {
			latestDivRef.scrollIntoView({ behavior: 'smooth' });
		}
		if (contentRef) {
			extractEls();
		}
	});

	const generateFollowupQuestions = async () => {
		isLoading = true;
		let body = {
			question: markdown,
			context: followupArgs.FullText,
			course_name: followupArgs.CourseName,
			user_type: followupArgs.UserType,
			user_level: followupArgs.UserLevel,
			unit_name: followupArgs.UnitName,
			topic_name: followupArgs.TopicName
		};

		console.log(body);

		let response = await ApiCalls.post(`${apiUrl}/topic/followup`, body, fetch);

		if (response.ok) {
			let data = await response.json();
			data = JSON.parse(data);
			questions = data.followups;
			isLoading = false;
			showAsk = false;
		} else {
			console.log('Error loading tutorial');
			isLoading = false;
		}
	};

	const generateExplanationWithFollowups = async (question: string, e: any) => {
		isLoading = true;
		let body = {
			question: question,
			context: markdown,
			course_name: followupArgs.CourseName,
			user_type: followupArgs.UserType,
			user_level: followupArgs.UserLevel,
			unit_name: followupArgs.UnitName,
			topic_name: followupArgs.TopicName
		};

		let response = await ApiCalls.post(`${apiUrl}/topic/followup/answer`, body, fetch);

		if (response.ok) {
			let data = await response.json();
			data = JSON.parse(data);
			console.log(data);
			followups.push(data);
			isLoading = false;
			followups = [...followups];
			e.target.parentElement.style.display = 'none';
		} else {
			console.log('Error loading tutorial');
			isLoading = false;
		}
	};
</script>

<div class="mb-4 mt-4">
	<div class="flex flex-col gap-2">
		{#each questions as question}
			<button
				class="follow-button"
				disabled={isLoading}
				onclick={(e) => generateExplanationWithFollowups(question, e)}
			>
				<span class="material-symbols-outlined text-base">owl</span>
				<span>{question}</span>
			</button>
		{/each}
		{#if showAsk}
			<button class="follow-button" disabled={isLoading} onclick={generateFollowupQuestions}>
				<span class="material-symbols-outlined text-base">owl</span>
				<span>Show Clarifying Questions</span>
			</button>
		{/if}
	</div>
	{#each followups as followup}
		<div class="border-l border-yellow-300 pl-4 dark:border-yellow-500">
			<div class="scrollable mt-16" bind:this={latestDivRef}></div>
			<div
				class="prose prose-sm dark:prose-invert prose-headings:text-base mb-4 mt-8 max-w-none"
				bind:this={contentRef}
			>
				{@html followup.description}
			</div>
			<div class="flex flex-col gap-2">
				{#each followup.followups as followupInner}
					<button
						class="follow-inner-button"
						disabled={isLoading}
						onclick={(e) => generateExplanationWithFollowups(followupInner, e)}
					>
						<span class="material-symbols-outlined text-base">lightbulb</span>
						<span>{followupInner}</span>
					</button>
				{/each}
			</div>
		</div>
	{/each}

	<Loading {isLoading} />
</div>
