<script lang="ts">
	export let isLoading = false;

	// Array of messages to choose from
	let messages = [
		'Optimizing prompts...',
		'Processing data...',
		'Generating response...',
		'Fetching insights...',
		'Analyzing...'
	];
	let currentMessage = 'Thinking...';
	let intervalId: number = 0;

	// Function to pick a random message from the array
	function getNextMessage(index: number = 0) {
		index = index % messages.length;
		return messages[index];
	}

	// Function to set the message at random intervals
	function startChangingMessages() {
		if (intervalId) clearInterval(intervalId); // Clear previous interval if it exists
		let index = 0;
		intervalId = setInterval(() => {
			currentMessage = getNextMessage(index++);
			const randomInterval = Math.floor(Math.random() * 2000) + 2000; // Random interval between 2000ms and 4000ms
			clearInterval(intervalId); // Clear the interval before setting a new one
			intervalId = setInterval(() => {
				currentMessage = getNextMessage();
			}, randomInterval);
		}, 2000); // First message change after 1 second
	}

	// Watch for when isLoading becomes true to start changing the message
	$: if (isLoading) {
		startChangingMessages();
	} else {
		clearInterval(intervalId); // Clear the interval when isLoading becomes false
	}
</script>

{#if isLoading}
	<div class="my-4">
		<p class="gradient-text mb-2 animate-pulse font-semibold">{currentMessage}</p>
	</div>
{/if}
