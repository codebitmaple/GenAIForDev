import typography from '@tailwindcss/typography';
import flowbite from 'flowbite/plugin';
import type { Config } from 'tailwindcss';

export default {
	content: ['./src/**/*.{html,js,svelte,ts}', './node_modules/flowbite/**/*.js'],

	theme: {
		extend: {
			colors: {
				accent: '#D8B43B',
				beige: '#DCCBB2',
				blue: '#4867AA',
				red: '#B96659',
				purple: '#AB7FCD',
				sky: {
					'50': '#f0f9ff',
					'100': '#e0f2fe',
					'200': '#bae6fd',
					'300': '#7dd3fc',
					'400': '#38bdf8',
					'500': '#0ea5e9',
					'600': '#0284c7',
					'700': '#0369a1',
					'800': '#075985',
					'900': '#0c4a6e',
					'950': '#082f49'
				},
				cyan: {
					'50': '#ecfeff',
					'100': '#cffafe',
					'200': '#a5f3fc',
					'300': '#67e8f9',
					'400': '#22d3ee',
					'500': '#06b6d4',
					'600': '#0891b2',
					'700': '#0e7490',
					'800': '#155e75',
					'900': '#164e63',
					'950': '#083344'
				},
				yellow: {
					'50': '#fefce8',
					'100': '#fef9c3',
					'200': '#fef08a',
					'300': '#fde047',
					'400': '#facc15',
					'500': '#eab308',
					'600': '#ca8a04',
					'700': '#a16207',
					'800': '#854d0e',
					'900': '#713f12',
					'950': '#422006'
				}
			},
			fontFamily: {
				serif: ['"Spectral"', 'serif'],
				mono: ['"Fira Code"', 'monospace'],
				sans: ['"Noto Sans"', 'sans-serif']
			}
		}
	},

	plugins: [typography, flowbite]
} satisfies Config;
