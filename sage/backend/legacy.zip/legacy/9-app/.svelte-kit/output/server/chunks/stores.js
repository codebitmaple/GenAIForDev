import { w as writable } from "./index2.js";
const LogoStore = writable("");
const CourseStore = writable();
const CurrentCourseStore = writable();
const SidebarStore = writable();
const TopicAllStore = writable();
const UnitAllStore = writable();
const PracticeTestStore = writable();
const ResultStore = writable();
const QuestionsStore = writable();
const AnsweredQuestionsStore = writable();
const ChatStore = writable();
const GropuedResultsStore = writable();
const UserInfoStore = writable();
export {
  AnsweredQuestionsStore as A,
  ChatStore as C,
  GropuedResultsStore as G,
  LogoStore as L,
  PracticeTestStore as P,
  QuestionsStore as Q,
  ResultStore as R,
  SidebarStore as S,
  TopicAllStore as T,
  UserInfoStore as U,
  CourseStore as a,
  UnitAllStore as b,
  CurrentCourseStore as c
};
