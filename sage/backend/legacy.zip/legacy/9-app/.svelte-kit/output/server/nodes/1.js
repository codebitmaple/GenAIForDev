

export const index = 1;
let component_cache;
export const component = async () => component_cache ??= (await import('../entries/fallbacks/error.svelte.js')).default;
export const imports = ["_app/immutable/nodes/1.Sku2s73F.js","_app/immutable/chunks/disclose-version.I-RjJhnD.js","_app/immutable/chunks/runtime.Cwp630e2.js","_app/immutable/chunks/legacy.DCghlM8i.js","_app/immutable/chunks/lifecycle.Bq7wBMyP.js","_app/immutable/chunks/store.BmkDAs3D.js","_app/immutable/chunks/stores.BB2SkRRq.js","_app/immutable/chunks/entry.h2gTVBox.js","_app/immutable/chunks/index.B9cgvAar.js"];
export const stylesheets = [];
export const fonts = [];
