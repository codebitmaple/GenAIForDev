import { A as ApiCalls } from "../../../chunks/api.js";
import { C as ChatStore } from "../../../chunks/stores.js";
const apiUrl = "https://aarya.ai/api";
function groupByDate(data) {
  const groupedData = [];
  const grouped = data.reduce((acc, curr) => {
    const date = curr.date;
    if (!acc[date]) {
      acc[date] = [];
    }
    acc[date].push(curr);
    return acc;
  }, {});
  for (const key in grouped) {
    groupedData.push({ [key]: grouped[key] });
  }
  return groupedData;
}
const formatQuestion = (response, source) => {
  switch (source) {
    case "practice":
      return response;
    case "answer-recommendations":
      return JSON.parse(response).Question;
    case "topic-followup":
    default:
      return response;
  }
};
const formatContext = (context, source) => {
  switch (source) {
    case "practice":
      return JSON.parse(context).Question;
    case "answer-recommendations":
      return JSON.parse(context).Question;
    case "topic-followup":
    default:
      return context;
  }
};
const formatResponse = (response, source) => {
  switch (source) {
    case "practice":
      return JSON.parse(response).description;
    case "answer-recommendations":
      return response;
    case "topic-followup":
      return JSON.parse(response).description;
    default:
      return response;
  }
};
async function load({ fetch }) {
  const response = await ApiCalls.get(`${apiUrl}/chats`, fetch);
  if (response.ok) {
    const result = await response.json();
    const chats = [];
    result.map((r) => {
      chats.push({
        id: r._id.$oid,
        userId: r.user_id,
        timestamp: r.timestamp,
        source: r.source,
        courseName: r.course_name,
        unitName: r.unit_name,
        topicName: r.topic_name,
        question: formatQuestion(r.question, r.source),
        context: formatContext(r.context, r.source),
        response: formatResponse(r.response, r.source),
        date: r.date
      });
    });
    const groupedData = groupByDate(chats);
    ChatStore.set(groupedData);
  }
}
export {
  load
};
