import { N as pop, K as push, O as attr, P as escape_html, Q as bind_props, R as ensure_array_like, S as stringify, T as store_get, V as unsubscribe_stores, W as slot } from "../../chunks/index.js";
import { L as LogoStore, S as SidebarStore, U as UserInfoStore } from "../../chunks/stores.js";
import { o as onDestroy } from "../../chunks/index-server.js";
import { f as fallback } from "../../chunks/utils.js";
import { p as page } from "../../chunks/stores2.js";
function Darkmode($$payload, $$props) {
  push();
  $$payload.out += `<button id="theme-toggle" class="ml-4 flex items-center">`;
  {
    $$payload.out += "<!--[-->";
    $$payload.out += `<span class="material-symbols-outlined">light_mode</span>`;
  }
  $$payload.out += `<!--]--> `;
  {
    $$payload.out += "<!--[!-->";
  }
  $$payload.out += `<!--]--></button>`;
  pop();
}
function Logo($$payload, $$props) {
  push();
  let image = "/aarya-w.svg";
  let alt = "Aarya AI Logo";
  let href = "/";
  let text = "Aarya AI";
  let unsubscribeLogoStore = LogoStore.subscribe((value) => {
    image = value;
  });
  onDestroy(() => {
    unsubscribeLogoStore();
  });
  if (image) {
    $$payload.out += "<!--[-->";
    $$payload.out += `<a${attr("href", href)} class="ms-2 flex items-center md:me-24"><img${attr("src", image)} class="me-3 h-6"${attr("alt", alt)}> <span class="self-center whitespace-nowrap text-lg font-semibold dark:text-white">${escape_html(text)}</span></a>`;
  } else {
    $$payload.out += "<!--[!-->";
  }
  $$payload.out += `<!--]-->`;
  pop();
}
function Menu_item($$payload, $$props) {
  let href = fallback($$props["href"], "/");
  let label = fallback($$props["label"], "");
  $$payload.out += `<li><a${attr("href", href)} class="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100 dark:text-gray-300 dark:hover:bg-gray-600 dark:hover:text-white" role="menuitem">${escape_html(label)}</a></li>`;
  bind_props($$props, { href, label });
}
function Right_sidebar($$payload, $$props) {
  push();
  let sidebarData = void 0;
  let unsubscribeCourse = SidebarStore.subscribe((value) => {
    if (value) {
      sidebarData = value;
    }
  });
  onDestroy(() => {
    unsubscribeCourse();
  });
  $$payload.out += `<aside id="logo-sidebar" class="fixed right-0 top-0 z-40 h-screen w-0 border-l border-gray-200 bg-white pt-20 transition-transform xl:w-72 dark:border-gray-800 dark:bg-gray-900" aria-label="Sidebar"><h2 class="flex items-center pb-4 pl-2 text-sm text-gray-400 dark:text-gray-500"><span class="material-symbols-outlined">list</span> <span class="ml-2">On this page</span></h2> <div class="toc h-full overflow-y-auto bg-white px-3 pb-4 dark:bg-gray-900">`;
  if (sidebarData?.h1 && sidebarData.h1.length > 0) {
    $$payload.out += "<!--[-->";
    const each_array = ensure_array_like(sidebarData.h1);
    $$payload.out += `<ul><!--[-->`;
    for (let $$index_2 = 0, $$length = each_array.length; $$index_2 < $$length; $$index_2++) {
      let h1Item = each_array[$$index_2];
      $$payload.out += `<li><a${attr("href", h1Item.link)}><small class="hover:text-sky-400 dark:text-gray-400 dark:hover:text-sky-300">${escape_html(h1Item.title)}</small></a> `;
      if (h1Item.h2) {
        $$payload.out += "<!--[-->";
        const each_array_1 = ensure_array_like(h1Item.h2);
        $$payload.out += `<ul class="ml-2 mt-2"><!--[-->`;
        for (let $$index_1 = 0, $$length2 = each_array_1.length; $$index_1 < $$length2; $$index_1++) {
          let h2Item = each_array_1[$$index_1];
          $$payload.out += `<li><a${attr("href", h2Item.link)}><small class="overflow-clip hover:text-sky-400 dark:text-gray-400 dark:hover:text-sky-300">${escape_html(h2Item.title)}</small></a></li> `;
          if (h2Item.h3) {
            $$payload.out += "<!--[-->";
            const each_array_2 = ensure_array_like(h2Item.h3);
            $$payload.out += `<ul class="ml-2"><!--[-->`;
            for (let $$index = 0, $$length3 = each_array_2.length; $$index < $$length3; $$index++) {
              let h3Item = each_array_2[$$index];
              $$payload.out += `<li><a${attr("href", h3Item.link)}><small class="line-clamp-1 hover:text-sky-400 dark:text-gray-400 dark:hover:text-sky-300">${escape_html(h3Item.title)}</small></a></li>`;
            }
            $$payload.out += `<!--]--></ul>`;
          } else {
            $$payload.out += "<!--[!-->";
          }
          $$payload.out += `<!--]-->`;
        }
        $$payload.out += `<!--]--></ul>`;
      } else {
        $$payload.out += "<!--[!-->";
      }
      $$payload.out += `<!--]--></li>`;
    }
    $$payload.out += `<!--]--></ul>`;
  } else {
    $$payload.out += "<!--[!-->";
    $$payload.out += `<p class="text-xs text-gray-500 dark:text-gray-400">💭 Nothing to show yet</p>`;
  }
  $$payload.out += `<!--]--></div></aside>`;
  pop();
}
function Sidebar_item($$payload, $$props) {
  let href = fallback($$props["href"], "/");
  let label = fallback($$props["label"], "");
  let icon = fallback($$props["icon"], "");
  let isActive = fallback($$props["isActive"], false);
  $$payload.out += `<li><a${attr("href", href)}${attr("class", `group flex items-center rounded p-2 text-xs ${stringify(isActive ? "active" : "text-gray-900 dark:text-gray-300")}`)}><span class="material-symbols-outlined text-sm">${escape_html(icon)}</span> <span class="ms-3">${escape_html(label)}</span></a></li>`;
  bind_props($$props, { href, label, icon, isActive });
}
function Sidebar($$payload, $$props) {
  push();
  var $$store_subs;
  let isCourseActive = false;
  $$payload.out += `<aside id="logo-sidebar" class="fixed left-0 top-0 z-40 h-screen w-64 -translate-x-full border-r border-gray-200 bg-white pt-20 transition-transform sm:translate-x-0 dark:border-gray-800 dark:bg-gray-900" aria-label="Sidebar"><div class="h-full overflow-y-auto bg-white px-3 pb-4 dark:bg-gray-900"><ul class="space-y-2 font-medium">`;
  Sidebar_item($$payload, {
    href: "/",
    label: "Home",
    icon: "home",
    isActive: store_get($$store_subs ??= {}, "$page", page).url.pathname === "/"
  });
  $$payload.out += `<!----> `;
  Sidebar_item($$payload, {
    href: "/courses",
    label: "Courses",
    icon: "book",
    isActive: isCourseActive
  });
  $$payload.out += `<!----> `;
  Sidebar_item($$payload, {
    href: "/chats",
    label: "Chats",
    icon: "chat",
    isActive: store_get($$store_subs ??= {}, "$page", page).url.pathname === "/chats"
  });
  $$payload.out += `<!----> `;
  Sidebar_item($$payload, {
    href: "/results",
    label: "Results",
    icon: "analytics",
    isActive: store_get($$store_subs ??= {}, "$page", page).url.pathname === "/results"
  });
  $$payload.out += `<!----></ul></div></aside>`;
  if ($$store_subs) unsubscribe_stores($$store_subs);
  pop();
}
function Navbar($$payload, $$props) {
  push();
  const baseUrl = "https://aarya.ai";
  let userInfo = {
    userKey: "000",
    firstName: "John",
    lastName: "Doe",
    userAuthenticated: false,
    email: "",
    pictureUrl: "/thumb.jpg"
  };
  UserInfoStore.subscribe((value) => {
    if (value) userInfo = value;
  });
  $$payload.out += `<nav class="fixed top-0 z-50 w-full border-b border-gray-200 bg-white dark:border-gray-800 dark:bg-gray-900"><div class="px-3 py-3 lg:px-5 lg:pl-3"><div class="flex items-center justify-between"><div class="flex items-center justify-start rtl:justify-end"><button data-drawer-target="logo-sidebar" data-drawer-toggle="logo-sidebar" aria-controls="logo-sidebar" type="button" class="inline-flex items-center rounded-lg p-2 text-sm text-gray-500 hover:bg-gray-100 focus:outline-none focus:ring-2 focus:ring-gray-200 sm:hidden dark:text-gray-400 dark:hover:bg-gray-700 dark:focus:ring-gray-600"><span class="sr-only">Open sidebar</span> <svg class="h-6 w-6" aria-hidden="true" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg"><path clip-rule="evenodd" fill-rule="evenodd" d="M2 4.75A.75.75 0 012.75 4h14.5a.75.75 0 010 1.5H2.75A.75.75 0 012 4.75zm0 10.5a.75.75 0 01.75-.75h7.5a.75.75 0 010 1.5h-7.5a.75.75 0 01-.75-.75zM2 10a.75.75 0 01.75-.75h14.5a.75.75 0 010 1.5H2.75A.75.75 0 012 10z"></path></svg></button> `;
  Logo($$payload);
  $$payload.out += `<!----></div> <div class="flex items-center"><div class="ms-3 flex items-center"><div class="flex"><button type="button" class="flex rounded-full bg-gray-800 text-sm focus:ring-4 focus:ring-gray-300 dark:focus:ring-gray-600" aria-expanded="false" data-dropdown-toggle="dropdown-user"><span class="sr-only">Open user menu</span> <img class="h-8 w-8 rounded-full"${attr("src", userInfo.pictureUrl)} alt="user photo"></button> `;
  Darkmode($$payload);
  $$payload.out += `<!----></div> <div class="z-50 my-4 hidden list-none divide-y divide-gray-100 rounded bg-white text-base shadow dark:divide-gray-600 dark:bg-gray-700" id="dropdown-user"><div class="px-4 py-3" role="none"><p class="text-sm text-gray-900 dark:text-white" role="none">${escape_html(userInfo.firstName + " " + userInfo.lastName)}</p> <p class="truncate text-sm font-medium text-gray-900 dark:text-gray-300" role="none">${escape_html(userInfo.email)}</p></div> <ul class="py-1" role="none">`;
  Menu_item($$payload, {
    href: `${stringify(baseUrl)}/auth/logout/${stringify(userInfo.userKey)}`,
    label: "Logout"
  });
  $$payload.out += `<!----></ul></div></div></div></div></div></nav> `;
  Sidebar($$payload);
  $$payload.out += `<!----> `;
  Right_sidebar($$payload);
  $$payload.out += `<!---->`;
  pop();
}
function Container($$payload, $$props) {
  Navbar($$payload);
  $$payload.out += `<!----> <div class="p-4 sm:ml-64 sm:mr-64 xl:mr-72"><div class="mx-auto max-w-screen-lg"><div class="mt-14 rounded-lg p-4"><!---->`;
  slot($$payload, $$props, "default", {});
  $$payload.out += `<!----></div></div></div>`;
}
function _layout($$payload, $$props) {
  push();
  let { children } = $$props;
  Container($$payload, {
    children: ($$payload2) => {
      children($$payload2);
      $$payload2.out += `<!---->`;
    },
    $$slots: { default: true }
  });
  pop();
}
export {
  _layout as default
};
