import { R as ensure_array_like, O as attr, P as escape_html, N as pop, K as push } from "../../../chunks/index.js";
import "../../../chunks/client.js";
import { a as CourseStore } from "../../../chunks/stores.js";
function _page($$payload, $$props) {
  push();
  let courses = [];
  CourseStore.subscribe((value) => {
    if (value) {
      courses = value;
    }
  });
  if (courses.length === 0) {
    $$payload.out += "<!--[-->";
    $$payload.out += `<p>Loading...</p>`;
  } else {
    $$payload.out += "<!--[!-->";
    const each_array = ensure_array_like(courses);
    $$payload.out += `<div class="flex flex-col gap-16"><!--[-->`;
    for (let $$index = 0, $$length = each_array.length; $$index < $$length; $$index++) {
      let course = each_array[$$index];
      $$payload.out += `<div class="flex flex-col gap-2"><h1 class="scrollable text-2xl font-semibold uppercase"${attr("id", course.slug)}>${escape_html(course.name)}</h1> <small class="text-gray-500 dark:text-gray-400">Updated: ${escape_html(course.updated)}</small> <div class="mb-4 mt-4 flex flex-wrap items-center gap-8 text-sm"><p class="flex items-center gap-2 border-l-4 border-sky-300 px-2"><span class="material-symbols-outlined text-base">group</span> ${escape_html(course.students)} students</p> <p class="flex items-center gap-2 border-l-4 border-sky-300 px-2"><span class="material-symbols-outlined">checklist</span> ${escape_html(course.units)} units</p> <p class="flex items-center gap-2 border-l-4 border-sky-300 px-2"><span class="material-symbols-outlined">laptop_chromebook</span> ${escape_html(course.topics)} topics</p> <p class="flex items-center gap-2 border-l-4 border-sky-300 px-2"><span class="material-symbols-outlined">pool</span> ${escape_html(course.exams)}+ practice tests</p></div> <p class="italic text-gray-600 dark:text-gray-300">${escape_html(course.description)}</p> <p class="mt-4 text-gray-700 dark:text-gray-300">${escape_html(course.summary)}</p> <div class="flex gap-4"><button class="button-primary mt-4 flex items-center gap-2" type="button"><span class="material-symbols-outlined text-base">owl</span> <span>Learn</span></button> <button class="button-primary mt-4 flex items-center gap-2" type="button"><span class="material-symbols-outlined text-base">pool</span> <span>Practice Test</span></button></div></div>`;
    }
    $$payload.out += `<!--]--></div>`;
  }
  $$payload.out += `<!--]-->`;
  pop();
}
export {
  _page as default
};
