import * as universal from '../entries/pages/topic/_...slug_/_page.ts.js';

export const index = 8;
let component_cache;
export const component = async () => component_cache ??= (await import('../entries/pages/topic/_...slug_/_page.svelte.js')).default;
export { universal };
export const universal_id = "src/routes/topic/[...slug]/+page.ts";
export const imports = ["_app/immutable/nodes/8.3o2RcDtH.js","_app/immutable/chunks/api.eaprVEHa.js","_app/immutable/chunks/stores.DRDIB_G-.js","_app/immutable/chunks/index.B9cgvAar.js","_app/immutable/chunks/runtime.Cwp630e2.js","_app/immutable/chunks/disclose-version.I-RjJhnD.js","_app/immutable/chunks/if.sUFoR466.js","_app/immutable/chunks/html.DoUVXxNn.js","_app/immutable/chunks/attributes.D7C6WRNa.js","_app/immutable/chunks/this.CxsaMnEI.js","_app/immutable/chunks/each.DEl-2jfd.js","_app/immutable/chunks/loading.CQtsdSjo.js","_app/immutable/chunks/legacy.DCghlM8i.js","_app/immutable/chunks/props.CXTR-fxd.js","_app/immutable/chunks/store.BmkDAs3D.js","_app/immutable/chunks/class.Dm5Bmw4r.js","_app/immutable/chunks/lifecycle.Bq7wBMyP.js","_app/immutable/chunks/index-client.CMZNMlmA.js"];
export const stylesheets = ["_app/immutable/assets/8.CMYouZ3z.css"];
export const fonts = [];
