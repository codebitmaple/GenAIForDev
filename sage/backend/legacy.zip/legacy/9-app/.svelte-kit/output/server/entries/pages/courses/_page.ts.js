import { A as ApiCalls } from "../../../chunks/api.js";
import { a as CourseStore } from "../../../chunks/stores.js";
let courses = [];
const apiUrl = "https://aarya.ai/api";
CourseStore.subscribe((value) => {
  if (value) courses = value;
});
async function load({ fetch }) {
  if (courses.length > 0) return;
  const response = await ApiCalls.get(`${apiUrl}/courses`, fetch);
  if (response.ok) {
    const result = await response.json();
    result.map((r) => {
      console.log(courses);
      courses.push({
        id: r._id.$oid,
        slug: r.slug,
        name: r.name,
        description: r.meta_description,
        summary: r.summary,
        updated: new Date(r.updated * 1e3).toLocaleDateString(),
        disclaimer: r.disclaimer,
        students: r.students,
        units: r.units,
        topics: r.topics,
        exercises: r.exercises,
        exams: r.exams
      });
    });
    CourseStore.set(courses);
  }
}
export {
  load
};
