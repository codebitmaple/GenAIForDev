import { R as ensure_array_like, P as escape_html, O as attr, S as stringify, N as pop, K as push } from "../../../chunks/index.js";
import { G as GropuedResultsStore, S as SidebarStore } from "../../../chunks/stores.js";
import { o as onDestroy } from "../../../chunks/index-server.js";
function _page($$payload, $$props) {
  push();
  let keys = void 0;
  let unsubscribeGropuedResultsStore = GropuedResultsStore.subscribe((value) => {
    keys = value;
    SidebarStore.set({ h1: [] });
  });
  onDestroy(() => {
    unsubscribeGropuedResultsStore();
  });
  if (keys) {
    $$payload.out += "<!--[-->";
    const each_array = ensure_array_like(keys);
    $$payload.out += `<!--[-->`;
    for (let $$index = 0, $$length = each_array.length; $$index < $$length; $$index++) {
      let key = each_array[$$index];
      $$payload.out += `<div class="mb-8 flex flex-col"><div class="flex flex-col gap-1"><p class="uppercase">${escape_html(key.value.courseName)}</p> <small>${escape_html(key.value.questions)} questions on ${escape_html(key.value.dateTaken)}</small></div> <a${attr("href", `/result/practice/${stringify(key.key)}`)} class="dark:text-sky-500 dark:hover:text-sky-400">See result</a></div>`;
    }
    $$payload.out += `<!--]-->`;
  } else {
    $$payload.out += "<!--[!-->";
    $$payload.out += `<p><a href="/courses" class="text-sky-700 hover:text-sky-600 dark:text-sky-500 dark:hover:text-sky-400">Start learning</a> to see results on this page.</p>`;
  }
  $$payload.out += `<!--]-->`;
  pop();
}
export {
  _page as default
};
