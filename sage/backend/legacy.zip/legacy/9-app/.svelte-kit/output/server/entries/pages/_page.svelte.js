import { P as escape_html, N as pop, K as push } from "../../chunks/index.js";
import { U as UserInfoStore, S as SidebarStore } from "../../chunks/stores.js";
function _page($$payload, $$props) {
  push();
  let userInfo = void 0;
  SidebarStore.set({ h1: [] });
  UserInfoStore.subscribe((value) => {
    if (value) userInfo = value;
  });
  if (userInfo) {
    $$payload.out += "<!--[-->";
    $$payload.out += `<h1>Hello, ${escape_html(userInfo.firstName)}</h1> <p><a href="/courses" class="text-sky-700 hover:text-sky-600 dark:text-sky-500 dark:hover:text-sky-400">Go to Courses</a></p>`;
  } else {
    $$payload.out += "<!--[!-->";
  }
  $$payload.out += `<!--]-->`;
  pop();
}
export {
  _page as default
};
