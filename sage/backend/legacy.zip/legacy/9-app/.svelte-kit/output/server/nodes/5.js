import * as universal from '../entries/pages/practice/_slug_/_page.ts.js';

export const index = 5;
let component_cache;
export const component = async () => component_cache ??= (await import('../entries/pages/practice/_slug_/_page.svelte.js')).default;
export { universal };
export const universal_id = "src/routes/practice/[slug]/+page.ts";
export const imports = ["_app/immutable/nodes/5.UahpFHu5.js","_app/immutable/chunks/api.eaprVEHa.js","_app/immutable/chunks/stores.DRDIB_G-.js","_app/immutable/chunks/index.B9cgvAar.js","_app/immutable/chunks/runtime.Cwp630e2.js","_app/immutable/chunks/disclose-version.I-RjJhnD.js","_app/immutable/chunks/if.sUFoR466.js","_app/immutable/chunks/index-client.CMZNMlmA.js","_app/immutable/chunks/entry.h2gTVBox.js","_app/immutable/chunks/each.DEl-2jfd.js","_app/immutable/chunks/html.DoUVXxNn.js","_app/immutable/chunks/attributes.D7C6WRNa.js"];
export const stylesheets = [];
export const fonts = [];
