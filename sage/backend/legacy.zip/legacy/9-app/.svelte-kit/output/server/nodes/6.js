import * as universal from '../entries/pages/result/_...slug_/_page.ts.js';

export const index = 6;
let component_cache;
export const component = async () => component_cache ??= (await import('../entries/pages/result/_...slug_/_page.svelte.js')).default;
export { universal };
export const universal_id = "src/routes/result/[...slug]/+page.ts";
export const imports = ["_app/immutable/nodes/6.CI6V04C_.js","_app/immutable/chunks/api.eaprVEHa.js","_app/immutable/chunks/stores.DRDIB_G-.js","_app/immutable/chunks/index.B9cgvAar.js","_app/immutable/chunks/runtime.Cwp630e2.js","_app/immutable/chunks/disclose-version.I-RjJhnD.js","_app/immutable/chunks/if.sUFoR466.js","_app/immutable/chunks/each.DEl-2jfd.js","_app/immutable/chunks/html.DoUVXxNn.js","_app/immutable/chunks/index-client.CMZNMlmA.js","_app/immutable/chunks/entry.h2gTVBox.js","_app/immutable/chunks/this.CxsaMnEI.js","_app/immutable/chunks/loading.CQtsdSjo.js","_app/immutable/chunks/legacy.DCghlM8i.js","_app/immutable/chunks/props.CXTR-fxd.js","_app/immutable/chunks/store.BmkDAs3D.js"];
export const stylesheets = ["_app/immutable/assets/6._sKjXx9B.css"];
export const fonts = [];
