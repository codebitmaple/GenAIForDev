import { A as ApiCalls } from "../../chunks/api.js";
import { U as UserInfoStore } from "../../chunks/stores.js";
const apiUrl = "https://aarya.ai/api";
const baseUrl = "https://aarya.ai";
let userInfo = void 0;
UserInfoStore.subscribe((value) => {
  if (value) userInfo = value;
});
async function load({ fetch }) {
  if (userInfo) return;
  let response = await ApiCalls.get(`${apiUrl}/user`, fetch);
  if (response.ok) {
    let data = await response.json();
    let userInfo2 = {
      userKey: data.user_key,
      firstName: data.first_name,
      lastName: data.last_name,
      userAuthenticated: true,
      email: data.email,
      pictureUrl: `${apiUrl}/google/picture`
    };
    UserInfoStore.set(userInfo2);
  } else {
    console.error("Failed to load user info");
    if (response.status === 401) {
      window.location.href = `${baseUrl}/login`;
    }
  }
}
export {
  load
};
