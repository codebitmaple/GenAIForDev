import * as universal from '../entries/pages/results/_page.ts.js';

export const index = 7;
let component_cache;
export const component = async () => component_cache ??= (await import('../entries/pages/results/_page.svelte.js')).default;
export { universal };
export const universal_id = "src/routes/results/+page.ts";
export const imports = ["_app/immutable/nodes/7.DTlHvRqh.js","_app/immutable/chunks/api.eaprVEHa.js","_app/immutable/chunks/stores.DRDIB_G-.js","_app/immutable/chunks/index.B9cgvAar.js","_app/immutable/chunks/runtime.Cwp630e2.js","_app/immutable/chunks/disclose-version.I-RjJhnD.js","_app/immutable/chunks/if.sUFoR466.js","_app/immutable/chunks/each.DEl-2jfd.js","_app/immutable/chunks/attributes.D7C6WRNa.js","_app/immutable/chunks/index-client.CMZNMlmA.js"];
export const stylesheets = [];
export const fonts = [];
