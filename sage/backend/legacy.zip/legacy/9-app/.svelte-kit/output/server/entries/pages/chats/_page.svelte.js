import { R as ensure_array_like, O as attr, P as escape_html, N as pop, K as push } from "../../../chunks/index.js";
import { C as ChatStore } from "../../../chunks/stores.js";
import { o as onDestroy } from "../../../chunks/index-server.js";
import { h as html } from "../../../chunks/html.js";
function _page($$payload, $$props) {
  push();
  let groupedChats = void 0;
  let unsubChat = ChatStore.subscribe((value) => {
    if (value) {
      groupedChats = value;
    }
  });
  const formatSource = (source, chat) => {
    switch (source) {
      case "topic-followup":
        return `${chat.courseName}: ${chat.unitName}/${chat.topicName}`.replace(/-/g, " ");
      case "practice":
        return "Practice Test";
      case "answer-recommendations":
        return "Answer clarifications";
      default:
        return "Unknown";
    }
  };
  onDestroy(() => {
    unsubChat();
  });
  if (groupedChats && groupedChats.length > 0) {
    $$payload.out += "<!--[-->";
    const each_array = ensure_array_like(groupedChats);
    $$payload.out += `<!--[-->`;
    for (let $$index_2 = 0, $$length = each_array.length; $$index_2 < $$length; $$index_2++) {
      let group = each_array[$$index_2];
      const each_array_1 = ensure_array_like(Object.entries(group));
      $$payload.out += `<!--[-->`;
      for (let $$index_1 = 0, $$length2 = each_array_1.length; $$index_1 < $$length2; $$index_1++) {
        let [date, chats] = each_array_1[$$index_1];
        const each_array_2 = ensure_array_like(chats);
        $$payload.out += `<h2 class="scrollable text-lg font-bold"${attr("id", date)}>${escape_html(date)}</h2> <!--[-->`;
        for (let $$index = 0, $$length3 = each_array_2.length; $$index < $$length3; $$index++) {
          let chat = each_array_2[$$index];
          $$payload.out += `<div class="mt-8 flex flex-col gap-8 border-b-2 border-gray-100 dark:border-gray-700"><div class="text-xs uppercase text-gray-500 dark:text-gray-400">${escape_html(formatSource(chat.source, chat))}</div> <div class="flex flex-col gap-4"><div class="prose prose-base dark:prose-invert prose-headings:text-base max-w-none">${html(chat.question)}</div> <div class="prose prose-base dark:prose-invert prose-headings:text-base max-w-none">${html(chat.context)}</div> <div class="prose prose-base dark:prose-invert prose-headings:text-base max-w-none">${html(chat.response)}</div></div></div>`;
        }
        $$payload.out += `<!--]-->`;
      }
      $$payload.out += `<!--]-->`;
    }
    $$payload.out += `<!--]-->`;
  } else {
    $$payload.out += "<!--[!-->";
    $$payload.out += `<p><a href="/courses" class="text-sky-700 hover:text-sky-600 dark:text-sky-500 dark:hover:text-sky-400">Start learning</a> to see chats on this page.</p>`;
  }
  $$payload.out += `<!--]-->`;
  pop();
}
export {
  _page as default
};
