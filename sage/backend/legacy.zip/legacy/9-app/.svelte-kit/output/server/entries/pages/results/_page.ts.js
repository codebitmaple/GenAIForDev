import { A as ApiCalls } from "../../../chunks/api.js";
import { G as GropuedResultsStore } from "../../../chunks/stores.js";
const apiUrl = "https://aarya.ai/api";
async function load({ fetch }) {
  let response = await ApiCalls.get(`${apiUrl}/results`, fetch);
  if (response.ok) {
    let data = await response.json();
    const keys = Object.keys(data);
    const results = [];
    keys.forEach((key) => {
      results.push({
        key,
        value: {
          courseName: data[key][0].course_slug,
          questions: data[key].length,
          dateTaken: data[key][0].date_created
        }
      });
    });
    GropuedResultsStore.set(results);
  }
}
export {
  load
};
