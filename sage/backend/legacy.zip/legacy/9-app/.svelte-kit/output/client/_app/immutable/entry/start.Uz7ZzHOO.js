import{a as t}from"../chunks/entry.h2gTVBox.js";export{t as start};
