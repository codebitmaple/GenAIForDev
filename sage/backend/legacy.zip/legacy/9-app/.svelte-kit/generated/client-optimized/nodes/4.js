import * as universal from "../../../../src/routes/courses/+page.ts";
export { universal };
export { default as component } from "../../../../src/routes/courses/+page.svelte";