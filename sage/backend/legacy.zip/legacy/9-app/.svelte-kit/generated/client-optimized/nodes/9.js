import * as universal from "../../../../src/routes/units/[slug]/+page.ts";
export { universal };
export { default as component } from "../../../../src/routes/units/[slug]/+page.svelte";