import * as universal from "../../../../src/routes/chats/+page.ts";
export { universal };
export { default as component } from "../../../../src/routes/chats/+page.svelte";