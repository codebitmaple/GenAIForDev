use std::sync::Arc;

use aarya_entities::{email::payment_confirmation::PaymentConfirmationModel, queue::NamedQueue};
use aarya_utils::{
    date_ops,
    email_ops::{self, EmailRequest},
    environ::{Environ, RedisConfig},
    file_ops,
    queue_ops::{Consumer, RedisConnectionManager},
};
use log::debug;
use serde_json::{from_value, Value};

fn main() {
    Environ::load_env_file();
    let redis_config: RedisConfig = Environ::init();
    let connection_manager = Arc::new(RedisConnectionManager::new(&redis_config.redis_server));
    let consumer = Consumer::new(connection_manager);

    debug!("Starting consumer. Listening to queues: {:?}. Redis config: {:?}", NamedQueue::Email.as_str(), redis_config);

    // List of queue names to listen to
    let queues = vec![NamedQueue::Email.as_str()];

    // Custom deserialization function for JSON messages
    let deserialize_fn = |message_str: &str| -> Result<Value, serde_json::Error> { serde_json::from_str(message_str) };

    // Custom message processing function
    let process_message_fn = |message: serde_json::Value| -> bool {
        let typed_message: PaymentConfirmationModel = match from_value(message) {
            Ok(m) => m,
            Err(e) => {
                eprintln!("Error deserializing message: [{:?}]", e);
                return false;
            }
        };

        match typed_message.queue_name {
            NamedQueue::Email => {
                let file_path = format!("email-templates/{}", typed_message.template_name);
                let contents = match file_ops::read_file(&file_path) {
                    Ok(c) => c,
                    Err(e) => {
                        eprintln!("Error reading file: [{:?}]", e);
                        return false;
                    }
                };

                let updated_contents = contents
                    .replace("{{header}}", typed_message.header.as_str())
                    .replace("{{subject}}", typed_message.subject.as_str())
                    .replace("{{message}}", typed_message.message.as_str())
                    .replace("{{CTA_Link}}", typed_message.cta_link.as_str())
                    .replace("{{year}}", date_ops::to_year_only().as_str())
                    .replace("{{CTA_Text}}", typed_message.cta_text.as_str());

                match email_ops::send_email(EmailRequest {
                    key: typed_message.idempotent_key,
                    subject: typed_message.subject,
                    from: None,
                    to: typed_message.email_to.join(","),
                    body: updated_contents,
                }) {
                    Some(_) => {
                        println!("Email sent successfully");
                    }
                    None => {
                        eprintln!("Error sending email");
                        return false;
                    }
                }
            }
        }
        true
    };

    // Start consuming messages from multiple queues with custom deserialization and processing logic
    match consumer.consume_multiple_queues(&queues, deserialize_fn, process_message_fn) {
        Ok(_) => print!("Consumed messages successfully"),
        Err(e) => eprintln!("Error consuming messages: [{:?}]", e),
    }
}
