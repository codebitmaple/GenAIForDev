use serde::{Deserialize, Serialize};

pub mod exam_question_context;
pub mod exam_question_handler;
pub mod exam_request_generator;
pub mod exercise_question_context;
pub mod exercise_question_handler;
pub mod generated_exam_question_context;
pub mod generated_exam_question_handler;

#[derive(Debug, Serialize, Deserialize, Clone)]
pub struct Prompt {
    pub system: String,
    pub user: String,
}
