use std::{thread, time::Duration};

use aarya_entities::{
    course::course_entity::CourseEntity,
    question::question_entity::{QuestionEntity, QuestionTarget, QuestionUploadModel},
    unit::unit_entity::UnitEntity,
};
use aarya_utils::{
    cache_ops, date_ops,
    db_ops::Database,
    hash_ops,
    json_ops::{self, JsonOpsResult},
};
use futures::{stream, StreamExt};
use log::{debug, error};
use schemars::JsonSchema;
use serde::{Deserialize, Serialize};

use super::generated_exam_question_context::GeneratedExamQuestionContext;

#[derive(Debug, Serialize, Deserialize, Clone, JsonSchema)]
pub struct QuestionsModel {
    questions: Vec<QuestionUploadModel>,
}

pub async fn handle_exam_questions(context_file: &str) {
    let context = GeneratedExamQuestionContext::read_context_file(context_file.to_string());

    let max_concurrent_requests = 1;

    let questions_stream = stream::iter(context.iter()).for_each_concurrent(max_concurrent_requests, |context| {
        let context = context.clone();

        async move { process_question(&context).await }
    });

    // Await all tasks to complete
    questions_stream.await;
}

async fn process_question(context: &GeneratedExamQuestionContext) {
    let client = Database::get_client().await;
    let cache = cache_ops::Cache::default();
    let unit = UnitEntity::find_by_slug(&client, &cache, context.unit_slug.clone()).await.unwrap();
    let course = CourseEntity::find_by_slug(&client, &cache, context.course_slug.clone()).await.unwrap();

    debug!("Context: {:?}", context);

    let questions: Vec<QuestionUploadModel> = match json_ops::read_json_file(&context.generated_path) {
        JsonOpsResult::Success(r) => serde_json::from_value(r).unwrap(),
        JsonOpsResult::Error(_) => {
            error!("Error reading generated questions from file");
            panic!("Error reading generated questions from file")
        }
    };

    let max_concurrent_requests = 1;
    let questions_stream = stream::iter(questions.iter()).for_each_concurrent(max_concurrent_requests, |q| {
        let client = client.clone();
        let cache = cache.clone();
        async move {
            let entity = QuestionEntity {
                _id: Database::generate_id(),
                question: q.question.clone(),
                question_hash: hash_ops::string_hasher(q.question.as_str()),
                choices: q.choices.clone(),
                answers: q.answers.clone(),
                created_at: date_ops::to_timestamp(),
                updated_at: date_ops::to_timestamp(),
                tags: q.tags.clone(),
                question_type: q.question_type.clone(),
                key_concept: q.key_concept.clone(),
                question_difficulty: q.question_difficulty.clone(),
                answer_explanation: q.answer_explanation.clone(),
                course_id: course._id.to_hex(),
                unit_id: unit._id.to_hex(),
                topic_id: None,
                group_id: Some(q.group_id.clone()),
                kind: Some(q.kind.clone()),
                target: Some(QuestionTarget::Exam),
                illustration: Some(q.illustration.clone()),
                order: Some(q.order),
            };
            entity.create(&client, &cache).await;
        }
    });

    // Await all tasks to complete
    questions_stream.await;

    debug!("Questions run complete. Saved to database. Sleeping for 1 sec");
    thread::sleep(Duration::from_secs(1));
}
