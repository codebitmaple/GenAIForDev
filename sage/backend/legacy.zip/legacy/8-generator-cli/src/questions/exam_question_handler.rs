use std::{thread, time::Duration};

use aarya_entities::{
    course::course_entity::CourseEntity,
    openai::{
        completion_request::{Content, ContentType, ImageDetail, ImageUrl, Message, ResponseFormat, ResponseFormatType},
        PostChatCompletionRequest,
    },
    question::question_entity::{QuestionEntity, QuestionTarget, QuestionUploadModel},
    topic::topic_entity::TopicEntity,
    unit::unit_entity::UnitEntity,
};
use aarya_utils::{cache_ops, date_ops, db_ops::Database, file_ops, hash_ops, image_ops, schema_ops};
use futures::{stream, StreamExt};
use log::{debug, error};
use mongodb::Client;
use schemars::JsonSchema;
use serde::{Deserialize, Serialize};

use crate::openai_model::{get_validated_response_slug, OpenAiSchemaModel};

use super::exam_question_context::ExamQuestionContext;

#[derive(Debug, Serialize, Deserialize, Clone, JsonSchema)]
pub struct QuestionsModel {
    questions: Vec<QuestionUploadModel>,
}

pub async fn handle_exam_questions(context_file: &str) {
    let context = ExamQuestionContext::read_context_file(context_file.to_string());

    let schema = OpenAiSchemaModel {
        name: "question".to_string(),
        schema: schema_ops::to_openai_schema(schema_ops::to_json_schema::<QuestionsModel>().unwrap()).unwrap(),
    };

    let max_concurrent_requests = 1;
    let questions_stream = stream::iter(context.iter()).for_each_concurrent(max_concurrent_requests, |context| {
        let context = context.clone();
        let schema = schema.clone();
        async move {
            process_question(context, &schema).await;
        }
    });

    // Await all tasks to complete
    questions_stream.await;
}

async fn process_question(
    context: ExamQuestionContext,
    schema: &OpenAiSchemaModel,
) {
    let client = Database::get_client().await;
    let cache = cache_ops::Cache::default();
    let unit = UnitEntity::find_by_slug(&client, &cache, context.unit_slug.clone()).await.unwrap();
    let course = CourseEntity::find_by_slug(&client, &cache, context.course_slug.clone()).await.unwrap();
    let topics = TopicEntity::find_by_unit(&client, &cache, &unit._id.to_hex()).await.unwrap();
    let topic_summary: Vec<String> = topics.iter().filter_map(|t| t.summary.clone()).collect::<Vec<_>>();
    let unit_metadata = unit.metadata.iter().map(|k| format!("{:?}: {:?}", k.key, k.value)).collect::<Vec<_>>();

    let mut context = context.clone();
    context.unit_context = Some(format!(
        "Unit context including learning objectives and key concepts: {}\n\n Short summary of all the topics covered: {}",
        unit_metadata.join("\n"),
        topic_summary.join("\n")
    ));

    process_unit(&client, &course, &unit, &context, schema).await;

    debug!("Unit run complete.");
}

async fn process_unit(
    client: &Client,
    course: &CourseEntity,
    unit: &UnitEntity,
    context: &ExamQuestionContext,
    schema: &OpenAiSchemaModel,
) {
    let cache = cache_ops::Cache::default();
    let additional_context = format!(
        "Course Name: {}\n\n Course Summary: {}\n\n Unit Name: {}\n\n Unit Summary: {} \n\n {}",
        course.slug,
        course.summary,
        unit.slug,
        unit.description,
        context.unit_context.clone().unwrap_or_default()
    );

    let openai_request = if context.problem_path.is_some() {
        create_text_request(context, additional_context, schema)
    } else {
        create_image_request(context, additional_context, schema)
    };

    file_ops::write_file("./requests/question_request.json", serde_json::to_string_pretty(&openai_request).unwrap().as_str()).unwrap();

    let openai_response = get_validated_response_slug::<QuestionsModel>(&openai_request, &unit.slug).await;

    file_ops::write_file("./responses/question_response.json", openai_response.as_str()).unwrap();

    let openai_response = match serde_json::from_str::<QuestionsModel>(openai_response.as_str()) {
        Ok(m) => m,
        Err(e) => {
            error!("Error parsing openai response: {}", e);
            panic!("Error parsing openai response: {}", e);
        }
    };

    let max_concurrent_requests = 1;
    let questions_stream = stream::iter(openai_response.questions.iter()).for_each_concurrent(max_concurrent_requests, |q| {
        let client = client.clone();
        let cache = cache.clone();
        async move {
            let entity = QuestionEntity {
                _id: Database::generate_id(),
                question: q.question.clone(),
                question_hash: hash_ops::string_hasher(q.question.as_str()),
                choices: q.choices.clone(),
                answers: q.answers.clone(),
                created_at: date_ops::to_timestamp(),
                updated_at: date_ops::to_timestamp(),
                tags: q.tags.clone(),
                question_type: q.question_type.clone(),
                key_concept: q.key_concept.clone(),
                question_difficulty: q.question_difficulty.clone(),
                answer_explanation: q.answer_explanation.clone(),
                course_id: course._id.to_hex(),
                unit_id: unit._id.to_hex(),
                topic_id: None,
                group_id: Some(q.group_id.clone()),
                kind: Some(q.kind.clone()),
                target: Some(QuestionTarget::Exam),
                illustration: Some(q.illustration.clone()),
                order: Some(q.order),
            };
            entity.create(&client, &cache).await;
        }
    });

    // Await all tasks to complete
    questions_stream.await;

    debug!("Questions run complete. Saved to database. Sleeping for 1 sec");
    thread::sleep(Duration::from_secs(1));
}

fn create_text_request(
    context: &ExamQuestionContext,
    additional_context: String,
    schema: &OpenAiSchemaModel,
) -> PostChatCompletionRequest {
    let context = context.clone();
    let problem_text = file_ops::read_file(context.problem_path.as_ref().unwrap().as_str()).unwrap();
    PostChatCompletionRequest {
        messages: vec![
            Message {
                role: "user".to_string(),
                content: vec![Content {
                    content_type: ContentType::Text,
                    text: Some(format!(
                        "{}\n Use the following context to create questions: {}\n\n Example: {}",
                        context.prompt.user, additional_context, problem_text
                    )),
                    image_url: None,
                }],
            },
            Message {
                role: "system".to_string(),
                content: vec![Content {
                    content_type: ContentType::Text,
                    text: Some(context.prompt.system.clone()),
                    image_url: None,
                }],
            },
        ],
        response_format: Some(ResponseFormat {
            format_type: ResponseFormatType::JsonSchema,
            json_schema: Some(schema.to_value()),
        }),
    }
}

fn create_image_request(
    context: &ExamQuestionContext,
    additional_context: String,
    schema: &OpenAiSchemaModel,
) -> PostChatCompletionRequest {
    let base64_image = match image_ops::to_base64(context.image_path.as_ref().unwrap().as_str()) {
        Ok(b) => b,
        Err(e) => {
            error!("Error converting image to base64: {}", e);
            panic!("Error converting image to base64: {}", e);
        }
    };

    PostChatCompletionRequest {
        messages: vec![
            Message {
                role: "user".to_string(),
                content: vec![
                    Content {
                        content_type: ContentType::ImageUrl,
                        text: None,
                        image_url: Some(ImageUrl {
                            url: format!("data:image/jpeg;base64,{}", base64_image),
                            detail: ImageDetail::Low,
                        }),
                    },
                    Content {
                        content_type: ContentType::Text,
                        text: Some(format!(
                            "{}\n\n Use the following context and the attached image as an example to create questions: {}",
                            context.prompt.user, additional_context
                        )),
                        image_url: None,
                    },
                ],
            },
            Message {
                role: "system".to_string(),
                content: vec![Content {
                    content_type: ContentType::Text,
                    text: Some(context.prompt.system.clone()),
                    image_url: None,
                }],
            },
        ],
        response_format: Some(ResponseFormat {
            format_type: ResponseFormatType::JsonSchema,
            json_schema: Some(schema.to_value()),
        }),
    }
}
