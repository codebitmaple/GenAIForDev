use aarya_utils::file_ops;
use serde::{Deserialize, Serialize};

use super::Prompt;

#[derive(Debug, Serialize, Deserialize, Clone)]
pub struct ExamQuestionContext {
    pub course_slug: String,
    pub unit_slug: String,
    pub prompt: Prompt,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub problem_path: Option<String>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub image_path: Option<String>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub unit_context: Option<String>,
    pub kind: String,
}

impl ExamQuestionContext {
    pub fn read_context_file(context_file: String) -> Vec<Self> {
        // load course context
        let context_str = file_ops::read_file(context_file.as_str()).unwrap();
        let context_data: Vec<ExamQuestionContext> = serde_json::from_str(&context_str).unwrap();
        context_data
    }
}
