use aarya_utils::file_ops;
use serde::{Deserialize, Serialize};

#[derive(Debug, Serialize, Deserialize, Clone)]
pub struct GeneratedExamQuestionContext {
    pub course_slug: String,
    pub unit_slug: String,
    pub generated_path: String,
}

impl GeneratedExamQuestionContext {
    pub fn read_context_file(context_file: String) -> Vec<Self> {
        // load course context
        let context_str = file_ops::read_file(context_file.as_str()).unwrap();
        let context_data: Vec<GeneratedExamQuestionContext> = serde_json::from_str(&context_str).unwrap();
        context_data
    }
}
