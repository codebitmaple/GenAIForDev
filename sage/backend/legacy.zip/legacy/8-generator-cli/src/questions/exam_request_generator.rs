use aarya_entities::{
    openai::{
        completion_request::{Content, ContentType, Message, ResponseFormat, ResponseFormatType},
        PostChatCompletionRequest,
    },
    question::question_entity::QuestionUploadModel,
};
use aarya_utils::{file_ops, schema_ops};
use futures::{stream, StreamExt};
use log::debug;
use schemars::JsonSchema;
use serde::{Deserialize, Serialize};

use crate::openai_model::OpenAiSchemaModel;

use super::exam_question_context::ExamQuestionContext;

#[derive(Debug, Serialize, Deserialize, Clone, JsonSchema)]
pub struct QuestionsModel {
    questions: Vec<QuestionUploadModel>,
}

pub async fn handle_exam_questions(context_file: &str) {
    let context = ExamQuestionContext::read_context_file(context_file.to_string());

    let schema = OpenAiSchemaModel {
        name: "question".to_string(),
        schema: schema_ops::to_openai_schema(schema_ops::to_json_schema::<QuestionsModel>().unwrap()).unwrap(),
    };

    let max_concurrent_requests = 1;
    let questions_stream = stream::iter(context.iter()).for_each_concurrent(max_concurrent_requests, |context| {
        let context = context.clone();
        let schema = schema.clone();
        async move {
            process_question(context, &schema).await;
        }
    });

    // Await all tasks to complete
    questions_stream.await;
}

async fn process_question(
    context: ExamQuestionContext,
    schema: &OpenAiSchemaModel,
) {
    let context = context.clone();

    process_unit(&context, schema).await;

    debug!("Unit run complete.");
}

async fn process_unit(
    context: &ExamQuestionContext,
    schema: &OpenAiSchemaModel,
) {
    let openai_request = if context.problem_path.is_some() {
        create_text_request(context, schema)
    } else {
        panic!("problem_path is required for this context.");
    };

    file_ops::write_file(
        format!("./requests/{}", context.clone().problem_path.unwrap().split("/").last().unwrap()).as_str(),
        serde_json::to_string_pretty(&openai_request).unwrap().as_str(),
    )
    .unwrap();
}

fn create_text_request(
    context: &ExamQuestionContext,
    schema: &OpenAiSchemaModel,
) -> PostChatCompletionRequest {
    let context = context.clone();
    let problem_text = file_ops::read_file(context.problem_path.as_ref().unwrap().as_str()).unwrap();
    PostChatCompletionRequest {
        messages: vec![
            Message {
                role: "user".to_string(),
                content: vec![Content {
                    content_type: ContentType::Text,
                    text: Some(format!("{} \n\n --- EXAMPLE --- \n {}", context.prompt.user, problem_text)),
                    image_url: None,
                }],
            },
            Message {
                role: "system".to_string(),
                content: vec![Content {
                    content_type: ContentType::Text,
                    text: Some(context.prompt.system.clone()),
                    image_url: None,
                }],
            },
        ],
        response_format: Some(ResponseFormat {
            format_type: ResponseFormatType::JsonSchema,
            json_schema: Some(schema.to_value()),
        }),
    }
}
