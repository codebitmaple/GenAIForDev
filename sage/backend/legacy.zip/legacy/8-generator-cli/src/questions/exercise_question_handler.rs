use std::{thread, time::Duration};

use aarya_entities::{
    course::course_entity::CourseEntity,
    openai::{
        completion_request::{Content, ContentType, Message, ResponseFormat, ResponseFormatType},
        PostChatCompletionRequest,
    },
    question::question_entity::{QuestionEntity, QuestionKind, QuestionTarget, QuestionUploadModel},
    topic::topic_entity::TopicEntity,
    unit::unit_entity::UnitEntity,
};
use aarya_utils::{cache_ops, date_ops, db_ops::Database, file_ops, hash_ops, schema_ops};
use futures::{stream, StreamExt};
use log::{debug, error};
use mongodb::Client;
use schemars::JsonSchema;
use serde::{Deserialize, Serialize};

use crate::openai_model::{get_validated_response_slug, OpenAiSchemaModel};

use super::exercise_question_context::ExerciseQuestionContext;

#[derive(Debug, Serialize, Deserialize, Clone, JsonSchema)]
pub struct QuestionsModel {
    questions: Vec<QuestionUploadModel>,
}

pub async fn handle_exercise_questions(context_file: &str) {
    let context = ExerciseQuestionContext::read_context_file(context_file.to_string());

    let schema = OpenAiSchemaModel {
        name: "question".to_string(),
        schema: schema_ops::to_openai_schema(schema_ops::to_json_schema::<QuestionsModel>().unwrap()).unwrap(),
    };

    let max_concurrent_requests = 1;
    let questions_stream = stream::iter(context.iter()).for_each_concurrent(max_concurrent_requests, |context| {
        let context = context.clone();
        let schema = schema.clone();
        async move {
            process_question(context, &schema).await;
        }
    });

    // Await all tasks to complete
    questions_stream.await;
}

async fn process_question(
    context: ExerciseQuestionContext,
    schema: &OpenAiSchemaModel,
) {
    let client = Database::get_client().await;
    let cache = cache_ops::Cache::default();
    let unit = UnitEntity::find_by_slug(&client, &cache, context.unit_slug.clone()).await.unwrap();
    let course = CourseEntity::find_by_slug(&client, &cache, context.course_slug.clone()).await.unwrap();

    // get topics from the unit
    let topics = TopicEntity::find_by_unit(&client, &cache, &unit._id.to_hex()).await.unwrap();

    let max_concurrent_requests = 1;
    let topics_stream = stream::iter(topics.iter()).for_each_concurrent(max_concurrent_requests, |topic| {
        let client = client.clone();
        let course = course.clone();
        let unit = unit.clone();
        let topic = topic.clone();
        let context = context.clone();
        let schema = schema.clone();
        async move {
            process_topic(&client, &course, &unit, &topic, &context, &schema).await;
        }
    });

    topics_stream.await;
    debug!("Topic run complete. Sleeping for 5 seconds");
    thread::sleep(Duration::from_secs(5));
}

async fn process_topic(
    client: &Client,
    course: &CourseEntity,
    unit: &UnitEntity,
    topic: &TopicEntity,
    context: &ExerciseQuestionContext,
    schema: &OpenAiSchemaModel,
) {
    let cache = cache_ops::Cache::default();
    let additional_context = format!(
        "Course Name: {} Summary: {}\nUnit Name: {} Summary: {} \nTopic Name: {} Contents: {}",
        course.slug, course.summary, unit.slug, unit.description, topic.slug, topic.markdown
    );

    let openai_request = create_text_request(context, additional_context, schema);

    file_ops::write_file("./requests/question_request.json", serde_json::to_string_pretty(&openai_request).unwrap().as_str()).unwrap();

    let openai_response = get_validated_response_slug::<QuestionsModel>(&openai_request, &topic.slug).await;

    file_ops::write_file("./responses/question_response.json", openai_response.as_str()).unwrap();

    let openai_response = match serde_json::from_str::<QuestionsModel>(openai_response.as_str()) {
        Ok(m) => m,
        Err(e) => {
            error!("Error parsing openai response: {}", e);
            panic!("Error parsing openai response: {}", e);
        }
    };

    let max_concurrent_requests = 1;
    let questions_stream = stream::iter(openai_response.questions.iter()).for_each_concurrent(max_concurrent_requests, |q| {
        let client = client.clone();
        let cache = cache.clone();

        async move {
            let entity = QuestionEntity {
                _id: Database::generate_id(),
                question: q.question.clone(),
                question_hash: hash_ops::string_hasher(q.question.as_str()),
                choices: q.choices.clone(),
                answers: q.answers.clone(),
                created_at: date_ops::to_timestamp(),
                updated_at: date_ops::to_timestamp(),
                tags: q.tags.clone(),
                question_type: q.question_type.clone(),
                key_concept: q.key_concept.clone(),
                question_difficulty: q.question_difficulty.clone(),
                answer_explanation: q.answer_explanation.clone(),
                course_id: course._id.to_hex(),
                unit_id: unit._id.to_hex(),
                topic_id: Some(topic._id.to_hex()),
                group_id: Some(q.group_id.clone()),
                kind: Some(QuestionKind::Standalone),
                target: Some(QuestionTarget::Exercise),
                illustration: Some(q.illustration.clone()),
                order: Some(q.order),
            };
            entity.create(&client, &cache).await;
        }
    });

    // Await all tasks to complete
    questions_stream.await;

    debug!("Questions run complete. Saved to database. Sleeping for 1 sec");
    thread::sleep(Duration::from_secs(1));
}

fn create_text_request(
    context: &ExerciseQuestionContext,
    additional_context: String,
    schema: &OpenAiSchemaModel,
) -> PostChatCompletionRequest {
    PostChatCompletionRequest {
        messages: vec![
            Message {
                role: "user".to_string(),
                content: vec![Content {
                    content_type: ContentType::Text,
                    text: Some(format!("{}\n Context: {}", context.prompt.user, additional_context)),
                    image_url: None,
                }],
            },
            Message {
                role: "system".to_string(),
                content: vec![Content {
                    content_type: ContentType::Text,
                    text: Some(context.prompt.system.clone()),
                    image_url: None,
                }],
            },
        ],
        response_format: Some(ResponseFormat {
            format_type: ResponseFormatType::JsonSchema,
            json_schema: Some(schema.to_value()),
        }),
    }
}
