use aarya_utils::file_ops;
use serde::{Deserialize, Serialize};

use super::Prompt;

#[derive(Debug, Serialize, Deserialize, Clone)]
pub struct ExerciseQuestionContext {
    pub course_slug: String,
    pub unit_slug: String,
    pub prompt: Prompt,
}

impl ExerciseQuestionContext {
    pub fn read_context_file(context_file: String) -> Vec<Self> {
        // load course context
        let context_str = file_ops::read_file(context_file.as_str()).unwrap();
        let context_data: Vec<ExerciseQuestionContext> = serde_json::from_str(&context_str).unwrap();
        context_data
    }
}
