use std::{any::type_name, thread, time::Duration};

use aarya_entities::openai::{
    completion_request::{Content, ContentType},
    PostChatCompletionRequest,
};
use log::{debug, error};
use schemars::JsonSchema;
use serde::{de::DeserializeOwned, Deserialize, Serialize};
use serde_json::{json, Value};

use crate::openai_server::chat_completion;

#[derive(Debug, Serialize, Deserialize, Clone, JsonSchema)]
pub struct OpenAiSchemaModel {
    pub name: String,
    pub schema: Value,
}

impl Default for OpenAiSchemaModel {
    fn default() -> Self {
        OpenAiSchemaModel {
            name: "".to_string(),
            schema: json!({}),
        }
    }
}

impl OpenAiSchemaModel {
    pub fn to_value(&self) -> serde_json::Value {
        serde_json::from_value(json!(self)).unwrap()
    }
}

pub async fn get_response(
    request: &PostChatCompletionRequest,
    user_id: &str,
) -> Option<String> {
    let mut retries = 5;

    loop {
        if retries == 0 {
            error!("Failed to get valid response after {} retries", retries);
            return None;
        }

        let response = chat_completion(&request.messages, request.clone().response_format, Some(user_id.to_string())).await;

        match response {
            Some(r) => {
                return Some(r);
            }
            None => {
                retries -= 1;
                debug!("Retries remaining: {}", retries);

                let delay = 2 * retries + 2;
                debug!("Sleeping for {} seconds before retrying", delay);
                thread::sleep(Duration::from_secs(delay));
            }
        }
    }
}

pub async fn get_validated_response_slug<T>(
    request: &PostChatCompletionRequest,
    slug: &str,
) -> String
where
    T: DeserializeOwned + JsonSchema,
{
    let mut response: String;
    let mut retries = 5;
    let mut request = request.clone();

    loop {
        if retries == 0 {
            error!("Failed to get valid {} response after {} retries", slug, retries);
            panic!("Failed to get valid {} response after {} retries", slug, retries);
        }
        response = get_response(&request, "aarya").await.unwrap();

        match serde_json::from_str::<T>(response.as_str()) {
            Ok(_) => {
                break;
            }
            Err(e) => {
                retries -= 1;
                println!("Error parsing {} response: {:?}. Retries remaining: {}. Type: {}", slug, e, retries, type_name::<T>());

                let delay = 2 * retries + 2;
                debug!("Sleeping for {} seconds before retrying", delay);
                thread::sleep(Duration::from_secs(delay));

                request.messages[0].content = vec![Content {
                    content_type: ContentType::Text,
                    text: Some(format!(
                        "Your previous response did not conform to the schema. Schema parser failed with the error: {}. Try again: {}",
                        e,
                        match request.messages[0].content[0].text.as_ref() {
                            Some(t) => t.clone(),
                            None => "".to_string(),
                        }
                    )),
                    image_url: None,
                }];

                continue;
            }
        }
    }

    response
}

pub async fn get_validated_response<T>(request: &PostChatCompletionRequest) -> String
where
    T: DeserializeOwned + JsonSchema,
{
    let mut response: String;
    let mut retries = 5;
    let mut request = request.clone();

    loop {
        if retries == 0 {
            error!("Failed to get valid response after {} retries", retries);
            panic!("Failed to get valid response after {} retries", retries);
        }
        response = get_response(&request, "aarya").await.unwrap();

        debug!("Response: {}", response);

        match serde_json::from_str::<T>(response.as_str()) {
            Ok(_) => {
                break;
            }
            Err(e) => {
                retries -= 1;
                println!("Error parsing response: {:?}. Retries remaining: {}. Type: {}", e, retries, type_name::<T>());

                let delay = 2 * retries + 2;
                debug!("Sleeping for {} seconds before retrying", delay);
                thread::sleep(Duration::from_secs(delay));

                request.messages[0].content = vec![Content {
                    content_type: ContentType::Text,
                    text: Some(format!(
                        "Your previous response did not conform to the schema. Schema parser failed with the error: {}. Try again: {}",
                        e,
                        match request.messages[0].content[0].text.as_ref() {
                            Some(t) => t.clone(),
                            None => "".to_string(),
                        }
                    )),
                    image_url: None,
                }];

                continue;
            }
        }
    }

    response
}
