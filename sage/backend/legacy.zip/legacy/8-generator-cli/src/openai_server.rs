use aarya_entities::openai::{
    completion_request::{ChatCompletionRequest, Message, ResponseFormat},
    completion_response::ChatCompletionResponse,
};
use aarya_utils::environ::{Environ, Environment, OpenAIConfig};
use log::debug;
use reqwest::Client as HttpClient;

pub async fn chat_completion(
    messages: &[Message],
    response_format: Option<ResponseFormat>,
    user_id: Option<String>,
) -> Option<String> {
    let openai_config: OpenAIConfig = Environ::init();

    let max_completion_tokens = if Environment::get_env() == Environment::Dev { None } else { Some(4096) };

    let openai_request = ChatCompletionRequest {
        model: openai_config.model.clone(),
        messages: messages.to_vec(),
        stream: Some(false),
        max_completion_tokens,
        user: user_id,
        response_format,
        temperature: Some(openai_config.temperature.into()),
        top_p: None,
        n: Some(1),
        stop: None,
        presence_penalty: None,
        frequency_penalty: None,
        logit_bias: None,
    };

    debug!("openai_request: {:?}", openai_request);

    let client = HttpClient::builder().timeout(std::time::Duration::from_secs(300)).build().unwrap();
    let response = client
        .post("https://api.openai.com/v1/chat/completions")
        .header("Content-Type", "application/json")
        .header("Authorization", format!("Bearer {}", openai_config.api_key))
        .json(&openai_request)
        .send()
        .await;

    let response = match response {
        Ok(r) => r,
        Err(e) => {
            log::error!("OpenAI request failed: {}", e);
            // return HttpResponse::InternalServerError().body("Request failed");
            return None;
        }
    };

    if response.status().is_success() {
        let response_body = response.text().await.unwrap();
        let data = serde_json::from_str::<ChatCompletionResponse>(&response_body).unwrap();
        let choice = &data.choices[0];
        debug!("Finish reason: {}", choice.finish_reason);
        let content = &choice.message.content;
        Some(content.clone())
    } else {
        log::error!("OpenAI response NOT OK: {} Details: [{}]", response.status(), response.text().await.unwrap());
        None
    }
}
