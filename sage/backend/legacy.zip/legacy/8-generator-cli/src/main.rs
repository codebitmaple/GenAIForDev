use std::path::PathBuf;

use aarya_utils::environ::Environ;
use blog_posts::post_handler::handle_post;
use clap::{arg, command, Parser, Subcommand};
use courses::course_handler::handle_courses;
use log::debug;
use questions::{exam_question_handler::handle_exam_questions, exam_request_generator, exercise_question_handler::handle_exercise_questions, generated_exam_question_handler};

pub mod blog_posts;
pub mod courses;
pub mod openai_model;
pub mod openai_server;
pub mod questions;

#[derive(Parser, Debug)]
#[command(version = "1.0")]
#[command(about = "create questions and courses in batches", long_about = None)]
pub struct Cli {
    #[command(subcommand)]
    command: Commands,
}

#[derive(Subcommand, Debug)]
enum Commands {
    /// creates new courses using a context file
    Courses {
        /// Path to the file to read
        #[arg(short, long)]
        context_file: PathBuf,

        #[arg(short, long)]
        prompt_file: PathBuf,

        #[arg(short, long)]
        target_audience: String,
    },

    /// creates new questions using a context file for topic-wise exercises
    ExerciseQuestions {
        #[arg(short, long)]
        context_file: String,
    },

    /// creates new questions using a context file at the unit level matching AP exam format
    ExamQuestions {
        #[arg(short, long)]
        context_file: String,
    },

    /// uses a pre-generated response from o1-preview to create exam questions
    GeneratedExamQuestions {
        #[arg(short, long)]
        context_file: String,
    },

    /// Generates only the requests for the questions
    GenerateRequests {
        #[arg(short, long)]
        context_file: String,
    },

    /// Generates only the requests for the questions
    BlogPosts {
        #[arg(short, long)]
        context_file: String,
    },
}

#[tokio::main]
async fn main() {
    Environ::load_env_file();
    let log_level = "debug";
    env_logger::init_from_env(env_logger::Env::new().default_filter_or(log_level));

    let cli = Cli::parse();

    match cli.command {
        Commands::Courses {
            context_file,
            prompt_file,
            target_audience,
        } => {
            handle_courses(context_file.to_str().unwrap(), prompt_file.to_str().unwrap(), target_audience.as_str()).await;
        }
        Commands::ExerciseQuestions { context_file } => {
            handle_exercise_questions(context_file.as_str()).await;
            debug!("Exercise Questions created");
        }
        Commands::ExamQuestions { context_file } => {
            handle_exam_questions(context_file.as_str()).await;
            debug!("Exam Questions created");
        }
        Commands::GeneratedExamQuestions { context_file } => {
            generated_exam_question_handler::handle_exam_questions(context_file.as_str()).await;
            debug!("Generated Exam Questions created");
        }
        Commands::GenerateRequests { context_file } => {
            exam_request_generator::handle_exam_questions(context_file.as_str()).await;
            debug!("Requests created");
        }
        Commands::BlogPosts { context_file } => {
            handle_post(context_file).await;
        }
    }
}
