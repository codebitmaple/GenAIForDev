use std::{thread, time::Duration};

use aarya_entities::{
    course::course_entity::{CourseEntity, CourseRequestModel},
    instructor::entity::InstructorEntity,
    openai::{
        completion_request::{Content, ContentType, Message, ResponseFormat, ResponseFormatType},
        PostChatCompletionRequest,
    },
    topic::topic_entity::{TopicCreateModel, TopicEntity},
    unit::unit_entity::{UnitEntity, UnitUploadModel},
};
use aarya_utils::{cache_ops, date_ops, db_ops::Database, file_ops, hash_ops, schema_ops};
use futures::{stream, StreamExt};
use log::{debug, error};

use crate::{
    courses::{
        course_context::{get_context, CourseContext},
        course_model::{CourseModel, PromptModel, Unit},
    },
    openai_model::get_validated_response_slug,
};

pub async fn handle_courses(
    context_file: &str,
    prompt_file: &str,
    target_audience: &str,
) {
    file_ops::write_file("./contexts/schema.json", schema_ops::to_json_schema::<CourseContext>().unwrap().as_str()).unwrap();
    let context_data = CourseContext::from_file(context_file.to_string());
    let mut prompt_model = PromptModel::from_file(prompt_file.to_string()).from_audience(target_audience.to_string());
    let model = context_data.to_model(&mut prompt_model).with_schema().unwrap();
    let model_file = format!("./models/{}.json", model.course.slug);
    match file_ops::write_file(model_file.as_str(), &serde_json::to_string(&model).unwrap()) {
        Ok(_) => debug!("Course model saved to {}", model_file),
        Err(e) => error!("Error saving course model: {}", e),
    }
    let course_id = process_course(&model, &context_data).await;
    debug!("Course Id: {}", course_id);

    process_units(&model, &context_data, &course_id).await;

    debug!("{} processing complete", context_file);
}

pub async fn process_course(
    model: &CourseModel,
    context_data: &CourseContext,
) -> String {
    let request = get_completion_request(
        &model.course.system_prompt,
        &model.course.user_prompt,
        model.course.json_schema.to_value(),
        &get_context(context_data, None, None, None).join(", "),
    );

    let response = get_validated_response_slug::<CourseRequestModel>(&request, &model.course.name).await;

    save_course(&response).await
}

pub async fn process_units(
    model: &CourseModel,
    course_context: &CourseContext,
    course_id: &str,
) {
    let max_concurrent_requests = 1; // Limit concurrent requests if needed

    let units_stream = stream::iter(model.units.iter()).for_each_concurrent(max_concurrent_requests, |unit| {
        let unit_schema = unit.unit.json_schema.clone();
        let context_data = course_context.clone();
        let slug = unit.unit.slug.clone();

        async move {
            let request = get_completion_request(
                &unit.unit.system_prompt,
                &unit.unit.user_prompt,
                unit_schema.to_value(),
                &get_context(&context_data, Some(&slug), None, None).join(", "),
            );

            let response = get_validated_response_slug::<UnitUploadModel>(&request, &slug).await;

            let unit_id = save_unit(&response, course_id).await;

            debug!("Unit Id: {}", unit_id);

            process_topics(unit, &context_data, &unit_id).await;
        }
    });

    // Await all tasks to complete
    units_stream.await;
}

async fn process_topics(
    unit: &Unit,
    course_context: &CourseContext,
    unit_id: &str,
) {
    let max_concurrent_requests = 1; // Limit concurrent requests if needed

    let topics_stream = stream::iter(unit.topics.iter()).for_each_concurrent(max_concurrent_requests, |topic| {
        let topic_schema = topic.json_schema.clone();
        let context_data = course_context.clone();
        let slug = unit.unit.slug.clone();

        async move {
            let request = get_completion_request(
                &topic.system_prompt,
                &topic.user_prompt,
                topic_schema.to_value(),
                &get_context(&context_data, Some(&slug), Some(&topic.slug), None).join(";"),
            );

            let response = get_validated_response_slug::<TopicCreateModel>(&request, &slug).await;

            save_topic(&response, unit_id).await;

            debug!("Sleeping for a second");
            thread::sleep(Duration::from_secs(1));
        }
    });

    // Await all tasks to complete
    topics_stream.await;
}

fn get_completion_request(
    system_prompt: &str,
    user_prompt: &str,
    json_schema: serde_json::Value,
    context_data: &str,
) -> PostChatCompletionRequest {
    PostChatCompletionRequest {
        messages: vec![
            Message {
                role: "system".to_string(),
                content: vec![Content {
                    content_type: ContentType::Text,
                    text: Some(system_prompt.to_string()),
                    image_url: None,
                }],
            },
            Message {
                role: "user".to_string(),
                content: vec![Content {
                    content_type: ContentType::Text,
                    text: Some(user_prompt.replace("{additional_context}", context_data)),
                    image_url: None,
                }],
            },
        ],
        response_format: Some(ResponseFormat {
            format_type: ResponseFormatType::JsonSchema,
            json_schema: Some(json_schema.clone()),
        }),
    }
}

async fn save_course(response: &str) -> String {
    let client = Database::get_client().await;
    let cache = cache_ops::Cache::default();
    let course_model = serde_json::from_str::<CourseRequestModel>(response).unwrap();
    let creator_id = match InstructorEntity::scan(&client).await {
        Some(instructor) => instructor.first().unwrap().user_id.clone(),
        None => {
            error!("No instructor found in the database");
            panic!("No instructor found in the database");
        }
    };
    let course_id = Database::generate_id();

    // check if the course exists
    if let Some(course) = CourseEntity::find_by_slug(&client, &cache, course_model.slug.clone()).await {
        debug!("Course exists: {}. Sending its Id", course_model.name);
        return course._id.to_hex();
    }

    // create if it doesn't exist
    let entity = CourseEntity {
        _id: course_id,
        name: course_model.name.clone(),
        slug: course_model.slug.clone(),
        meta_description: course_model.meta_description.clone(),
        summary: course_model.summary.clone(),
        created: date_ops::to_timestamp(),
        updated: date_ops::to_timestamp(),
        active: true,
        tags: course_model.tags.clone(),
        metadata: course_model.metadata.clone(),
        creator_id,
        disclaimer: course_model.disclaimer.clone(),
        intent: course_model.intent.clone(),
        restricted_words: course_model.restricted_words.clone(),
    };
    match entity.create(&client, &cache).await {
        Some(id) => id,
        None => {
            error!("Error creating course");
            panic!("Error creating course");
        }
    }
}

async fn save_unit(
    response: &str,
    course_id: &str,
) -> String {
    let client = Database::get_client().await;
    let cache = cache_ops::Cache::default();
    let unit_model = serde_json::from_str::<UnitUploadModel>(response).unwrap();
    let creator_id = match InstructorEntity::scan(&client).await {
        Some(instructor) => instructor.first().unwrap().user_id.clone(),
        None => {
            error!("No instructor found in the database");
            panic!("No instructor found in the database");
        }
    };

    // check if the unit exists
    if let Some(unit) = UnitEntity::find_by_slug_course(&client, &cache, &unit_model.slug, course_id).await {
        debug!("Unit exists: {}. Sending its Id", unit.first().unwrap().name);
        return unit.first().unwrap()._id.to_hex();
    }

    // if it doesn't exist, create it
    let unit_id = Database::generate_id();
    let entity = UnitEntity {
        _id: unit_id,
        name: unit_model.name.clone(),
        name_hash: hash_ops::string_hasher(&unit_model.name),
        slug: unit_model.slug.clone(),
        description: unit_model.description.clone(),
        creator_id,
        created_at: date_ops::to_timestamp(),
        updated_at: date_ops::to_timestamp(),
        course_id: course_id.to_string(),
        metadata: unit_model.metadata.clone(),
        unit_number: unit_model.unit_number,
    };
    match entity.create_force(&client, &cache).await {
        Some(id) => id,
        None => {
            error!("Error creating unit");
            panic!("Error creating unit");
        }
    }
}

async fn save_topic(
    response: &str,
    unit_id: &str,
) -> String {
    let client = Database::get_client().await;
    let cache = cache_ops::Cache::default();
    let topic_model = serde_json::from_str::<TopicCreateModel>(response).unwrap();
    let creator_id = match InstructorEntity::scan(&client).await {
        Some(instructor) => instructor.first().unwrap().user_id.clone(),
        None => {
            error!("No instructor found in the database");
            panic!("No instructor found in the database");
        }
    };

    // check if the topic exists
    if let Some(topic) = TopicEntity::find_by_slug_unit(&client, &cache, &topic_model.slug, unit_id).await {
        debug!("Topic exists: {}. Sending its Id", topic.first().unwrap().name);
        return topic.first().unwrap()._id.to_hex();
    }

    // if it doesn't exist, create it
    let entity = TopicEntity {
        _id: Database::generate_id(),
        name: topic_model.name.clone(),
        name_hash: hash_ops::string_hasher(&topic_model.name),
        summary: Some(topic_model.summary),
        slug: topic_model.slug.clone(),
        meta_description: topic_model.meta_description.clone(),
        markdown: topic_model.markdown.clone(),
        creator_id,
        created_at: date_ops::to_timestamp(),
        updated_at: date_ops::to_timestamp(),
        unit_id: unit_id.to_string(),
        tags: topic_model.tags.clone(),
        scope: topic_model.scope.clone(),
        // metadata: Some(topic_model.metadata),
        topic_number: topic_model.topic_number,
    };
    match entity.create_force(&client, &cache).await {
        Some(id) => id,
        None => {
            error!("Error creating unit");
            panic!("Error creating topic");
        }
    }
}
