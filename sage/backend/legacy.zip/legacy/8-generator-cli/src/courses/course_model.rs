use aarya_entities::{course::course_entity::CourseRequestModel, topic::topic_entity::TopicCreateModel, unit::unit_entity::UnitUploadModel};
use aarya_utils::{file_ops, schema_ops};
use log::error;
use schemars::JsonSchema;
use serde::{Deserialize, Serialize};

use crate::openai_model::OpenAiSchemaModel;

#[derive(Debug, Serialize, Deserialize, Clone, JsonSchema)]
pub struct PromptCourseModel {
    pub course: String,
    pub unit: String,
    pub topic: String,
}

#[derive(Debug, Serialize, Deserialize, Clone, JsonSchema)]
pub struct PromptModel {
    pub user: PromptCourseModel,
    pub system: PromptCourseModel,
}

#[derive(Debug, Serialize, Deserialize, Clone, JsonSchema)]
pub struct Target {
    pub slug: String,
    pub name: String,
    pub user_prompt: String,
    pub system_prompt: String,
    pub json_schema: OpenAiSchemaModel,
}

#[derive(Debug, Serialize, Deserialize, Clone, JsonSchema)]
pub struct Unit {
    pub unit: Target,
    pub topics: Vec<Target>,
}

#[derive(Debug, Serialize, Deserialize, Clone, JsonSchema)]
pub struct CourseModel {
    pub course: Target,
    pub units: Vec<Unit>,
}

impl Default for CourseModel {
    fn default() -> Self {
        CourseModel {
            course: Target {
                slug: "".to_string(),
                name: "".to_string(),
                user_prompt: "".to_string(),
                system_prompt: "".to_string(),
                json_schema: OpenAiSchemaModel::default(),
            },
            units: vec![],
        }
    }
}

impl CourseModel {
    pub fn from_json(json: &str) -> Option<CourseModel> {
        match serde_json::from_str(json) {
            Ok(c) => Some(c),
            Err(e) => {
                error!("Error parsing course model from json: {}", e);
                None
            }
        }
    }

    pub fn with_schema(&mut self) -> Option<Self> {
        self.course.json_schema = OpenAiSchemaModel {
            name: "CourseRequestModel".to_string(),
            schema: schema_ops::to_openai_schema(schema_ops::to_json_schema::<CourseRequestModel>().unwrap()).unwrap(),
        };

        let unit_schema = schema_ops::to_openai_schema(schema_ops::to_json_schema::<UnitUploadModel>().unwrap()).unwrap();
        let topic_schema = schema_ops::to_openai_schema(schema_ops::to_json_schema::<TopicCreateModel>().unwrap()).unwrap();

        // set the json schema for the units and topics
        for unit in self.units.iter_mut() {
            unit.unit.json_schema = OpenAiSchemaModel {
                name: "UnitUploadModel".to_string(),
                schema: unit_schema.clone(),
            };

            for topic in unit.topics.iter_mut() {
                topic.json_schema = OpenAiSchemaModel {
                    name: "TopicCreateModel".to_string(),
                    schema: topic_schema.clone(),
                };
            }
        }

        Some(self.clone())
    }
}

impl PromptModel {
    pub fn from_file(prompt_file: String) -> Self {
        let prompt_str = file_ops::read_file(prompt_file.as_str()).unwrap();
        let prompt_data: PromptModel = serde_json::from_str(&prompt_str).unwrap();
        prompt_data
    }

    pub fn from_audience(
        &self,
        target_audience: String,
    ) -> Self {
        let mut prompt = self.clone();
        prompt.user.course = prompt.user.course.clone().replace("{target_audience}", target_audience.as_str());
        prompt.system.course = prompt.system.course.clone().replace("{target_audience}", target_audience.as_str());
        prompt.user.unit = prompt.user.unit.clone().replace("{target_audience}", target_audience.as_str());
        prompt.system.unit = prompt.system.unit.clone().replace("{target_audience}", target_audience.as_str());
        prompt.user.topic = prompt.user.topic.clone().replace("{target_audience}", target_audience.as_str());
        prompt.system.topic = prompt.system.topic.clone().replace("{target_audience}", target_audience.as_str());
        prompt
    }
}
