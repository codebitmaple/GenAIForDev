use aarya_utils::file_ops;
use schemars::JsonSchema;
use serde::{Deserialize, Serialize};

use crate::{
    courses::course_model::{CourseModel, PromptModel, Target, Unit},
    openai_model::OpenAiSchemaModel,
};

#[derive(Serialize, Deserialize, Debug, Clone, JsonSchema)]
pub struct MetadataContext {
    pub key: String,
    pub value: String,
}

#[derive(Serialize, Deserialize, Debug, Clone, JsonSchema)]
pub struct TopicContext {
    pub topic_slug: String,
    pub name: String,
    pub metadata: Vec<MetadataContext>,
}

#[derive(Serialize, Deserialize, Debug, Clone, JsonSchema)]
pub struct UnitContext {
    pub unit_slug: String,
    pub name: String,
    pub metadata: Vec<MetadataContext>,
    pub topics: Vec<TopicContext>,
}

#[derive(Serialize, Deserialize, Debug, Clone, JsonSchema)]
pub struct CourseContext {
    pub course_slug: String,
    pub name: String,
    pub metadata: Vec<MetadataContext>,
    pub units: Vec<UnitContext>,
}

// Function to find metadata based on the key
fn find_metadata(
    metadata: &[MetadataContext],
    key: Option<&str>,
) -> Vec<String> {
    metadata.iter().filter(|meta| key.map_or(true, |k| meta.key == k)).map(|meta| meta.value.clone()).collect()
}

// Function to get context based on course, unit, and topic slugs, and metadata key
pub fn get_context(
    course: &CourseContext,
    unit_slug: Option<&str>,
    topic_slug: Option<&str>,
    key: Option<&str>,
) -> Vec<String> {
    let mut results = vec![];

    // If no unit_slug is provided, return course-level metadata
    if unit_slug.is_none() {
        results.extend(find_metadata(&course.metadata, key));
        return results;
    }

    // Find the unit based on the provided unit_slug
    if let Some(unit) = course.units.iter().find(|u| unit_slug.map_or(true, |us| u.unit_slug == us)) {
        // If no topic_slug is provided, return unit-level metadata
        if topic_slug.is_none() {
            results.extend(find_metadata(&unit.metadata, key));
            return results;
        }

        // Find the topic based on the provided topic_slug
        if let Some(topic) = unit.topics.iter().find(|t| topic_slug.map_or(true, |ts| t.topic_slug == ts)) {
            results.extend(find_metadata(&topic.metadata, key));
        }
    }

    results
}

impl CourseContext {
    pub fn from_file(context_file: String) -> Self {
        // load course context
        let context_str = file_ops::read_file(context_file.as_str()).unwrap();
        let context_data: CourseContext = serde_json::from_str(&context_str).unwrap();
        context_data
    }

    pub fn to_model(
        &self,
        prompt_model: &mut PromptModel,
    ) -> CourseModel {
        let mut model = CourseModel::default();
        model.course.slug = self.course_slug.clone();
        model.course.name = self.name.clone();
        prompt_model.user.course = prompt_model.user.course.clone().replace("{course_name}", self.name.as_str());
        prompt_model.system.course = prompt_model.system.course.clone().replace("{course_name}", self.name.as_str());
        model.course.user_prompt = prompt_model.user.course.clone();
        model.course.system_prompt = prompt_model.system.course.clone();

        for unit in self.units.iter() {
            model.units.push(Unit {
                unit: Target {
                    slug: unit.unit_slug.clone(),
                    name: unit.name.clone(),
                    user_prompt: prompt_model.user.unit.replace("{unit_name}", unit.name.as_str()).replace("{course_name}", model.course.name.as_str()),
                    system_prompt: prompt_model.system.unit.replace("{unit_name}", unit.name.as_str()).replace("{course_name}", model.course.name.as_str()),
                    json_schema: OpenAiSchemaModel::default(),
                },
                topics: unit
                    .topics
                    .iter()
                    .map(|topic| Target {
                        slug: topic.topic_slug.clone(),
                        name: topic.name.clone(),
                        user_prompt: prompt_model
                            .user
                            .topic
                            .replace("{topic_name}", topic.name.as_str())
                            .replace("{course_name}", model.course.name.as_str())
                            .replace("{unit_name}", unit.name.as_str()),
                        system_prompt: prompt_model
                            .system
                            .topic
                            .replace("{topic_name}", topic.name.as_str())
                            .replace("{course_name}", model.course.name.as_str())
                            .replace("{unit_name}", unit.name.as_str()),
                        json_schema: OpenAiSchemaModel::default(),
                    })
                    .collect(),
            });
        }

        model
    }
}
