use aarya_entities::openai::{
    completion_request::{Content, ContentType, Message},
    PostChatCompletionRequest,
};
use aarya_utils::file_ops;
use futures::{stream, StreamExt};

use crate::openai_model::get_response;

use super::post_context::PostContext;

pub async fn handle_post(context_file: String) {
    let mut context = PostContext::read_context_file(context_file);
    context.replace_placeholders();
    let max_concurrent_requests = 1;
    let body_requests = context.create_body_request();

    let body_stream = stream::iter(body_requests.iter()).for_each_concurrent(max_concurrent_requests, |body| {
        let requests_folder = context.requests_folder.clone();
        let responses_folder = context.responses_folder.clone();
        async move {
            // save request to file
            file_ops::write_file_force(format!("{}/{}.txt", requests_folder, body.name.to_lowercase()).as_str(), &body.text).unwrap();
            let request = PostChatCompletionRequest {
                messages: vec![Message {
                    role: "user".to_string(),
                    content: vec![Content {
                        content_type: ContentType::Text,
                        text: Some(body.text.clone()),
                        image_url: None,
                    }],
                }],
                response_format: None,
            };
            let response = get_response(&request, "aarya").await;
            // save response to file
            file_ops::write_file_force(format!("{}/{}.md", responses_folder, body.name.to_lowercase()).as_str(), response.unwrap().as_str()).unwrap();
        }
    });

    // Await all tasks to complete
    body_stream.await;

    // for request in body_requests {
    //     file_ops::write_file_force(format!("{}/{}.txt", context.requests_folder, request.name.to_lowercase()).as_str(), &request.text).unwrap();
    // }
    // let summary_requests = context.create_summary_request();
    // for request in summary_requests {
    //     file_ops::write_file_force(format!("{}/{}.txt", context.requests_folder, request.name.to_lowercase()).as_str(), &request.text).unwrap();
    // }
    // let part_requests = context.create_post_parts();
    // for request in part_requests {
    //     file_ops::write_file_force(format!("{}/{}.txt", context.requests_folder, request.name.to_lowercase()).as_str(), &request.text).unwrap();
    // }
    // let social_requests = context.create_social_requests();
    // for request in social_requests {
    //     file_ops::write_file_force(format!("{}/{}.txt", context.requests_folder, request.name.to_lowercase()).as_str(), &request.text).unwrap();
    // }
}
