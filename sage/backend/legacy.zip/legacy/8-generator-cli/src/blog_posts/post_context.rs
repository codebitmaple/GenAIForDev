use std::str::FromStr;

use aarya_utils::file_ops;
use schemars::JsonSchema;
use serde::{Deserialize, Serialize};

#[derive(Serialize, Deserialize, Debug, Clone, JsonSchema)]
pub struct PostContext {
    pub role: String,
    pub source: String,
    pub s3_path: String,
    pub platforms: Vec<Platform>,
    pub responses_folder: String,
    pub requests_folder: String,
    pub tentative_title: String,
}

#[derive(Serialize, Deserialize, Debug, Clone, JsonSchema)]
pub struct Platform {
    pub name: SocialPlatform,
    pub instruction_file: String,
    pub tone: WriterTone,
    pub image_file: Option<String>,
}

// This ensures JSON values are matched case-insensitively
// Also allow free-text as a fallback
#[derive(Serialize, Deserialize, Debug, Clone, JsonSchema)]
#[serde(rename_all = "lowercase")]

pub enum WriterTone {
    Novice,
    Professional,
    Friendly,
    Editorial,
    Academic,
    Random,
    Default,
    Argumentative,
    Exploratory,
}

// This ensures JSON values are matched case-insensitively
// Also allow free-text as a fallback
#[derive(Serialize, Deserialize, Debug, Clone, JsonSchema)]
#[serde(rename_all = "lowercase")] // This ensures JSON values are matched case-insensitively
pub enum SocialPlatform {
    Aarya,
    LinkedIn,
    Twitter,
    Medium,
    DevTo,
    Substack,
    Facebook,
}

impl FromStr for SocialPlatform {
    type Err = ();

    fn from_str(platform: &str) -> Result<Self, Self::Err> {
        Ok(match platform.to_lowercase().as_str() {
            "linkedin" => SocialPlatform::LinkedIn,
            "twitter" => SocialPlatform::Twitter,
            "medium" => SocialPlatform::Medium,
            "devto" => SocialPlatform::DevTo,
            "substack" => SocialPlatform::Substack,
            "facebook" => SocialPlatform::Facebook,
            "aarya" => SocialPlatform::Aarya,
            _ => SocialPlatform::Aarya,
        })
    }
}

impl SocialPlatform {
    pub fn to_str(&self) -> String {
        match self {
            SocialPlatform::LinkedIn => "LinkedIn".to_string(),
            SocialPlatform::Twitter => "Twitter".to_string(),
            SocialPlatform::Medium => "Medium".to_string(),
            SocialPlatform::DevTo => "Dev.to".to_string(),
            SocialPlatform::Substack => "Substack".to_string(),
            SocialPlatform::Facebook => "Facebook".to_string(),
            SocialPlatform::Aarya => "Aarya".to_string(),
        }
    }
}

impl FromStr for WriterTone {
    type Err = ();
    fn from_str(tone: &str) -> Result<Self, Self::Err> {
        Ok(match tone.to_lowercase().as_str() {
            "novice" => WriterTone::Novice,
            "professional" => WriterTone::Professional,
            "friendly" => WriterTone::Friendly,
            "editorial" => WriterTone::Editorial,
            "academic" => WriterTone::Academic,
            "argumentative" => WriterTone::Argumentative,
            "exploratory" => WriterTone::Exploratory,
            _ => WriterTone::Default,
        })
    }
}

impl WriterTone {
    pub fn to_str(&self) -> String {
        match self {
            WriterTone::Novice => "novice".to_string(),
            WriterTone::Professional => "professional".to_string(),
            WriterTone::Friendly => "friendly".to_string(),
            WriterTone::Editorial => "editorial".to_string(),
            WriterTone::Academic => "academic".to_string(),
            WriterTone::Random => "random".to_string(),
            WriterTone::Default => "default".to_string(),
            WriterTone::Argumentative => "argumentative".to_string(),
            WriterTone::Exploratory => "exploratory".to_string(),
        }
    }
}

#[derive(Serialize, Deserialize, Debug, Clone, JsonSchema)]
pub struct RequestModel {
    pub name: String,
    pub text: String,
}

impl PostContext {
    pub fn read_context_file(context_file: String) -> Self {
        // load course context
        let context_str = file_ops::read_file(context_file.as_str()).unwrap();
        let context_data: PostContext = serde_json::from_str(&context_str).unwrap();
        context_data
    }

    pub fn replace_placeholders(&mut self) {
        self.source = self.source.replace("{tentative_title}", &self.tentative_title);
        self.s3_path = self.s3_path.replace("{tentative_title}", &self.tentative_title);
        self.responses_folder = self.responses_folder.replace("{tentative_title}", &self.tentative_title);
        self.requests_folder = self.requests_folder.replace("{tentative_title}", &self.tentative_title);
        self.platforms.iter_mut().for_each(|platform| {
            if let Some(image_file) = &mut platform.image_file {
                *image_file = image_file.replace("{tentative_title}", &self.tentative_title);
            }
        });
    }

    pub fn create_body_request(&self) -> Vec<RequestModel> {
        let mut requests = vec![];

        for platform in &self.platforms {
            match platform.name {
                SocialPlatform::Aarya => {
                    requests.push(self.build_request("blog post", platform, platform.instruction_file.replace("{sub_topic}", "body").as_str(), Some("body")));
                }
                SocialPlatform::LinkedIn => {}
                SocialPlatform::Twitter => {}
                SocialPlatform::Medium => {}
                SocialPlatform::DevTo => {}
                SocialPlatform::Substack => {}
                SocialPlatform::Facebook => {}
            }
        }

        requests
    }

    pub fn create_summary_request(&self) -> Vec<RequestModel> {
        let mut requests = vec![];

        for platform in &self.platforms {
            match platform.name {
                SocialPlatform::Aarya => {
                    requests.push(self.build_request("blog post summary", platform, platform.instruction_file.replace("{sub_topic}", "summary").as_str(), Some("summary")));
                }
                SocialPlatform::LinkedIn => {}
                SocialPlatform::Twitter => {}
                SocialPlatform::Medium => {}
                SocialPlatform::DevTo => {}
                SocialPlatform::Substack => {}
                SocialPlatform::Facebook => {}
            }
        }

        requests
    }

    pub fn create_post_parts(&self) -> Vec<RequestModel> {
        let mut requests = vec![];

        for platform in &self.platforms {
            match platform.name {
                SocialPlatform::Aarya => {
                    requests.push(self.build_request(
                        "permalink for blog post",
                        platform,
                        platform.instruction_file.replace("{sub_topic}", "permalink").as_str(),
                        Some("permalink"),
                    ));
                    requests.push(self.build_request("tldr for blog post", platform, platform.instruction_file.replace("{sub_topic}", "tldr").as_str(), Some("tldr")));
                    requests.push(self.build_request(
                        "html meta description for blog post",
                        platform,
                        platform.instruction_file.replace("{sub_topic}", "description").as_str(),
                        Some("description"),
                    ));
                    requests.push(self.build_request("title of the blog post", platform, platform.instruction_file.replace("{sub_topic}", "title").as_str(), Some("title")));
                    requests.push(self.build_request(
                        "subtitle for blog post",
                        platform,
                        platform.instruction_file.replace("{sub_topic}", "subtitle").as_str(),
                        Some("subtitle"),
                    ));
                    requests.push(self.build_request(
                        "keywords for blog post",
                        platform,
                        platform.instruction_file.replace("{sub_topic}", "keywords").as_str(),
                        Some("keywords"),
                    ));
                    requests.push(self.build_request("tags for blog post", platform, platform.instruction_file.replace("{sub_topic}", "tags").as_str(), Some("tags")));
                }
                SocialPlatform::LinkedIn => {}
                SocialPlatform::Twitter => {}
                SocialPlatform::Medium => {}
                SocialPlatform::DevTo => {}
                SocialPlatform::Substack => {}
                SocialPlatform::Facebook => {}
            }
        }

        requests
    }

    pub fn create_social_requests(&self) -> Vec<RequestModel> {
        let mut requests = vec![];
        for platform in &self.platforms {
            match platform.name {
                SocialPlatform::LinkedIn => {
                    requests.push(self.build_request("LinkedIn post", platform, platform.instruction_file.as_str(), None));
                }
                SocialPlatform::Twitter => {
                    requests.push(self.build_request("Twitter post", platform, platform.instruction_file.as_str(), None));
                }
                SocialPlatform::Medium => {
                    requests.push(self.build_request("Medium post", platform, platform.instruction_file.as_str(), None));
                }
                SocialPlatform::DevTo => {
                    requests.push(self.build_request("Dev.to technical blog post", platform, platform.instruction_file.as_str(), None));
                }
                SocialPlatform::Substack => {
                    requests.push(self.build_request("Substack email post", platform, platform.instruction_file.as_str(), None));
                }
                SocialPlatform::Facebook => {
                    requests.push(self.build_request("Facebook post", platform, platform.instruction_file.as_str(), None));
                }
                SocialPlatform::Aarya => {}
            }
        }
        requests
    }

    fn build_request(
        &self,
        piece: &str,
        platform: &Platform,
        instruction: &str,
        sub_topic: Option<&str>,
    ) -> RequestModel {
        let instruction_str = file_ops::read_file(instruction).unwrap(); // Read instruction from file
        let source_str = file_ops::read_file(self.source.as_str()).unwrap(); // Read source from file
        RequestModel {
            name: match sub_topic {
                Some(sub_topic) => format!("{}-{}", platform.name.to_str(), sub_topic),
                None => platform.name.to_str(),
            },
            text: format!(
                "You are an {}. \n\nUse the following to write a {}: \n{}. \n\nUse a {} tone. \n\nUse the following instructions to write: \n{}",
                self.role,
                piece,
                source_str,
                platform.tone.to_str(),
                instruction_str
            ),
        }
    }
}
