```
../target/debug/aarya-generator-cli courses \
--target-audience "High School Student" \
--prompt-file ./prompts/apcs.json \
--context-file ./contexts/courses/ap-csp-u2.json
```

```
../target/debug/aarya-generator-cli exercise-questions \
 --context-file ./contexts/questions/apcsp-exercises-all.json
```

```
../target/debug/aarya-generator-cli exam-questions \
--context-file ./contexts/questions/apcsa-exams-all.json
```

```
../target/debug/aarya-generator-cli generated-exam-questions \
--context-file ./contexts/questions/generated/apcsa-exams.json
```

```
../target/debug/aarya-generator-cli generate-requests \
--context-file ./contexts/questions/apcsa-exams-all-text.json
```
