# Stop Working — You’re a Manager Now

Maybe you didn’t dream of becoming a manager when you were a kid pretending to be an astronaut or veterinarian. But
years of hard work and crushing it meant that this trajectory was all but inevitable (even if that’s not smart for
business).

Congratulations are in order! Let’s go out for a drink and celebrate your flashy career milestone of being the first
person to blame when work doesn’t get done according to the latest Gantt chart! (Please tell me you don’t use Gantt
charts.)

But hey, at least you got that fancy new title, and hopefully a salary bump to go with it.

So… now what?

Being a first-time manager is essentially akin to becoming a whole new species of professional. You’ll need to rapidly
evolve from your former self into a more advanced, more disciplined, more emotionally intelligent being that thrives in
the most inhospitable of work environments — ones you may have only seen from afar (or not at all).

Go ahead and wipe away those tears. You’ll get through this period of metamorphosis and emerge from your proverbial
cocoon as a people leader worthy of leading…well, people.

But first, let’s talk about your new work life.

Why the transition is so mind-bendingly painful So you got the promotion. A career-defining moment that comes with it
newfound power. But… what’s that quote? Ah yes: With great power comes great responsibility. And headaches. Lots and
lots of headaches. I think Uncle Ben forgot to say that part out loud.

Let’s get specific on what makes this shift feel as tough as the nails that are seemingly being hammered inside your
skull — because if you can understand who or what is causing the pain, that can make the experience a bit more…
manageable (sorry not sorry).

#1: You’re dealing with office politics for the first time As an individual contributor (IC), you were happily insulated
in your own little world. You likely only had to focus on doing your job well, being a good teammate, and contributing
to the goals of the wider team. I’m sure you’ve had moments where you needed to navigate some tricky internal company
politics or culture, but that was nothing compared to constantly needing to play “the game”.

Your world is about to open up to the unfortunate and distressing reality that while the work is important, the
workplace is just as important. Every decision suddenly has ripple effects across departments, teams, managers, and
executives. You’ll need to constantly balance (often conflicting) business needs and priorities with individual skill
sets and personalities, all in a way that somehow makes everyone happy, especially including those pesky stakeholders.
(Spoiler: welcome to the losing proposition that is now your life.)

#2: You have no training for any of this It’s not like going to management “school” is as straightforward as declaring a
major in college. Sure, there are educational programs that help teach management theory. But how often does life happen
according to those straightforward plans?

Not only that, but companies generally don’t provide even a modicum of training for managers. You’ll be thrown to the
wolves, trying to figure out everything from scratch.

For instance, do you know…:

How to run productive 1:1s? How to give insightful feedback? How to help your reports develop into better professionals?
How to advocate for your team by fighting for the budgets and priorities that will lead to their continued engagement
and retention? Consider yourself lucky if you have an understanding, experienced manager taking you under their wing.
More often, you’ll need to rely on researching and reading and learning by failing over and over again until you start
to figure it out.

#3: You’re going to disappoint people It doesn’t really matter how thoughtful or considerate or amazing you think you
are. Somewhere down this new journey of yours, you are going to let someone down. And hard. I guarantee it.

Maybe it’s that one person who taught you everything you know, and now you’ve had to make the difficult decision of
passing them over for a promotion because you saw potential in someone else. Maybe it’s your own boss, as you fight the
good fight for your team’s priorities, only to get denied — and then you have to deliver that bad news to the people
relying on you. Maybe it’s yourself. We all go into management roles believing we’ll be the exception to the rule, only
to realize there are so many exceptions, we become just another example ourselves. The transition is an emotional
rollercoaster that you could never have adequately braced for ahead of time. It’s one thing to read about impostor
syndrome; it’s another to experience it in full force as you begin to question yourself at every turn.

If it makes you feel any better, it’s not only impostor syndrome — you’ll actually do it wrong plenty of the time, too!

Yay?

What not to do anymore Alright, so we’ve covered some of the reasons why shifting from an individual contributor to a
first-time manager is the career equivalent of being the first human to land on Mars. It’s insanely exciting and you
feel like a bona fide trailblazer. But it’s also incredibly dangerous, lonely, and uncomfortable.

What do you do from here?

Well, the first thing is to be aware of what you should stop doing — basically all of the behaviors that were acceptable
and necessary when you were an IC, but are now anathema to being a quality people leader.

#1: Stop believing you can keep doing the same work We’ve all made this naive mistake. You get that new “Manager” title,
but somehow still think you can continue diving deep into the tactical, ground-level work that your team is doing.

You can’t.

I’m serious here. Everyone says they understand this, but they don’t really get it, not at first. Pause here for a
moment and let it sink in.

Your life as an individual contributor is over.

You have to shift your mindset towards enabling your team to do the work instead of doing it yourself. You may have been
an amazing engineer, designer, or analyst. But now is the time to become a coach, facilitator, and people leader.

If you insist on staying in the trenches, you’ll quickly find yourself overwhelmed and with absolutely no time to focus
on the bigger picture responsibilities that come with being a manager (i.e., your job). At best, your reports will
resent you for micromanaging and not giving them autonomy. At worst, you’ll fail them by never providing the career
development opportunities, team advocacy, and strategic vision leadership that they need from you.

Again, say it with me:

Your life as an individual contributor is over.

#2: Stop thinking success is about you You may have always been an IC who took work seriously, never missed a deadline,
and volunteered for every new initiative. Maybe you believed that was the key to moving up in the world. (And maybe that
worked.)

As a manager, though, that individualistic style of working simply doesn’t translate. Your job is no longer about how
impressive or talented or hard-working you are personally. It’s about cultivating those traits in your team and enabling
them to be their best selves, both individually and collectively.

Going forward, your contributions need to happen through other people, rather than you being the one delivering results
yourself.

#3: Stop solving every problem yourself Your years of training and instinct as an individual contributor make you want
to dive in headfirst every time a problem or challenge comes across your desk (or Slack channel or video call or email).
You know how to build things rapidly, you know all the pitfalls and shortcuts, and you get an adrenaline rush from
coming up with clever solutions.

Resist this urge at all costs.

You may think you’re being helpful and efficient by solving every single issue yourself. But you’re actually being
incredibly detrimental to your team’s growth and development. They’ll:

start over-relying on you stop stretching their own critical thinking abilities lose their sense of accountability and
ownership lose faith in their own skills and autonomy Don’t let any of that happen.

When issues arise, force yourself to ask questions rather than provide answers. Push your team to come up with their own
solutions and proposals. Guide them through the process of investigating root causes, considering different approaches,
and outlining potential implications. As much as it may pain you, do not reflexively jump in with “here’s how we’re
going to solve this.”

You are now the coach on the sidelines providing perspective and wisdom, not the star player.

What to start doing Enough about all the things you need to stop doing. Let’s provide some more positive, constructive
advice on the types of behaviors you must start embracing as a new manager.

#1: Start being overly transparent and building trust One of the most vital steps towards being a successful manager is
building and maintaining trust. Without that foundation, everything quickly crumbles — decision-making becomes opaque,
people inevitably begin to feel misled, and toxicity can spread like a virus throughout the whole team dynamic.

The antidote is to make a staunch commitment to being as transparent as possible in every situation. Constantly outline
the context around choices being made, the rationale that went into the ultimate decisions, and any lingering
uncertainties or risks that still remain. For example:

If you had to sacrifice one priority for another based on directions from your leadership, make that clear. If you
weren’t able to secure more headcount or budget for the team, explain what happened. If you continue deferring an issue
your team cares about, be upfront as to why. Remember: people can’t connect all the dots themselves — they lack the more
complete context you will be granted (and they can’t read your mind).

Transparency and trust will give your reports the information and psychological safety they need to do their best work.

#2: Start getting out of your comfort zone As an individual contributor, you were likely able to double down on the
skills and tasks that played to your natural strengths and inclinations. If you were an introvert, you could put your
head down and focus more on solo work. If you were an extrovert, you gravitated towards roles allowing you to interact
with other humans. If you enjoyed coding, you coded. If you preferred visual design, you got to design all day.

Those days are gone now that you’re a manager. You now have to stretch yourself across many different responsibilities
and disciplines.

Maybe you’ll need to put on a public speaking hat to help evangelize your team’s work and raise their profile. Maybe
you’ll be expected to jump into negotiations for contracts, budgets, or headcount. Maybe you’ll have to become a data
storytelling pro to get buy-in for your roadmap and vision. You’ll have to find ways to build up new muscle memories and
coping mechanisms for all of the uncomfortable situations that managing throws your way.

Give yourself plentiful opportunities to evolve into a well-rounded leader capable of creating focus and delivering
outcomes through others.

#3: Start being an advocate and champion You have to start proactively sticking up for your people and fighting to
ensure they have all the resources, support, air cover, and opportunities they need from the wider organization. You
must make it an unwavering commitment to go to battle for your team’s priorities, career development, and overall
well-being.

This means:

having difficult conversations with your own manager and cross-functionally when your team’s workload becomes
unmanageable or their output is being blocked by counterproductive dependencies. pushing for promotions even when the
timing or budget isn’t ideal. bringing hard truths to light about things the organization needs to improve for the sake
of employee engagement and retention. In other words, it means sticking your neck out repeatedly on behalf of the people
who are counting on you as their leader. It requires an entirely different mental shift towards prioritizing advocacy
over individual achievements.

Fight for your team, so they have the space and motivation to deliver.

Wrapping it up The leap from an individual contributor role to a first-time manager may be one of the most difficult
career transitions you’ll experience. After spending years honing your specialist skills and focusing on your personal
outputs, you now have to shift gears completely. Instead of doing the work yourself, your job becomes enabling a team of
others to achieve success through your guidance, support, and leadership.

It’s a transition filled with confusion, self-doubt, and constant battles against your former instincts. What made you
so successful before can often be the very thing holding you back from thriving in your new role. You have to evolve
into an entirely different kind of professional — where your impact is generated through others’ hands rather than your
own.

It won’t be easy by any stretch. But if you can resist the temptations to keep operating like an IC, and instead get out
of your comfort zone, build trust, and advocate for your team, you’ll be well on your way.

So stop working already. You’re a manager now.
