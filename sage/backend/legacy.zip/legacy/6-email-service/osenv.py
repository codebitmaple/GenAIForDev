import os

from dotenv import load_dotenv

# Load environment variables based on the environment
if os.getenv('APP_ENV') == 'production':
    load_dotenv(".env.prod")
else:
    load_dotenv(".env.dev")

def get_redis_server():
    return os.getenv("REDIS_SERVER")