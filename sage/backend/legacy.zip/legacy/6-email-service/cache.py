import redis
import osenv

# Initialize Redis connection
redis_client = redis.StrictRedis(host=osenv.get_redis_server(), port=6379, db=0)

def set_string(key: str, value: str, ttl: int = 3600) -> bool:
    """
    Set an idempotent key in Redis with an expiration time (TTL).
    :param key: The unique key to be stored
    :param value: The string value to be stored
    :param ttl: Time to live in seconds (default is 3600 seconds = 1 hour)
    :return: True if successfully set, False otherwise
    """
    try:
        # Store the string value with the given TTL (in seconds)
        redis_client.setex(key, ttl, value)
        return True
    except Exception as e:
        print(f"Error setting key: {e}")
        return False

def get_string(key: str) -> str:
    """
    Get the value of an idempotent key from Redis.
    :param key: The unique key to retrieve
    :return: The stored value as a string, or None if not found
    """
    try:
        value = redis_client.get(key)
        if value:
            return value.decode('utf-8')  # Decode from bytes to string
        return None
    except Exception as e:
        print(f"Error getting key: {e}")
        return None