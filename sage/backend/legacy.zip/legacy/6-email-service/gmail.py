from fastapi import FastAPI, HTTPException
from google.oauth2 import service_account
from googleapiclient.discovery import build
from email.mime.text import MIMEText
import base64
import cache

from pydantic import BaseModel

app = FastAPI()

SCOPES = ['https://www.googleapis.com/auth/gmail.send']
SERVICE_ACCOUNT_FILE = '.secrets/aarya-service-account-key.json'
USER_EMAIL = 'sanjeet@aarya.ai'

credentials = service_account.Credentials.from_service_account_file(
    SERVICE_ACCOUNT_FILE, scopes=SCOPES
).with_subject(USER_EMAIL)

class EmailRequest(BaseModel):
    key: str
    to: str
    subject: str
    body: str

def create_message(to, subject, message_text):
    message = MIMEText(message_text, "html")
    message['to'] = to
    message['subject'] = subject
    raw = base64.urlsafe_b64encode(message.as_bytes()).decode()
    return {'raw': raw}

def send_message(to, subject, body):
    try:
        service = build('gmail', 'v1', credentials=credentials)
        message = create_message(to, subject, body)
        sent_message = service.users().messages().send(userId=USER_EMAIL, body=message).execute()
        return sent_message
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/send-email/")
async def send_email(email: EmailRequest):
    print(email)
    # send email because the key does not exist
    if cache.get_string(email.key) is None:
        try:
            result = send_message(email.to, email.subject, email.body)
            return {"message_id": result['id']}
        except Exception as e:
            print(f"error sending email for {email.key}, {email.to} due to {e}")
            return None
    else:
        print(f"not sending duplicate email for {email.key}")
        cache.set_string(email.key, email.key)
        return None

