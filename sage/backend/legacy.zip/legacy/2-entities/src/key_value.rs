use schemars::JsonSchema;
use serde::{Deserialize, Serialize};

#[derive(Debug, Serialize, Deserialize, Clone, JsonSchema)]
pub struct KeyValues {
    pub key: String,
    pub value: Vec<String>,
}

#[derive(Debug, Serialize, Deserialize, Clone, JsonSchema)]
pub struct KeyValue {
    #[schemars(length(min = 1, max = 64))]
    pub key: String,
    #[schemars(length(min = 1, max = 2048))]
    pub value: String,
}

#[derive(Debug, Serialize, Deserialize, Clone, JsonSchema)]
pub struct KeyComplexValue {
    #[schemars(length(min = 1, max = 64))]
    pub key: String,
    #[schemars(length(min = 1, max = 16))]
    pub value: Vec<KeyValue>,
}

impl Default for KeyValues {
    fn default() -> Self {
        KeyValues {
            key: "not-set".to_string(),
            value: vec![],
        }
    }
}
