use ::serde::{Deserialize, Serialize};
use aarya_utils::{
    date_ops,
    db_ops::Database,
    result_types::{EntityResult, SuccessResultType},
};
use mongodb::{
    bson::{doc, oid::ObjectId},
    Client,
};

#[derive(Debug, Serialize, Deserialize, Clone)]
pub enum ChatSource {
    #[serde(rename = "topic-followup")]
    Topic,
    #[serde(rename = "practice")]
    Practice,
    #[serde(rename = "answer-recommendations")]
    Recommendation,
}

#[derive(Debug, Serialize, Deserialize, Clone)]
struct RecommendationChatSource {
    #[serde(rename = "Question")]
    pub question: String,
    #[serde(rename = "Choices")]
    pub choices: String,
    #[serde(rename = "AnswerExplanation")]
    pub answer_explanation: String,
    #[serde(rename = "KeyConcept")]
    pub key_concept: String,
    #[serde(rename = "UserResponse")]
    pub user_response: String,
    #[serde(rename = "Result")]
    pub result: bool,
}

#[derive(Debug, Serialize, Deserialize, Clone)]
struct PracticeChatSource {
    pub description: String,
    pub followups: Vec<String>,
}

#[derive(Debug, Serialize, Deserialize, Clone)]
pub struct ChatResponseModel {
    pub id: String,
    pub question: String,
    pub explanation: String,
    pub source: String,
    pub date_created: String,
    pub context: String,
    pub about: String,
    pub unit_name: Option<String>,
    pub topic_name: Option<String>,
    pub summary: Option<String>,
    pub title: Option<String>,
}

impl Default for ChatResponseModel {
    fn default() -> Self {
        ChatResponseModel {
            id: "not-set".to_string(),
            question: "not-set".to_string(),
            source: "not-set".to_string(),
            explanation: "not-set".to_string(),
            date_created: date_ops::to_display_date(date_ops::local_date_time()),
            about: "not-set".to_string(),
            context: "not-set".to_string(),
            unit_name: None,
            topic_name: None,
            summary: None,
            title: None,
        }
    }
}

impl From<ChatEntity> for ChatResponseModel {
    fn from(chat: ChatEntity) -> Self {
        match chat.source.as_str() {
            "topic-followup" => ChatResponseModel {
                id: chat._id.to_hex(),
                question: chat.question,
                source: "Deep Dive".to_string(),
                date_created: chat.date,
                about: chat.course_name.unwrap_or_default(),
                unit_name: Some(format!("&rarr; {}", chat.unit_name.unwrap_or_default())),
                topic_name: Some(format!("&rarr; {}", chat.topic_name.unwrap_or_default())),
                explanation: serde_json::from_str::<PracticeChatSource>(chat.response.replace("\\\\", "\\").as_str()).unwrap().description,
                context: chat.context.unwrap_or_default(),
                summary: chat.summary,
                title: chat.title,
            },
            "practice" => ChatResponseModel {
                id: chat._id.to_hex(),
                question: chat.question,
                source: "Deep Dive".to_string(),
                date_created: chat.date,
                about: chat.course_name.unwrap_or_default(),
                unit_name: chat.unit_name,
                topic_name: chat.topic_name,
                explanation: serde_json::from_str::<PracticeChatSource>(chat.response.replace("\\\\", "\\").as_str()).unwrap().description,
                context: serde_json::from_str::<RecommendationChatSource>(chat.context.unwrap().replace("\\\\", "\\").as_str()).unwrap().question,
                summary: chat.summary,
                title: chat.title,
            },
            "answer-recommendations" => ChatResponseModel {
                id: chat._id.to_hex(),
                question: serde_json::from_str::<RecommendationChatSource>(chat.question.replace("\\\\", "\\").as_str()).unwrap().question,
                source: "Personalized Feedback".to_string(),
                date_created: chat.date,
                about: chat.course_name.unwrap_or_default(),
                explanation: chat.response,
                unit_name: chat.unit_name,
                topic_name: chat.topic_name,
                context: serde_json::from_str::<RecommendationChatSource>(chat.context.unwrap().replace("\\\\", "\\").as_str()).unwrap().question,
                summary: chat.summary,
                title: chat.title,
            },
            _ => ChatResponseModel::default(),
        }
    }
}

#[derive(Debug, Serialize, Deserialize, Clone)]
pub struct ChatEntity {
    pub _id: ObjectId,
    pub user_id: String,
    pub timestamp: i64,
    pub date: String,
    pub source: String,
    pub course_name: Option<String>,
    pub unit_name: Option<String>,
    pub topic_name: Option<String>,
    pub question: String,
    pub context: Option<String>,
    pub response: String,
    pub summary: Option<String>,
    pub title: Option<String>,
}

impl Default for ChatEntity {
    fn default() -> Self {
        ChatEntity {
            _id: ObjectId::new(),
            user_id: "not-set".to_string(),
            timestamp: date_ops::to_timestamp(),
            course_name: None,
            unit_name: None,
            topic_name: None,
            question: "not-set".to_string(),
            context: None,
            response: "not-set".to_string(),
            source: "not-set".to_string(),
            date: date_ops::to_display_date(date_ops::local_date_time()),
            summary: None,
            title: None,
        }
    }
}

impl ChatEntity {
    pub async fn create(
        &self,
        mongoc: &Client,
    ) -> Option<String> {
        let chats = Database::get_collection::<ChatEntity>(mongoc, "chats");
        match Database::create(&chats, self).await {
            EntityResult::Success(r) => match r {
                SuccessResultType::Created(id) => Some(id),
                _ => None,
            },
            EntityResult::Error(e) => {
                log::error!("Error saving chat: {:?}", e);
                None
            }
        }
    }

    pub async fn scan(
        &self,
        mongoc: &Client,
    ) -> Option<Vec<ChatEntity>> {
        let chats = Database::get_collection::<ChatEntity>(mongoc, "chats");
        match Database::find_all(chats).await {
            EntityResult::Success(r) => Some(r),
            EntityResult::Error(e) => {
                log::error!("Error scanning chat: {:?}", e);
                None
            }
        }
    }

    pub async fn find(
        &self,
        mongoc: &Client,
    ) -> Option<ChatEntity> {
        let chats = Database::get_collection::<ChatEntity>(mongoc, "chats");
        match Database::find(chats, &self._id.to_hex()).await {
            EntityResult::Success(c) => Some(c),
            EntityResult::Error(_) => {
                log::debug!("No chat found for id: {}", self._id.to_hex());
                None
            }
        }
    }

    pub async fn filter(
        &self,
        mongoc: &Client,
    ) -> Option<Vec<ChatEntity>> {
        let chats = Database::get_collection::<ChatEntity>(mongoc, "chats");
        match Database::filter_by(chats, doc! {"user_id": self.user_id.clone()}).await {
            Some(r) => Some(r),
            None => {
                log::debug!("No chats found for user: {}", self.user_id);
                None
            }
        }
    }
}
