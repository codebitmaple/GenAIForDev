use completion_request::{Message, ResponseFormat};
use serde::{Deserialize, Serialize};

pub mod chat;
pub mod completion_request;
pub mod completion_response;
pub mod course_info;
pub mod user_info;

#[derive(Serialize, Deserialize, Debug, Clone)]
pub struct PostChatCompletionRequest {
    pub messages: Vec<Message>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub response_format: Option<ResponseFormat>,
}
