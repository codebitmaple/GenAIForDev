use serde::{Deserialize, Serialize};

#[derive(Serialize, Deserialize, Debug)]
pub struct DescribeCourseRequest {
    pub course_name: String,
    pub user_type: String,
    pub user_level: String,
    pub followup: Option<String>,
}
