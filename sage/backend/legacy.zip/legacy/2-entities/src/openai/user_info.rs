use serde::{Deserialize, Serialize};

#[derive(Serialize, Deserialize, Debug)]
pub enum UserType {
    Unknown = -1,
    Student = 0,
    Professional = 1,
}

impl UserType {
    pub fn to_str(user_type: &str) -> String {
        match user_type {
            "0" => "High School Student".to_string(),
            "1" => "Software Engineering Professional".to_string(),
            _ => "Unknown".to_string(),
        }
    }
}

#[derive(Serialize, Deserialize, Debug)]
pub enum UserLevel {
    Unknown = -1,
    Beginner = 0,
    Intermediate = 1,
    Advanced = 2,
    Expert = 3,
}

impl UserLevel {
    pub fn to_str(user_level: &str) -> String {
        match user_level {
            "0" => "Beginner".to_string(),
            "1" => "Intermediate".to_string(),
            "2" => "Advanced".to_string(),
            "3" => "Expert".to_string(),
            _ => "Unknown".to_string(),
        }
    }
}
