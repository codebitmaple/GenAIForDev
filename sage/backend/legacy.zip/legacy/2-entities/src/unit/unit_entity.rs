use aarya_utils::{
    cache_ops,
    db_ops::Database,
    result_types::{EntityResult, SuccessResultType},
};
use log::error;
use mongodb::{
    bson::{doc, oid::ObjectId},
    Client,
};
use schemars::JsonSchema;
use serde::{Deserialize, Serialize};

use crate::key_value::KeyValues;

const UNIT_COLLECTION: &str = "units";
const UNIT_CACHE_KEY: &str = "all_units";

#[derive(Debug, Serialize, Deserialize, Clone)]
pub struct UnitEntity {
    pub _id: ObjectId,
    pub name: String,
    pub name_hash: String,
    pub slug: String,
    pub description: String,
    pub creator_id: String,
    pub created_at: i64,
    pub updated_at: i64,
    pub course_id: String,
    pub metadata: Vec<KeyValues>,
    pub unit_number: u32,
}

impl Default for UnitEntity {
    fn default() -> Self {
        UnitEntity {
            _id: ObjectId::new(),
            name: String::from("not-set"),
            description: String::from("not-set"),
            creator_id: String::from("not-set"),
            created_at: 0,
            updated_at: 0,
            course_id: String::from("not-set"),
            name_hash: String::from("not-set"),
            slug: String::from("not-set"),
            metadata: vec![],
            unit_number: 0,
        }
    }
}

impl UnitEntity {
    pub async fn create(
        &self,
        mongoc: &Client,
        cache: &cache_ops::Cache,
    ) -> Option<String> {
        cache.remove(UNIT_CACHE_KEY);
        let units = Database::get_collection::<UnitEntity>(mongoc, UNIT_COLLECTION);
        let filter = doc! { "name_hash": &self.name_hash };
        match units.find_one(filter, None).await {
            Ok(Some(u)) => {
                println!("Unit with the same name_hash already exists, skipping insertion.");
                Some(u._id.to_hex())
            }
            Ok(None) => match Database::create(&units, self).await {
                EntityResult::Success(r) => match r {
                    SuccessResultType::Created(id) => Some(id),
                    _ => None,
                },
                EntityResult::Error(_) => {
                    error!("Error creating unit entity {:?}", self);
                    None
                }
            },
            Err(e) => {
                error!("Error querying unit collection: {:?}", e);
                None
            }
        }
    }

    pub async fn create_force(
        &self,
        mongoc: &Client,
        cache: &cache_ops::Cache,
    ) -> Option<String> {
        cache.remove(UNIT_CACHE_KEY);
        let units = Database::get_collection::<UnitEntity>(mongoc, UNIT_COLLECTION);
        match Database::create(&units, self).await {
            EntityResult::Success(r) => match r {
                SuccessResultType::Created(id) => Some(id),
                _ => None,
            },
            EntityResult::Error(_) => {
                error!("Error creating unit entity {:?}", self);
                None
            }
        }
    }

    pub async fn scan(
        mongoc: &Client,
        cache: &cache_ops::Cache,
    ) -> Option<Vec<UnitEntity>> {
        let cached_units: Option<Vec<UnitEntity>> = cache.get_json(UNIT_CACHE_KEY);
        if cached_units.is_some() {
            return cached_units;
        }
        let unit_collection = Database::get_collection::<UnitEntity>(mongoc, UNIT_COLLECTION);
        let units = match Database::find_all(unit_collection).await {
            EntityResult::Success(r) => r,
            EntityResult::Error(e) => {
                error!("Error scanning unit collection {:?}", e);
                return None;
            }
        };
        let _ = cache.set_json(UNIT_CACHE_KEY, &units);
        Some(units)
    }

    pub async fn find_by_course(
        mongoc: &Client,
        cache: &cache_ops::Cache,
        id: &String,
    ) -> Option<Vec<UnitEntity>> {
        let units = Self::scan(mongoc, cache).await.unwrap();
        let mut found_units: Vec<UnitEntity> = vec![];
        for unit in units {
            if unit.course_id == *id {
                found_units.push(unit);
            }
        }
        Some(found_units)
    }

    pub async fn find_by_slug(
        mongoc: &Client,
        cache: &cache_ops::Cache,
        slug: String,
    ) -> Option<UnitEntity> {
        let units = Self::scan(mongoc, cache).await.unwrap();
        for unit in units {
            if unit.slug == slug {
                return Some(unit);
            }
        }
        None
    }

    pub async fn find_by_slug_course(
        mongoc: &Client,
        cache: &cache_ops::Cache,
        slug: &str,
        course_id: &str,
    ) -> Option<Vec<UnitEntity>> {
        let units = Self::scan(mongoc, cache).await.unwrap();
        let mut found_units: Vec<UnitEntity> = vec![];
        for unit in units {
            if unit.slug == slug && unit.course_id == course_id {
                found_units.push(unit);
            }
        }
        if found_units.is_empty() {
            None
        } else {
            Some(found_units)
        }
    }

    pub async fn find_by_id(
        mongoc: &Client,
        cache: &cache_ops::Cache,
        id: String,
    ) -> Option<UnitEntity> {
        let units = Self::scan(mongoc, cache).await.unwrap();
        for unit in units {
            if unit._id.to_hex() == id {
                return Some(unit);
            }
        }
        None
    }

    pub async fn update(
        &self,
        mongoc: &Client,
        cache: &cache_ops::Cache,
    ) -> Option<String> {
        cache.remove(UNIT_CACHE_KEY);
        let units = Database::get_collection::<UnitEntity>(mongoc, UNIT_COLLECTION);
        match Database::update(&units, self, &self._id.to_hex()).await {
            EntityResult::Success(r) => match r {
                SuccessResultType::Updated(id) => Some(id),
                _ => None,
            },
            EntityResult::Error(e) => {
                log::error!("Error updating unit: {:?}", e);
                None
            }
        }
    }
}

#[derive(Debug, Serialize, Deserialize, JsonSchema)]
pub struct UnitUploadModel {
    #[schemars(length(min = 1, max = 64))]
    pub name: String,
    #[schemars(length(min = 64, max = 156))]
    pub description: String,
    #[schemars(length(min = 4, max = 64))]
    pub slug: String,
    #[schemars(length(min = 1, max = 16))]
    pub metadata: Vec<KeyValues>,
    #[schemars(range(min = 1, max = 256))]
    pub unit_number: u32,
}
