use crate::{
    instructor::entity::InstructorEntity,
    pricing::{pricing_category::PricingCategory, pricing_info::PricingInfo, pricing_type::PricingType},
    user::UserEntity,
};
use aarya_utils::{
    date_ops,
    db_ops::Database,
    result_types::{EntityResult, SuccessResultType},
};
use chrono::{Datelike, Local, NaiveDateTime, TimeZone, Timelike, Utc};
use log::{debug, error, info};
use mongodb::{bson::doc, Collection};
use mongodb::{bson::oid::ObjectId, Client};
use serde::{Deserialize, Serialize};

#[derive(Serialize, Deserialize, Debug, Clone)]
pub enum BookingStatus {
    Init,
    Details,
    Appointment,
    Checkout,
    Paid,
    Rescheduled,
    Canceled,
    Completed,
    FeedbackProvided,
}

#[derive(Serialize, Deserialize, Debug, Clone)]
pub struct DateTime {
    pub date: String,
    pub time: String,
}

impl DateTime {
    pub fn format(&self) -> String {
        // Combine date and time into a single string
        let datetime_str = format!("{}T{}", self.date, self.time);

        // Parse the combined date and time string into NaiveDateTime
        let naive_datetime = match NaiveDateTime::parse_from_str(&datetime_str, "%Y-%m-%dT%H:%M:%S") {
            Ok(dt) => dt,
            Err(_) => return "Invalid date or time format".to_string(), // Handle parsing error
        };

        // Convert the NaiveDateTime into a Local DateTime for formatting
        let local_datetime = match Local.from_local_datetime(&naive_datetime) {
            chrono::LocalResult::Single(ldt) => ldt,
            _ => return "Invalid date conversion".to_string(), // Handle invalid date conversion
        };

        // Extract components and format them as required
        let day_of_week = local_datetime.format("%A").to_string(); // Full weekday name (e.g., "Tuesday")
        let month = local_datetime.format("%B").to_string(); // Full month name (e.g., "October")
        let day = local_datetime.day(); // Day of the month (e.g., 9)

        let mut hour = local_datetime.hour();
        let am_pm = if hour >= 12 {
            if hour > 12 {
                hour -= 12;
            }
            "pm"
        } else {
            if hour == 0 {
                hour = 12;
            }
            "am"
        };

        // Format the final output
        format!("{}, {} {} at {}{}", day_of_week, month, day, hour, am_pm)
    }
}

#[derive(Serialize, Deserialize, Debug, Clone)]
pub struct Appointment {
    pub time_slots: Vec<DateTime>,
}

impl Appointment {
    pub fn format_time_slots(&self) -> Vec<String> {
        self.time_slots.iter().map(|slot| slot.format()).collect()
    }

    pub fn to_formatted_string(&self) -> String {
        self.format_time_slots().join(", ")
    }
}

#[derive(Serialize, Deserialize, Debug, Clone)]
pub struct BookingEntity {
    pub _id: Option<ObjectId>,
    pub student_id: String,
    pub instructor_id: String,
    pub payment: Option<PaymentDetails>,
    pub appointment: Option<Appointment>,
    pub details: Option<BookingDetails>,
    pub timestamp: i64,
    pub status: BookingStatus,
}

#[derive(Serialize, Deserialize, Debug, Clone)]
pub struct PaymentDetails {
    pub amount: f64,
    pub currency: String,
    pub status: String,
    pub payment_id: String,
}

#[derive(Serialize, Deserialize, Debug, Clone)]
pub struct DateTimeSlot {
    pub date: String,
    pub time: String,
}

impl DateTimeSlot {
    pub fn format_time(&self) -> Option<String> {
        Some(date_ops::format_time(&self.time))
    }

    pub fn format_date(&self) -> Option<String> {
        Some(date_ops::format_date(&self.date, None, None))
    }
}

#[derive(Serialize, Deserialize, Debug, Clone)]
pub enum BookingType {
    Mentoring,
    Tutoring,
    Interviewing,
    Unknown,
}

impl BookingType {
    pub fn to_text(&self) -> String {
        match self {
            BookingType::Mentoring => "Mentoring".to_string(),
            BookingType::Tutoring => "Tutoring".to_string(),
            BookingType::Interviewing => "Interviewing".to_string(),
            BookingType::Unknown => "Unknown".to_string(),
        }
    }
}

#[derive(Serialize, Deserialize, Debug, Clone)]
pub struct BookingDetails {
    pub booking_type: BookingType,
    pub topic: String,
    pub summary: String,
}

impl Default for BookingEntity {
    fn default() -> Self {
        BookingEntity {
            _id: Some(ObjectId::new()),
            student_id: String::new(),
            instructor_id: String::new(),
            payment: None,
            appointment: None,
            details: None,
            timestamp: Utc::now().timestamp(),
            status: BookingStatus::Init,
        }
    }
}

impl BookingEntity {
    pub async fn add_new(
        &self,
        mongoc: &mongodb::Client,
    ) -> Option<BookingEntity> {
        debug!("New booking: {:?}", self);

        let collection = BookingEntity::get_collection(mongoc);
        match Database::create(&collection, self).await {
            EntityResult::Success(r) => {
                info!("Booking created {:?}", r);
                match r {
                    SuccessResultType::Created(_) => Some(self.to_owned()),
                    _ => None,
                }
            }
            EntityResult::Error(e) => {
                error!("Failed to create new booking: {:?}", e);
                None
            }
        }
    }

    pub fn get_pricing_info(
        &self,
        source: &str,
    ) -> Option<PricingInfo> {
        let mut pricing_info = PricingInfo::default();
        let pricing_type = match self.details.clone() {
            Some(details) => match details.booking_type {
                BookingType::Mentoring => Some(PricingType::Professional),
                BookingType::Tutoring => Some(PricingType::Student),
                BookingType::Interviewing => Some(PricingType::Professional),
                BookingType::Unknown => Some(PricingType::Unknown),
            },
            None => Some(PricingType::Unknown),
        };
        let pricing_category = match source {
            "instructor-bio" => Some(PricingCategory::HumanOneOnOne),
            "blog-post" => Some(PricingCategory::HumanOneOnOne),
            _ => Some(PricingCategory::Unknown),
        };

        pricing_info.set_pricing_type(pricing_type.unwrap());
        pricing_info.set_pricing_category(pricing_category.unwrap());

        Some(pricing_info)
    }

    pub async fn set_status(
        &self,
        mongoc: &mongodb::Client,
        status: &BookingStatus,
    ) -> Option<BookingEntity> {
        let bookings = BookingEntity::get_collection(mongoc);
        let updated_booking = BookingEntity {
            status: status.clone(),
            ..self.clone()
        };
        match Database::update(&bookings, &updated_booking, &ObjectId::to_hex(self._id.unwrap())).await {
            EntityResult::Success(_) => Some(updated_booking),
            EntityResult::Error(e) => {
                error!("Failed to update booking: {:?}", e);
                None
            }
        }
    }

    pub fn get_collection(mongoc: &mongodb::Client) -> Collection<BookingEntity> {
        Database::get_collection::<BookingEntity>(mongoc, "bookings")
    }

    pub async fn get_student(
        &self,
        mongoc: &Client,
    ) -> Option<UserEntity> {
        UserEntity::find(mongoc, &self.student_id).await
    }

    pub async fn get_instructor(
        &self,
        mongoc: &Client,
    ) -> Option<InstructorEntity> {
        InstructorEntity::find(mongoc, &self.instructor_id).await
    }

    pub fn get_id(&self) -> String {
        ObjectId::to_hex(self._id.unwrap())
    }
}
