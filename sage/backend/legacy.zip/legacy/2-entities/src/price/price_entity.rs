use aarya_utils::{
    db_ops::Database,
    result_types::{EntityResult, SuccessResultType},
};
use mongodb::{bson::oid::ObjectId, Client};
use serde::{Deserialize, Serialize};

use crate::product::product_entity::ProductEntity;

#[derive(Debug, Serialize, Deserialize, Clone)]
pub struct PriceEntity {
    pub _id: ObjectId,
    pub stripe_id: Option<String>,
    pub unit_amount_cents: i64,
    pub currency: String,
    pub active: bool,
    pub livemode: bool,
    pub created: i64,
    pub updated: i64,
    pub product_id: String,
    pub product: ProductEntity,
}

impl Default for PriceEntity {
    fn default() -> Self {
        PriceEntity {
            _id: ObjectId::new(),
            stripe_id: None,
            unit_amount_cents: 0,
            currency: String::from("not-set"),
            active: false,
            livemode: false,
            created: 0,
            updated: 0,
            product_id: String::from("not-set"),
            product: ProductEntity::default(),
        }
    }
}

impl PriceEntity {
    pub async fn create(
        &self,
        mongoc: &Client,
    ) -> Option<String> {
        let prices = Database::get_collection::<PriceEntity>(mongoc, "prices");
        match Database::create(&prices, self).await {
            EntityResult::Success(SuccessResultType::Created(id)) => Some(id),
            _ => None,
        }
    }
}
