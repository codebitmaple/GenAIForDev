use aarya_utils::{
    db_ops::Database,
    result_types::{DatabaseErrorType, EntityResult, SuccessResultType},
};
use mongodb::{bson::oid::ObjectId, Client};
use serde::{Deserialize, Serialize};

#[derive(Debug, Serialize, Deserialize, Clone)]
pub enum PaymentStatus {
    Unknown,
    Initiated,
    Cancelled,
    Completed,
    Failed,
}

#[derive(Debug, Serialize, Deserialize, Clone)]
pub struct PaymentEntity {
    pub _id: ObjectId,
    pub booking_id: String,
    pub amount: f32,
    pub currency: String,
    pub status: PaymentStatus,
    pub timestamp: i64,
    pub livemode: Option<bool>,
    pub stripe_checkout_id: Option<String>,
}

impl Default for PaymentEntity {
    fn default() -> Self {
        PaymentEntity {
            _id: ObjectId::new(),
            booking_id: String::from("not-set"),
            amount: 0.0,
            currency: String::from("not-set"),
            status: PaymentStatus::Unknown,
            livemode: None,
            timestamp: 0,
            stripe_checkout_id: String::from("not-set").into(),
        }
    }
}

impl PaymentEntity {
    pub async fn update_status(
        mongoc: &Client,
        status: PaymentStatus,
        booking_id: &String,
    ) -> EntityResult<SuccessResultType> {
        let payment = match Self::find_by(mongoc, booking_id).await {
            EntityResult::Success(r) => r,
            EntityResult::Error(e) => {
                return EntityResult::Error(DatabaseErrorType::NotFound(String::from("PaymentEntity"), format!("booking_id: {}, error: {:?}", booking_id, e)));
            }
        };

        let updated_payment = PaymentEntity { status, ..payment };

        match updated_payment.upsert(mongoc).await {
            EntityResult::Success(_) => EntityResult::Success(SuccessResultType::Updated(updated_payment._id.to_hex())),
            EntityResult::Error(e) => EntityResult::Error(DatabaseErrorType::MutationError(String::from("PaymentEntity"), format!("booking_id: {}, error: {:?}", booking_id, e))),
        }
    }

    pub async fn find_by(
        mongoc: &Client,
        booking_id: &String,
    ) -> EntityResult<PaymentEntity> {
        let collection = Database::get_collection::<PaymentEntity>(mongoc, "payments");
        match Database::find_by(&collection, String::from("booking_id"), booking_id).await {
            EntityResult::Success(r) => EntityResult::Success(r),
            EntityResult::Error(e) => EntityResult::Error(e),
        }
    }

    pub async fn upsert(
        &self,
        mongoc: &Client,
    ) -> EntityResult<SuccessResultType> {
        let collection = Database::get_collection::<PaymentEntity>(mongoc, "payments");

        match Database::find_by(&collection, String::from("booking_id"), &self.booking_id).await {
            EntityResult::Success(r) => match Database::update_with(&collection, self, &r._id).await {
                EntityResult::Success(_) => EntityResult::Success(SuccessResultType::Updated(r._id.to_hex())),
                EntityResult::Error(e) => EntityResult::Error(e),
            },
            EntityResult::Error(e) => match e {
                DatabaseErrorType::NotFound(_, _) => match Database::create(&collection, self).await {
                    EntityResult::Success(_) => EntityResult::Success(SuccessResultType::Created(self._id.to_hex())),
                    EntityResult::Error(e) => EntityResult::Error(e),
                },
                _ => EntityResult::Error(e),
            },
        }
    }
}
