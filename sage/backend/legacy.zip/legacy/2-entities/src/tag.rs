use mongodb::bson::oid::ObjectId;
use serde::{Deserialize, Serialize};

#[derive(Debug, Serialize, Deserialize, Clone)]
pub struct TagEntity {
    #[serde(skip_serializing_if = "Option::is_none")]
    pub _id: Option<ObjectId>,
    pub name: String,
    pub description: String,
}

impl TagEntity {
    pub fn new() -> Self {
        TagEntity {
            _id: None,
            name: "not-set".to_string(),
            description: "not-set".to_string(),
        }
    }
}

impl Default for TagEntity {
    fn default() -> Self {
        Self::new()
    }
}
