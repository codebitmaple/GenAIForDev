use serde::{Deserialize, Serialize};

#[derive(Serialize, Deserialize, Debug, Clone)]
pub struct StripePricingRequest {
    // Stripe Product ID
    pub product_id: String,
    pub currency: String,
    pub unit_amount: i64,
}
