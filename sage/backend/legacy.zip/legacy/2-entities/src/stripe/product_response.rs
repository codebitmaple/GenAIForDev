use serde::{Deserialize, Serialize};

#[derive(Serialize, Deserialize, Debug, Clone)]
pub struct StripeProductResponse {
    pub id: String,
}

impl Default for StripeProductResponse {
    fn default() -> Self {
        StripeProductResponse { id: String::from("not-set") }
    }
}
