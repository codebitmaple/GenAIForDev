use serde::{Deserialize, Serialize};

#[derive(Serialize, Deserialize, Debug, Clone)]
pub struct StripePricingResponse {
    pub id: String,
    pub currency: String,
    pub unit_amount: i64,
    pub created: i64,
    pub livemode: bool,
}

impl Default for StripePricingResponse {
    fn default() -> Self {
        StripePricingResponse {
            id: String::from("not-set"),
            currency: String::from("not-set"),
            unit_amount: 0,
            created: 0,
            livemode: false,
        }
    }
}
