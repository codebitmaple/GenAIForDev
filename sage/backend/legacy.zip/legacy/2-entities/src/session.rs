use serde::{Deserialize, Serialize};

#[derive(Serialize, Deserialize, Debug, Clone)]
pub struct SessionModel {
    pub with_field: String,
    pub on_field: Vec<String>,
    pub for_field: String,
    pub about_field: String,
    pub actions: Vec<(String, String)>,
}
