use aarya_utils::{
    date_ops,
    db_ops::Database,
    result_types::{EntityResult, SuccessResultType},
};
use log::error;
use mongodb::bson::{doc, oid::ObjectId, Document};
use serde::{Deserialize, Serialize};

use crate::{question::question_entity::QuestionEntity, AnswerRequestModel, QuestionResponseModel};

#[derive(Serialize, Deserialize, Debug, Clone)]
pub struct ExerciseRequestModel {
    pub course_id: String,
    pub unit_id: String,
    pub topic_id: String,
    pub question_count: usize,
}

#[derive(Serialize, Deserialize, Debug, Clone)]
pub struct ExerciseResponseModel {
    pub exercise_id: String,
    pub questions: Vec<QuestionResponseModel>,
}

#[derive(Serialize, Deserialize, Debug, Clone)]
pub struct ExerciseEntity {
    pub _id: ObjectId,
    pub questions: Vec<QuestionEntity>,
    pub user_answers: Option<AnswerRequestModel>,
    pub analysis: Option<String>,
    pub score: Option<f32>,
    pub user_id: String,
    pub course_id: String,
    pub unit_id: String,
    pub topic_id: String,
    pub timestamp: i64,
    pub followups: Option<Vec<String>>,
}

impl Default for ExerciseEntity {
    fn default() -> Self {
        ExerciseEntity {
            _id: ObjectId::new(),
            questions: vec![],
            user_answers: None,
            analysis: None,
            score: None,
            user_id: "not-set".to_string(),
            course_id: "not-set".to_string(),
            unit_id: "not-set".to_string(),
            topic_id: "not-set".to_string(),
            timestamp: date_ops::to_timestamp(),
            followups: None,
        }
    }
}

impl ExerciseEntity {
    pub async fn create(
        &self,
        mongoc: &mongodb::Client,
    ) -> Option<String> {
        let exercises = Database::get_collection::<ExerciseEntity>(mongoc, "exercises");
        match Database::create(&exercises, self).await {
            EntityResult::Success(r) => match r {
                SuccessResultType::Created(id) => Some(id),
                _ => None,
            },
            EntityResult::Error(_) => {
                error!("Error creating exercise entity {:?}", self);
                None
            }
        }
    }

    pub async fn filter(
        mongoc: &mongodb::Client,
        filter: Document,
    ) -> Option<Vec<ExerciseEntity>> {
        let exercises = Database::get_collection::<ExerciseEntity>(mongoc, "exercises");
        Database::filter_by(exercises, filter).await
    }

    pub async fn update(
        &self,
        mongoc: &mongodb::Client,
    ) -> Option<String> {
        let exercises = Database::get_collection::<ExerciseEntity>(mongoc, "exercises");
        let filter = doc! { "_id": &self._id };
        match Database::update_by(&exercises, self, filter).await {
            EntityResult::Success(r) => match r {
                SuccessResultType::Updated(id) => Some(id),
                _ => None,
            },
            EntityResult::Error(_) => {
                error!("Error updating exercise entity {:?}", self);
                None
            }
        }
    }

    pub async fn find(
        &self,
        mongoc: &mongodb::Client,
    ) -> Option<ExerciseEntity> {
        let exercises = Database::get_collection::<ExerciseEntity>(mongoc, "exercises");
        match Database::find(exercises, &self._id.to_hex()).await {
            EntityResult::Success(r) => Some(r),
            EntityResult::Error(_) => {
                error!("Error finding exercise entity with id: {}", self._id.to_hex());
                None
            }
        }
    }
}
