use aarya_utils::{
    cache_ops,
    db_ops::Database,
    result_types::{EntityResult, SuccessResultType},
};
use log::error;
use mongodb::{
    bson::{doc, oid::ObjectId},
    Client,
};
use schemars::JsonSchema;
use serde::{Deserialize, Serialize};

const TOPIC_COLLECTION: &str = "topics";
const TOPIC_CACHE_KEY: &str = "all_topics";

#[derive(Debug, Serialize, Deserialize, Clone)]
pub struct TopicResponseModel {
    pub id: String,
    pub name: String,
    pub description: String,
    pub slug: Option<String>,
}

impl From<TopicEntity> for TopicResponseModel {
    fn from(entity: TopicEntity) -> Self {
        TopicResponseModel {
            id: entity._id.to_hex(),
            name: entity.name,
            description: entity.meta_description,
            slug: Some(entity.slug),
        }
    }
}

impl TopicResponseModel {
    pub fn from_topics(topics: Vec<TopicEntity>) -> Vec<TopicResponseModel> {
        topics.into_iter().map(TopicResponseModel::from).collect()
    }
}

#[derive(Debug, Serialize, Deserialize, JsonSchema)]
pub struct TopicEditModel {
    pub name: String,
    pub meta_description: String,
    pub markdown: String,
    pub tags: Vec<String>,
    pub scope: TopicScope,
    pub slug: String,
    pub topic_number: u32,
    pub summary: String,
    pub created_at: i64,
}

impl From<TopicEntity> for TopicEditModel {
    fn from(entity: TopicEntity) -> Self {
        TopicEditModel {
            name: entity.name,
            meta_description: entity.meta_description,
            markdown: entity.markdown,
            tags: entity.tags,
            scope: entity.scope,
            slug: entity.slug,
            // metadata: entity.metadata.unwrap_or_default(),
            topic_number: entity.topic_number,
            summary: entity.summary.unwrap_or_default(),
            created_at: entity.created_at,
        }
    }
}

#[derive(Debug, Serialize, Deserialize, Clone, JsonSchema)]
pub enum TopicScope {
    Public,
    Authenticated,
    Paid,
    Restricted,
    Hidden,
}

impl TopicScope {
    pub fn all() -> Vec<TopicScope> {
        vec![TopicScope::Public, TopicScope::Authenticated, TopicScope::Paid, TopicScope::Restricted, TopicScope::Hidden]
    }
}

#[derive(Debug, Serialize, Deserialize, Clone)]
pub struct TopicEntity {
    pub _id: ObjectId,
    pub name: String,
    pub name_hash: String,
    pub summary: Option<String>,
    pub slug: String,
    pub meta_description: String,
    pub markdown: String,
    pub creator_id: String,
    pub created_at: i64,
    pub updated_at: i64,
    pub unit_id: String,
    pub tags: Vec<String>,
    pub scope: TopicScope,
    // pub metadata: Option<Vec<KeyComplexValue>>,
    pub topic_number: u32,
}

impl Default for TopicEntity {
    fn default() -> Self {
        TopicEntity {
            _id: ObjectId::new(),
            meta_description: "not-set".to_string(),
            name: "not-set".to_string(),
            name_hash: "not-set".to_string(),
            markdown: "not-set".to_string(),
            creator_id: "not-set".to_string(),
            created_at: 0,
            updated_at: 0,
            unit_id: "not-set".to_string(),
            tags: vec![],
            scope: TopicScope::Public,
            slug: String::from("not-set"),
            // metadata: Some(vec![]),
            topic_number: 0,
            summary: Some(String::from("not-set")),
        }
    }
}

impl TopicEntity {
    pub async fn create(
        &self,
        mongoc: &mongodb::Client,
        cache: &cache_ops::Cache,
    ) -> Option<String> {
        cache.remove(TOPIC_CACHE_KEY);
        let topics = Database::get_collection::<TopicEntity>(mongoc, TOPIC_COLLECTION);
        let filter = doc! { "name_hash": &self.name_hash };
        match topics.find_one(filter, None).await {
            Ok(Some(t)) => {
                println!("Topic with the same name_hash already exists, skipping insertion.");
                Some(t._id.to_hex())
            }
            Ok(None) => match Database::create(&topics, self).await {
                EntityResult::Success(r) => match r {
                    SuccessResultType::Created(id) => Some(id),
                    _ => None,
                },
                EntityResult::Error(_) => {
                    error!("Error creating unit entity {:?}", self);
                    None
                }
            },
            Err(e) => {
                error!("Error querying unit collection: {:?}", e);
                None
            }
        }
    }

    pub async fn create_force(
        &self,
        mongoc: &mongodb::Client,
        cache: &cache_ops::Cache,
    ) -> Option<String> {
        cache.remove(TOPIC_CACHE_KEY);
        let topics = Database::get_collection::<TopicEntity>(mongoc, TOPIC_COLLECTION);
        match Database::create(&topics, self).await {
            EntityResult::Success(r) => match r {
                SuccessResultType::Created(id) => Some(id),
                _ => None,
            },
            EntityResult::Error(_) => {
                error!("Error creating unit entity {:?}", self);
                None
            }
        }
    }

    pub async fn scan(
        mongoc: &mongodb::Client,
        cache: &cache_ops::Cache,
    ) -> Option<Vec<TopicEntity>> {
        let cached_topics: Option<Vec<TopicEntity>> = cache.get_json(TOPIC_CACHE_KEY);
        if cached_topics.is_some() {
            return cached_topics;
        }
        let topic_collection = Database::get_collection::<TopicEntity>(mongoc, TOPIC_COLLECTION);
        let topics = match Database::find_all(topic_collection).await {
            EntityResult::Success(r) => Some(r),
            EntityResult::Error(e) => {
                log::error!("Error scanning topics: {:?}", e);
                None
            }
        };
        if topics.is_some() {
            let topics = topics.unwrap();
            let _ = cache.set_json(TOPIC_CACHE_KEY, &topics);
            Some(topics)
        } else {
            None
        }
    }

    pub async fn find_by_unit(
        mongoc: &Client,
        cache: &cache_ops::Cache,
        id: &String,
    ) -> Option<Vec<TopicEntity>> {
        let topics = Self::scan(mongoc, cache).await.unwrap();
        let mut unit_topics = vec![];
        for topic in topics {
            if topic.unit_id == *id {
                unit_topics.push(topic);
            }
        }
        if unit_topics.is_empty() {
            None
        } else {
            Some(unit_topics)
        }
    }

    pub async fn find_by_slug(
        mongoc: &Client,
        cache: &cache_ops::Cache,
        slug: String,
    ) -> Option<TopicEntity> {
        let topics = Self::scan(mongoc, cache).await.unwrap();
        for topic in topics {
            if topic.slug == slug {
                return Some(topic);
            }
        }
        None
    }

    pub async fn find_by_slug_unit(
        mongoc: &Client,
        cache: &cache_ops::Cache,
        slug: &str,
        unit_id: &str,
    ) -> Option<Vec<TopicEntity>> {
        let topics = Self::scan(mongoc, cache).await.unwrap();
        let mut found_topics: Vec<TopicEntity> = vec![];
        for topic in topics {
            if topic.slug == slug && topic.unit_id == unit_id {
                found_topics.push(topic);
            }
        }
        if found_topics.is_empty() {
            return None;
        }
        Some(found_topics)
    }

    pub async fn find_by_id(
        mongoc: &Client,
        cache: &cache_ops::Cache,
        id: String,
    ) -> Option<TopicEntity> {
        let topics = Self::scan(mongoc, cache).await.unwrap();
        for topic in topics {
            if topic._id.to_hex() == id {
                return Some(topic);
            }
        }
        None
    }

    pub async fn update(
        &self,
        mongoc: &Client,
        cache: &cache_ops::Cache,
    ) -> Option<String> {
        cache.remove(TOPIC_CACHE_KEY);
        let topics = Database::get_collection::<TopicEntity>(mongoc, TOPIC_COLLECTION);
        match Database::update(&topics, self, &self._id.to_hex()).await {
            EntityResult::Success(r) => match r {
                SuccessResultType::Updated(id) => Some(id),
                _ => None,
            },
            EntityResult::Error(e) => {
                log::error!("Error updating topic: {:?}", e);
                None
            }
        }
    }
}

#[derive(Debug, Serialize, Deserialize, JsonSchema)]
pub struct TopicCreateModel {
    #[schemars(length(min = 1, max = 64))]
    pub name: String,
    #[schemars(length(min = 64, max = 156))]
    pub meta_description: String,
    #[schemars(length(min = 1024, max = 10192))]
    pub markdown: String,
    #[schemars(length(min = 1, max = 8))]
    pub tags: Vec<String>,
    pub scope: TopicScope,
    #[schemars(length(min = 4, max = 64))]
    pub slug: String,
    // #[schemars(length(min = 1, max = 16))]
    // pub metadata: Vec<KeyComplexValue>,
    #[schemars(range(min = 1, max = 256))]
    pub topic_number: u32,
    #[schemars(length(min = 256, max = 1024))]
    pub summary: String,
}
