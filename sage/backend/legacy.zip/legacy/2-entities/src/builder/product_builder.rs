use aarya_utils::date_ops;
use mongodb::bson::oid::ObjectId;

use crate::product::{
    product_entity::{Cadence, DeliveryMethod, ProductEntity, PurchaseType},
    product_metadata::ProductMetadata,
    product_type::ProductType,
};

pub struct ProductBuilder {
    product: ProductEntity,
}

impl Default for ProductBuilder {
    fn default() -> Self {
        Self::new()
    }
}

impl ProductBuilder {
    pub fn new() -> Self {
        ProductBuilder {
            product: ProductEntity {
                _id: ObjectId::new(),
                stripe_id: None,
                display_name: String::new(),
                nickname: String::new(),
                description: String::new(),
                metadata: ProductMetadata {
                    method: DeliveryMethod::SelfService,
                    cadence: Cadence::Monthly,
                    billing_type: PurchaseType::Fixed,
                    billing_period: None,
                    session_count: None,
                    seat_count: None,
                },
                created: date_ops::to_timestamp(),
                updated: date_ops::to_timestamp(),
                active: true,
                livemode: false,
                course_description: String::new(),
                product_type: ProductType::Unknown,
                course_id: String::from("not-set"),
            },
        }
    }

    pub fn with_display_name(
        mut self,
        display_name: &str,
    ) -> Self {
        self.product.display_name = display_name.to_string();
        self
    }

    pub fn with_method(
        mut self,
        method: DeliveryMethod,
    ) -> Self {
        self.product.metadata.method = method;
        self
    }

    pub fn with_cadence(
        mut self,
        cadence: Cadence,
    ) -> Self {
        self.product.metadata.cadence = cadence;
        self
    }

    pub fn with_billing_type(
        mut self,
        billing_type: PurchaseType,
    ) -> Self {
        self.product.metadata.billing_type = billing_type;
        self
    }

    pub fn with_course_description(
        mut self,
        course_description: String,
    ) -> Self {
        self.product.course_description = course_description;
        self
    }

    pub fn with_product_type(
        mut self,
        product_type: ProductType,
    ) -> Self {
        self.product.product_type = product_type;
        self
    }

    pub fn build(self) -> ProductEntity {
        self.product
    }
}
