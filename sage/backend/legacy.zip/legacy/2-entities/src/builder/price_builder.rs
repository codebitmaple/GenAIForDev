use aarya_utils::date_ops;
use mongodb::bson::oid::ObjectId;

use crate::{price::price_entity::PriceEntity, product::product_entity::ProductEntity};

pub struct PriceBuilder {
    price: PriceEntity,
}

impl PriceBuilder {
    pub fn new(product: ProductEntity) -> Self {
        PriceBuilder {
            price: PriceEntity {
                _id: ObjectId::new(),
                stripe_id: None,
                currency: "USD".to_string(),
                active: true,
                livemode: false,
                created: date_ops::to_timestamp(),
                updated: date_ops::to_timestamp(),
                product: product.clone(),
                product_id: product._id.to_hex(),
                unit_amount_cents: 0,
            },
        }
    }

    pub fn with_amount_cents(
        mut self,
        amount: i64,
    ) -> Self {
        self.price.unit_amount_cents = amount;
        self
    }

    pub fn with_billing_period(
        mut self,
        period: Option<String>,
    ) -> Self {
        self.price.product.metadata.billing_period = period;
        self
    }

    pub fn with_session_count(
        mut self,
        count: Option<u32>,
    ) -> Self {
        self.price.product.metadata.session_count = count;
        self
    }

    pub fn with_seat_count(
        mut self,
        count: Option<u32>,
    ) -> Self {
        self.price.product.metadata.seat_count = count;
        self
    }

    pub fn build(self) -> PriceEntity {
        self.price
    }
}
