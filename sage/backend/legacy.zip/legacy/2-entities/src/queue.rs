use serde::{Deserialize, Serialize};

#[derive(Debug, Serialize, Deserialize, Clone)]
pub enum NamedQueue {
    Email,
}

impl NamedQueue {
    pub fn as_str(&self) -> &str {
        match self {
            NamedQueue::Email => "email",
        }
    }
}
