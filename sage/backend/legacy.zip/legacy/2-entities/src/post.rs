use aarya_utils::{
    cache_ops, date_ops,
    db_ops::Database,
    result_types::{EntityResult, SuccessResultType},
};
use log::error;
use mongodb::{
    bson::{doc, oid::ObjectId},
    Client,
};

use serde::{Deserialize, Serialize};

const POST_COLLECTION: &str = "posts";
const POST_CACHE_KEY: &str = "all_posts";

use crate::models::req_res::PostResponseModel;

#[derive(Debug, Serialize, Deserialize)]
pub struct PostCacheModel {
    pub model: PostResponseModel,
    pub post_markdown: String,
}

#[derive(Debug, Serialize, Deserialize, Clone)]
pub struct PostEntity {
    #[serde(skip_serializing_if = "Option::is_none")]
    pub _id: Option<ObjectId>,
    pub permalink: String,
    pub title: String,
    pub subtitle: String,
    pub kicker: String,
    pub body: String,
    pub description: String,
    pub tldr: String,
    pub publish_date: i64,
    pub modified_date: i64,
    pub hero_image: String,
    pub creator_id: String,
    pub tag: String,
}

impl PostEntity {
    fn new() -> Self {
        PostEntity {
            _id: None,
            permalink: "not-set".to_string(),
            title: "not-set".to_string(),
            subtitle: "not-set".to_string(),
            kicker: "not-set".to_string(),
            body: "not-set".to_string(),
            description: "not-set".to_string(),
            tldr: "not-set".to_string(),
            publish_date: date_ops::to_timestamp(),
            modified_date: date_ops::to_timestamp(),
            hero_image: "not-set".to_string(),
            creator_id: "not-set".to_string(),
            tag: "not-set".to_string(),
        }
    }

    pub async fn create(
        &self,
        mongoc: &Client,
        cache: &cache_ops::Cache,
    ) -> Option<String> {
        cache.remove(POST_CACHE_KEY);
        let units = Database::get_collection::<PostEntity>(mongoc, "posts");
        let filter = doc! { "permalink": &self.permalink };
        match units.find_one(filter, None).await {
            Ok(Some(_)) => {
                println!("Post with the same permalink already exists, skipping insertion.");
                None
            }
            Ok(None) => match Database::create(&units, self).await {
                EntityResult::Success(r) => match r {
                    SuccessResultType::Created(id) => Some(id),
                    _ => None,
                },
                EntityResult::Error(_) => {
                    error!("Error creating unit entity {:?}", self);
                    None
                }
            },
            Err(e) => {
                error!("Error querying unit collection: {:?}", e);
                None
            }
        }
    }

    pub async fn scan(
        mongoc: &Client,
        cache: &cache_ops::Cache,
    ) -> Option<Vec<PostEntity>> {
        let cached_posts: Option<Vec<PostEntity>> = cache.get_json(POST_CACHE_KEY);
        if cached_posts.is_some() {
            return cached_posts;
        }
        let posts_collection = Database::get_collection::<PostEntity>(mongoc, POST_COLLECTION);
        match Database::find_all(posts_collection).await {
            EntityResult::Success(r) => {
                let posts = r;
                cache.set_json(POST_CACHE_KEY, &posts);
                Some(posts)
            }
            EntityResult::Error(e) => {
                error!("Error scanning posts: {:?}", e);
                None
            }
        }
    }

    pub async fn find(
        mongoc: &Client,
        id: &String,
        cache: &cache_ops::Cache,
    ) -> Option<PostEntity> {
        let cached_posts: Option<Vec<PostEntity>> = Self::scan(mongoc, cache).await;
        if cached_posts.is_some() {
            let posts = cached_posts.unwrap();
            for post in posts {
                if post._id.unwrap().to_hex() == *id {
                    return Some(post);
                }
            }
        }
        None
    }

    pub async fn find_by_permalink(
        mongoc: &Client,
        permalink: &String,
        cache: &cache_ops::Cache,
    ) -> Option<PostEntity> {
        let cached_posts: Option<Vec<PostEntity>> = Self::scan(mongoc, cache).await;
        if cached_posts.is_some() {
            let posts = cached_posts.unwrap();
            for post in posts {
                if post.permalink == *permalink {
                    return Some(post);
                }
            }
        }
        None
    }

    pub async fn update(
        &self,
        mongoc: &Client,
        cache: &cache_ops::Cache,
    ) -> Option<String> {
        cache.remove(POST_CACHE_KEY);
        let posts = Database::get_collection::<PostEntity>(mongoc, POST_COLLECTION);
        match Database::update(&posts, self, &self._id.unwrap().to_hex()).await {
            EntityResult::Success(r) => match r {
                SuccessResultType::Updated(id) => Some(id),
                _ => None,
            },
            EntityResult::Error(_) => {
                error!("Error updating post entity {:?}", self);
                None
            }
        }
    }
}

impl Default for PostEntity {
    fn default() -> Self {
        Self::new()
    }
}
