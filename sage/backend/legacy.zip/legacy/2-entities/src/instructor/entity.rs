use aarya_utils::{db_ops::Database, result_types::EntityResult};
use log::error;
use mongodb::{
    bson::{doc, document},
    Client, Collection,
};
use serde::{Deserialize, Serialize};

use crate::user::UserEntity;

use super::response::InstructorResponseModel;

#[derive(Debug, Serialize, Deserialize, Clone)]
pub struct InstructorEntity {
    pub user_id: String,
    pub full_name: String,
    pub email: String,
    pub first_name: String,
    pub last_name: Option<String>,
    pub bio: String,
    pub intro: String,
    pub caption: Option<String>,
    pub photo_url: String,
    pub expertise: Vec<String>,
}

impl Default for InstructorEntity {
    fn default() -> Self {
        InstructorEntity {
            user_id: "not-set".to_string(),
            full_name: "not-set".to_string(),
            email: "not-set".to_string(),
            first_name: "not-set".to_string(),
            bio: "not-set".to_string(),
            intro: "not-set".to_string(),
            photo_url: "not-set".to_string(),
            expertise: vec![],
            last_name: Some("not-set".to_string()),
            caption: Some("not-set".to_string()),
        }
    }
}

impl InstructorEntity {
    pub fn get_collection(mongoc: &Client) -> Collection<InstructorEntity> {
        Database::get_collection::<InstructorEntity>(mongoc, "instructors")
    }

    pub fn get_id(&self) -> String {
        self.user_id.clone()
    }

    /// Updates or inserts an instructor entity
    pub async fn upsert(
        &self,
        mongoc: &Client,
    ) -> Option<String> {
        let collection = Self::get_collection(mongoc);
        match Database::find_by(&collection, String::from("user_id"), self.user_id.clone()).await {
            EntityResult::Success(_) => {
                // found, update
                self.update(mongoc).await.map(|_| self.user_id.clone())
            }
            EntityResult::Error(_) => {
                // not found, create
                match Database::create(&collection, self).await {
                    EntityResult::Success(_) => Some(self.user_id.clone()),
                    EntityResult::Error(e) => {
                        error!("Error creating instructor: {:?}", e);
                        None
                    }
                }
            }
        }
    }

    /// Finds an instructor by ID
    pub async fn find(
        mongoc: &Client,
        user_id: &String,
    ) -> Option<InstructorEntity> {
        let collection = Self::get_collection(mongoc);
        let filter = doc! {"user_id": user_id};
        Database::filter_by(collection, filter).await.unwrap_or_default().pop()
    }

    /// Finds all instructors
    pub async fn filter(
        mongoc: &Client,
        filter: document::Document,
    ) -> Option<Vec<InstructorEntity>> {
        let collection = Self::get_collection(mongoc);
        Database::filter_by(collection, filter).await
    }

    /// Finds all instructors
    pub async fn scan(mongoc: &Client) -> Option<Vec<InstructorEntity>> {
        let collection = Self::get_collection(mongoc);
        match Database::find_all(collection).await {
            EntityResult::Success(i) => Some(i),
            EntityResult::Error(database_error_type) => {
                error!("Error scanning instructors: {:?}", database_error_type);
                None
            }
        }
    }

    pub async fn update(
        &self,
        mongoc: &Client,
    ) -> Option<bool> {
        let collection = Self::get_collection(mongoc);
        let filter = doc! {"user_id": self.user_id.clone()};
        match Database::update_by(&collection, self, filter).await {
            EntityResult::Success(_) => Some(true),
            EntityResult::Error(_) => Some(false),
        }
    }

    pub async fn from(
        mongoc: &Client,
        user: &UserEntity,
    ) -> Option<InstructorEntity> {
        match Self::find(mongoc, &user._id.unwrap().to_hex()).await {
            Some(u) => Some(InstructorEntity {
                user_id: u.user_id,
                full_name: u.full_name,
                email: u.email,
                first_name: u.first_name,
                bio: u.bio,
                intro: u.intro,
                photo_url: u.photo_url,
                expertise: u.expertise,
                last_name: Some(u.last_name.unwrap_or_default()),
                caption: Some(u.caption.unwrap_or_default()),
            }),
            None => None,
        }
    }

    pub fn to(&self) -> InstructorResponseModel {
        let this = self.clone();
        InstructorResponseModel {
            id: this.user_id.clone(),
            google_id: this.user_id,
            first_name: this.first_name,
            full_name: this.full_name,
            email: this.email,
            bio: this.bio,
            profile_photo: this.photo_url,
            intro: this.intro,
            caption: this.caption.unwrap_or_default(),
            last_name: this.last_name.unwrap_or_default(),
        }
    }
}
