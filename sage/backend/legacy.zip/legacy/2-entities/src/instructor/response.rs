use log::{debug, error};
use mongodb::{bson::doc, Client};
use serde::{Deserialize, Serialize};

use crate::user::UserEntity;

use super::entity::InstructorEntity;

#[derive(Debug, Serialize, Deserialize, Clone)]
pub struct InstructorResponseModel {
    pub id: String,
    pub google_id: String,
    pub first_name: String,
    pub full_name: String,
    pub email: String,
    pub bio: String,
    pub profile_photo: String,
    pub intro: String,
    pub caption: String,
    pub last_name: String,
}

impl Default for InstructorResponseModel {
    fn default() -> Self {
        InstructorResponseModel {
            id: "not-set".to_string(),
            google_id: "not-set".to_string(),
            first_name: "not-set".to_string(),
            full_name: "not-set".to_string(),
            email: "not-set".to_string(),
            bio: "not-set".to_string(),
            profile_photo: "not-set".to_string(),
            intro: "not-set".to_string(),
            caption: "not-set".to_string(),
            last_name: "not-set".to_string(),
        }
    }
}

impl InstructorResponseModel {
    /// Converts a UserEntity and InstructorEntity into an InstructorResponseModel
    pub fn merge(
        user: UserEntity,
        instructor: InstructorEntity,
    ) -> Self {
        InstructorResponseModel {
            id: instructor.get_id(),
            google_id: user.google_id,
            first_name: user.given_name.clone(),
            full_name: format!("{} {}", user.given_name, user.family_name),
            email: user.email,
            bio: instructor.bio,
            profile_photo: instructor.photo_url,
            intro: instructor.intro,
            caption: instructor.caption.unwrap_or_default(),
            last_name: instructor.last_name.unwrap_or_default(),
        }
    }

    /// Converts a vector of UserEntity and InstructorEntity into a vector of InstructorResponseModel
    pub fn from_vector(
        users: &[UserEntity],
        instructors: &Vec<InstructorEntity>,
    ) -> Vec<Self> {
        let mut responses = vec![];

        for instructor in instructors {
            if let Some(user) = users.iter().find(|u| u._id.as_ref().map(|id| id.to_string()) == Some(instructor.user_id.clone())) {
                responses.push(InstructorResponseModel {
                    id: instructor.user_id.clone(),
                    google_id: user.google_id.clone(),
                    first_name: user.given_name.clone(),
                    full_name: user.family_name.clone(),
                    email: user.email.clone(),
                    bio: instructor.bio.clone(),
                    profile_photo: instructor.photo_url.clone(),
                    intro: instructor.intro.clone(),
                    caption: instructor.caption.clone().unwrap_or_default(),
                    last_name: instructor.last_name.clone().unwrap_or_default(),
                });
            }
        }

        responses
    }

    pub fn filter_vector_by(
        instructor_id: &String,
        users: &[UserEntity],
        instructors: &[InstructorEntity],
    ) -> Self {
        if let Some(instructor) = instructors.iter().find(|i| i.user_id == *instructor_id) {
            if let Some(user) = users.iter().find(|u| u.google_id == instructor.user_id) {
                let instructor = instructor.clone();
                let user = user.clone();
                return InstructorResponseModel {
                    id: instructor.user_id,
                    google_id: user.google_id,
                    first_name: user.given_name,
                    full_name: user.family_name,
                    email: user.email,
                    bio: instructor.bio,
                    profile_photo: instructor.photo_url,
                    intro: instructor.intro,
                    caption: instructor.caption.unwrap_or_default(),
                    last_name: instructor.last_name.unwrap_or_default(),
                };
            }
        }

        InstructorResponseModel::default()
    }

    /// Fetches an instructor by ID and returns a response model
    pub async fn from_google_id(
        mongoc: &Client,
        google_id: &String,
    ) -> Option<Self> {
        let users = match UserEntity::filter(mongoc, doc! {"google_id": google_id}).await {
            Some(u) => u,
            None => {
                error!("Failed to find users by google_id: {}", google_id);
                return None;
            }
        };
        let user = users.first().unwrap().clone();
        let instructor = match InstructorEntity::filter(mongoc, doc! {"user_id": google_id }).await.unwrap_or_default().first() {
            Some(i) => i.clone(),
            None => return Some(Self::merge(user.to_owned(), InstructorEntity::default())),
        };
        Some(Self::merge(user.to_owned(), instructor.to_owned()))
    }

    pub async fn from_user_id(
        mongoc: &Client,
        user_id: &String,
    ) -> Self {
        debug!("user_id: {}", user_id);
        let user = UserEntity::find(mongoc, user_id).await.unwrap();
        let instructors = InstructorEntity::filter(mongoc, doc! {"user_id":user_id}).await.unwrap_or_default();
        let instructor = match instructors.first() {
            Some(i) => i,
            None => return InstructorResponseModel::default(),
        };
        Self::merge(user.to_owned(), instructor.to_owned())
    }

    pub async fn from(
        mongoc: &Client,
        user: &UserEntity,
    ) -> Option<Self> {
        let instructor = match InstructorEntity::from(mongoc, user).await {
            Some(i) => i,
            None => return None,
        };
        let instructor = instructor.clone();
        Some(InstructorResponseModel {
            id: instructor.user_id,
            google_id: user.google_id.clone(),
            first_name: user.given_name.clone(),
            full_name: user.family_name.clone(),
            email: user.email.clone(),
            bio: instructor.bio,
            profile_photo: instructor.photo_url,
            intro: instructor.intro,
            caption: instructor.caption.unwrap_or_default(),
            last_name: instructor.last_name.unwrap_or_default(),
        })
    }
}
