use aarya_utils::{
    cache_ops,
    db_ops::Database,
    result_types::{EntityResult, SuccessResultType},
};
use mongodb::{
    bson::{doc, oid::ObjectId},
    Client,
};
use schemars::JsonSchema;
use serde::{Deserialize, Serialize};

use crate::key_value::KeyValue;

const COURSE_COLLECTION: &str = "courses";
const COURSE_CACHE_KEY: &str = "all_courses";

#[derive(Debug, Serialize, Deserialize, Clone)]
pub struct CourseEntity {
    pub _id: ObjectId,
    pub name: String,
    pub slug: String,
    pub meta_description: String,
    pub summary: String,
    pub created: i64,
    pub updated: i64,
    pub active: bool,
    pub tags: String,
    pub metadata: Vec<KeyValue>,
    pub creator_id: String,
    pub disclaimer: Option<String>,
    pub intent: Option<String>,
    pub restricted_words: Option<Vec<String>>,
}

impl Default for CourseEntity {
    fn default() -> Self {
        CourseEntity {
            _id: ObjectId::new(),
            name: String::from("not-set"),
            meta_description: String::from("not-set"),
            created: 0,
            updated: 0,
            active: false,
            creator_id: String::from("not-set"),
            // products: vec![],
            disclaimer: Some(String::from("not-set")),
            intent: Some(String::from("not-set")),
            restricted_words: Some(vec![String::from("official"), String::from("certified"), String::from("endorsed")]),
            slug: String::from("not-set"),
            metadata: vec![],
            tags: String::from("not-set"),
            summary: String::from("not-set"),
        }
    }
}

impl CourseEntity {
    pub async fn create(
        &self,
        mongoc: &Client,
        cache: &cache_ops::Cache,
    ) -> Option<String> {
        cache.remove(COURSE_CACHE_KEY);
        let courses = Database::get_collection::<CourseEntity>(mongoc, COURSE_COLLECTION);
        match Database::create(&courses, self).await {
            EntityResult::Success(r) => match r {
                SuccessResultType::Created(id) => Some(id),
                _ => None,
            },
            EntityResult::Error(e) => {
                log::error!("Error creating course: {:?}", e);
                None
            }
        }
    }

    pub async fn scan(
        mongoc: &Client,
        cache: &cache_ops::Cache,
    ) -> Option<Vec<CourseEntity>> {
        let courses = cache.get_json::<Vec<CourseEntity>>(COURSE_CACHE_KEY);
        if courses.is_some() {
            return courses;
        }
        let collection = Database::get_collection::<CourseEntity>(mongoc, COURSE_COLLECTION);
        let courses = match Database::find_all(collection).await {
            EntityResult::Success(r) => Some(r),
            EntityResult::Error(e) => {
                log::error!("Error scanning courses: {:?}", e);
                None
            }
        };
        if courses.is_some() {
            let courses = courses.unwrap();
            let _ = cache.set_json(COURSE_CACHE_KEY, &courses);
            Some(courses)
        } else {
            None
        }
    }

    pub async fn find_by_slug(
        mongoc: &Client,
        cache: &cache_ops::Cache,
        slug: String,
    ) -> Option<CourseEntity> {
        let courses = Self::scan(mongoc, cache).await;
        let courses = courses.unwrap();
        for course in courses {
            if course.slug.eq_ignore_ascii_case(&slug) {
                return Some(course);
            }
        }
        None
    }

    pub async fn exists(
        &self,
        mongoc: &Client,
        cache: &cache_ops::Cache,
    ) -> bool {
        let courses = Self::scan(mongoc, cache).await;
        let courses = courses.unwrap();
        for course in courses {
            if course.name.to_lowercase() == self.name.to_lowercase() {
                return true;
            }
        }
        false
    }

    pub async fn find_by_id(
        mongoc: &Client,
        cache: &cache_ops::Cache,
        id: String,
    ) -> Option<CourseEntity> {
        let courses = Self::scan(mongoc, cache).await;
        let courses = courses.unwrap();
        for course in courses {
            if course._id.to_hex() == id {
                return Some(course);
            }
        }
        None
    }

    pub async fn update(
        &self,
        mongoc: &Client,
        cache: &cache_ops::Cache,
    ) -> Option<String> {
        cache.remove(COURSE_CACHE_KEY);
        let courses = Database::get_collection::<CourseEntity>(mongoc, COURSE_COLLECTION);
        match Database::update(&courses, self, &self._id.to_hex()).await {
            EntityResult::Success(r) => match r {
                SuccessResultType::Updated(id) => Some(id),
                _ => None,
            },
            EntityResult::Error(e) => {
                log::error!("Error updating course: {:?}", e);
                None
            }
        }
    }
}

#[derive(Serialize, Deserialize, Debug, Clone, JsonSchema)]
pub struct CourseRequestModel {
    #[schemars(length(min = 8, max = 64))]
    pub name: String,
    #[schemars(length(min = 64, max = 156))]
    pub meta_description: String,
    #[schemars(length(min = 64, max = 2048))]
    pub summary: String,
    #[schemars(length(min = 4, max = 64))]
    pub slug: String,
    #[schemars(length(min = 4, max = 256))]
    pub tags: String,
    #[schemars(length(min = 1, max = 16))]
    pub metadata: Vec<KeyValue>,
    pub disclaimer: Option<String>,
    pub intent: Option<String>,
    pub restricted_words: Option<Vec<String>>,
}

impl Default for CourseRequestModel {
    fn default() -> Self {
        CourseRequestModel {
            name: "".to_string(),
            meta_description: "".to_string(),
            summary: "".to_string(),
            disclaimer: Some("".to_string()),
            intent: Some("".to_string()),
            restricted_words: Some(vec![]),
            slug: "".to_string(),
            metadata: vec![],
            tags: "".to_string(),
        }
    }
}
