use aarya_utils::{db_ops::Database, image_ops::ImagePath, result_types::EntityResult};
use log::{error, info};
use mongodb::{
    bson::{document, oid::ObjectId},
    Client, Collection,
};
use serde::{Deserialize, Serialize};

use crate::{
    admin::AdminEntity,
    instructor::entity::InstructorEntity,
    models::{google::GoogleUserModel, user_role::UserRole},
};

#[derive(Debug, Serialize, Deserialize, Clone)]
pub struct UserEntity {
    pub _id: Option<ObjectId>,
    pub google_id: String,
    pub email: String,
    pub verified_email: bool,
    pub full_name: String,
    pub given_name: String,
    pub family_name: String,
    pub picture: String,
    pub role: Option<UserRole>,
}

impl Default for UserEntity {
    fn default() -> Self {
        UserEntity {
            _id: None,
            google_id: "not-set".to_string(),
            email: "not-set".to_string(),
            verified_email: false,
            full_name: "not-set".to_string(),
            given_name: "not-set".to_string(),
            family_name: "not-set".to_string(),
            picture: "not-set".to_string(),
            role: None,
        }
    }
}

impl UserEntity {
    pub fn get_collection(mongoc: &Client) -> Collection<UserEntity> {
        Database::get_collection::<UserEntity>(mongoc, "users")
    }

    pub fn from(user: GoogleUserModel) -> UserEntity {
        UserEntity {
            _id: ObjectId::new().into(),
            google_id: user.id,
            email: user.email.clone(),
            verified_email: user.verified_email,
            full_name: user.name,
            given_name: user.given_name,
            family_name: user.family_name,
            picture: user.picture,
            role: Some(UserRole::from_email(user.email.as_str())),
        }
    }

    pub async fn create(
        &self,
        mongoc: &Client,
    ) -> Option<Self> {
        let collection = Self::get_collection(mongoc);
        match Database::create(&collection, self).await {
            EntityResult::Success(_) => Some(self.clone()),
            EntityResult::Error(e) => {
                error!("Error creating user: {:?}", e);
                None
            }
        }
    }

    // insert in the users collection if a user with google_id does not exist
    // insert in the instructors collection if the UserRole is an instructor
    // insert in the admins collection if the UserRole is an admin
    pub async fn insert_if(
        &self,
        mongoc: &Client,
        google_id: &String,
        user_model: &GoogleUserModel,
    ) -> Option<UserEntity> {
        let collection = Self::get_collection(mongoc);
        let user = match Database::find_by(&collection, String::from("google_id"), google_id).await {
            EntityResult::Success(r) => Some(r),
            EntityResult::Error(_) => None,
        };

        if user.is_some() {
            info!("User already exists: {:?}", user);
            return Some(user.unwrap_or_default());
        }

        let user = Self::from(user_model.clone());
        info!("Creating new user: {:?}", user);
        user.create(mongoc).await;

        match user.role.clone().unwrap() {
            UserRole::Instructor => {
                let user_clone = user.clone();
                let instructor = InstructorEntity {
                    user_id: user_clone._id.unwrap().to_hex(),
                    full_name: user_clone.full_name,
                    email: user_clone.email,
                    first_name: user_clone.given_name,
                    bio: "".to_string(),
                    intro: "".to_string(),
                    photo_url: "not-set".to_string(),
                    expertise: vec![],
                    last_name: Some(user_clone.family_name),
                    caption: Some("not-set".to_string()),
                };
                instructor.upsert(mongoc).await;
                info!("Created new instructor: {:?}", instructor);
            }
            UserRole::Admin => {
                let user_clone = user.clone();
                let instructor = InstructorEntity {
                    user_id: user_clone._id.unwrap().to_hex(),
                    full_name: user_clone.full_name,
                    email: user_clone.email,
                    first_name: user_clone.given_name,
                    bio: "".to_string(),
                    intro: "".to_string(),
                    photo_url: "not-set".to_string(),
                    expertise: vec![],
                    last_name: Some(user_clone.family_name),
                    caption: Some("not-set".to_string()),
                };
                instructor.upsert(mongoc).await;
                info!("Created new instructor: {:?}", instructor);

                let user_clone = user.clone();
                let admin = AdminEntity {
                    user_id: user_clone._id.unwrap().to_hex(),
                    full_name: user_clone.full_name,
                    email: user_clone.email,
                    first_name: user_clone.given_name,
                    bio: "".to_string(),
                    intro: "".to_string(),
                    photo_url: ImagePath::default(),
                    expertise: vec![],
                };
                admin.upsert(mongoc).await;
                info!("Created new admin: {:?}", admin);
            }
            _ => (),
        }

        Some(user)
    }

    pub async fn find(
        mongoc: &Client,
        user_id: &String,
    ) -> Option<UserEntity> {
        let collection = Self::get_collection(mongoc);
        match Database::find(collection, user_id).await {
            EntityResult::Success(r) => Some(r),
            EntityResult::Error(e) => {
                error!("Failed to find user: {:?}", e);
                None
            }
        }
    }

    pub async fn filter(
        mongoc: &Client,
        filter: document::Document,
    ) -> Option<Vec<UserEntity>> {
        let collection = Self::get_collection(mongoc);
        Database::filter_by(collection, filter).await
    }

    pub async fn scan(mongoc: &Client) -> Option<Vec<UserEntity>> {
        let collection = Self::get_collection(mongoc);
        match Database::find_all(collection).await {
            EntityResult::Success(r) => Some(r),
            EntityResult::Error(e) => {
                error!("Error scanning users: {:?}", e);
                None
            }
        }
    }
}
