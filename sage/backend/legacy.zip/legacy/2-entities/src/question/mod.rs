use schemars::JsonSchema;
use serde::{Deserialize, Serialize};

pub mod question_entity;

#[derive(Debug, Serialize, Deserialize, Clone, JsonSchema)]
pub enum QuestionType {
    /// Multiple choice questions have two or more correct answers and multiple incorrect answers.
    MultipleChoice,
    /// Single choice questions have one correct answer and multiple incorrect answers.
    SingleChoice,
    /// True/False questions have two choices: True or False.
    TrueFalse,
}

#[derive(Debug, Serialize, Deserialize, Clone, JsonSchema)]
pub enum QuestionDifficulty {
    /// Easy questions are conceptual and require basic understanding of the topic e.g. what is polymorphism?
    Easy,
    /// Medium questions are more complex and require a deeper understanding of the topic e.g. what is the difference between polymorphism and inheritance? These question have code and have one or more correct answers.
    Medium,
    /// Hard questions are challenging and require a comprehensive understanding of the topic. They have complex code in the question and in choices that test various related concepts. They have more than two correct answers.
    Hard,
}
