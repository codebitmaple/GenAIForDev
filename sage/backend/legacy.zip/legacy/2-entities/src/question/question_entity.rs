use aarya_utils::{
    cache_ops,
    db_ops::Database,
    result_types::{EntityResult, SuccessResultType},
};
use log::error;
use mongodb::bson::{doc, oid::ObjectId};
use schemars::JsonSchema;
use serde::{Deserialize, Serialize};

use crate::key_value::KeyValue;

use super::{QuestionDifficulty, QuestionType};

const QUESTION_COLLECTION: &str = "questions";
const QUESTION_CACHE_KEY: &str = "all_questions";

#[derive(Debug, Serialize, Deserialize, Clone, JsonSchema)]
pub struct QuestionUploadModel {
    pub question: String,
    /// Provide four or more choices for multiple and single choice questions. For True/False questions, provide two choices: True and False.
    pub choices: Vec<KeyValue>,
    pub answers: Vec<String>,
    pub question_type: QuestionType,
    pub key_concept: String,
    pub question_difficulty: QuestionDifficulty,
    pub answer_explanation: String,
    pub tags: Vec<String>,
    pub group_id: String,
    pub kind: QuestionKind,
    pub target: QuestionTarget,
    pub illustration: IllustrationType,
    pub order: i32,
}

#[derive(Debug, Serialize, Deserialize, Clone, JsonSchema, PartialEq)]
pub enum QuestionKind {
    Standalone,
    Group,
    NotSet,
}

#[derive(Debug, Serialize, Deserialize, Clone, JsonSchema, PartialEq)]
pub enum QuestionTarget {
    Exam,
    Exercise,
    NotSet,
}

/// Illustration type if the question contains code, table, graph, or diagrams. Use NotSet if no illustration is present. For Graph and Diagram types, generate Mermaid code. For Code and Table generate Markdown code.
#[derive(Debug, Serialize, Deserialize, Clone, JsonSchema)]
pub enum IllustrationType {
    Code,
    Table,
    Graph,
    Diagram,
    NotSet,
}

#[derive(Debug, Serialize, Deserialize, Clone)]
pub struct QuestionEntity {
    pub _id: ObjectId,
    pub question: String,
    pub question_hash: String,
    pub choices: Vec<KeyValue>,
    pub answers: Vec<String>,
    pub created_at: i64,
    pub updated_at: i64,
    pub course_id: String,
    pub unit_id: String,
    pub topic_id: Option<String>,
    pub tags: Vec<String>,
    pub question_type: QuestionType,
    pub key_concept: String,
    pub question_difficulty: QuestionDifficulty,
    pub answer_explanation: String,
    // set group_id to a value if the question is part of a group of questions, otherwise leave blank
    pub group_id: Option<String>,
    pub kind: Option<QuestionKind>,
    pub target: Option<QuestionTarget>,
    pub illustration: Option<IllustrationType>,
    pub order: Option<i32>,
}

impl Default for QuestionEntity {
    fn default() -> Self {
        QuestionEntity {
            _id: ObjectId::new(),
            question: "not-set".to_string(),
            question_hash: "not-set".to_string(),
            choices: vec![],
            answers: vec![],
            created_at: 0,
            updated_at: 0,
            course_id: "not-set".to_string(),
            unit_id: "not-set".to_string(),
            topic_id: Some("not-set".to_string()),
            question_type: QuestionType::MultipleChoice,
            key_concept: "not-set".to_string(),
            question_difficulty: QuestionDifficulty::Easy,
            answer_explanation: "not-set".to_string(),
            tags: vec![],
            group_id: None,
            kind: None,
            target: None,
            illustration: None,
            order: None,
        }
    }
}

impl QuestionEntity {
    pub async fn create(
        &self,
        mongoc: &mongodb::Client,
        cache: &cache_ops::Cache,
    ) -> Option<String> {
        cache.remove(QUESTION_CACHE_KEY);
        let questions = Database::get_collection::<QuestionEntity>(mongoc, "questions");
        let filter = doc! { "question_hash": &self.question_hash };
        match questions.find_one(filter, None).await {
            Ok(Some(_)) => {
                println!("Question with the same hash already exists, skipping insertion.");
                None
            }
            Ok(None) => match Database::create(&questions, self).await {
                EntityResult::Success(r) => match r {
                    SuccessResultType::Created(id) => Some(id),
                    _ => None,
                },
                EntityResult::Error(_) => {
                    error!("Error creating question entity {:?}", self);
                    None
                }
            },
            Err(e) => {
                error!("Error querying unit collection: {:?}", e);
                None
            }
        }
    }

    pub async fn scan(
        mongoc: &mongodb::Client,
        cache: &cache_ops::Cache,
    ) -> Option<Vec<QuestionEntity>> {
        let cached_questions = cache.get_json(QUESTION_CACHE_KEY);
        if cached_questions.is_some() {
            return cached_questions;
        }
        let questions_collection = Database::get_collection::<QuestionEntity>(mongoc, QUESTION_COLLECTION);
        let questions = match Database::find_all(questions_collection).await {
            EntityResult::Success(r) => r,
            EntityResult::Error(e) => {
                error!("Error scanning question collection {:?}", e);
                return None;
            }
        };
        cache.set_json(QUESTION_CACHE_KEY, &questions);
        Some(questions)
    }
}
