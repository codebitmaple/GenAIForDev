use aarya_utils::{db_ops::Database, image_ops::ImagePath, result_types::EntityResult};
use log::error;
use mongodb::{bson::doc, Client};
use serde::{Deserialize, Serialize};

#[derive(Debug, Serialize, Deserialize, Clone)]
pub struct AdminEntity {
    pub user_id: String,
    pub full_name: String,
    pub email: String,
    pub first_name: String,
    pub bio: String,
    pub intro: String,
    pub photo_url: ImagePath,
    pub expertise: Vec<String>,
}

impl Default for AdminEntity {
    fn default() -> Self {
        AdminEntity {
            user_id: "not-set".to_string(),
            full_name: "not-set".to_string(),
            email: "not-set".to_string(),
            first_name: "not-set".to_string(),
            bio: "not-set".to_string(),
            intro: "not-set".to_string(),
            photo_url: ImagePath::new("not-set".to_string(), "not-set".to_string()),
            expertise: vec![],
        }
    }
}

impl AdminEntity {
    pub fn get_id(&self) -> String {
        self.user_id.clone()
    }

    /// Updates or inserts an instructor entity
    pub async fn upsert(
        &self,
        mongoc: &Client,
    ) -> EntityResult<AdminEntity> {
        let collection = Database::get_collection::<AdminEntity>(mongoc, "admins");
        match Database::find_by(&collection, String::from("user_id"), self.user_id.clone()).await {
            EntityResult::Success(_) => EntityResult::Success(self.clone()),
            EntityResult::Error(_) => {
                // not found, create
                match Database::create(&collection, self).await {
                    EntityResult::Success(_) => EntityResult::Success(self.clone()),
                    EntityResult::Error(e) => {
                        error!("Error creating admin: {:?}", e);
                        EntityResult::Error(e)
                    }
                }
            }
        }
    }

    /// Finds an instructor by ID
    pub async fn find(
        mongoc: &Client,
        id: &String,
    ) -> EntityResult<AdminEntity> {
        let collection = Database::get_collection::<AdminEntity>(mongoc, "admins");
        match Database::find(collection, id).await {
            EntityResult::Success(r) => EntityResult::Success(r),
            EntityResult::Error(e) => {
                error!("Error finding admin: {:?}", e);
                EntityResult::Error(e)
            }
        }
    }

    /// Finds all admins
    pub async fn scan(mongoc: &Client) -> EntityResult<Vec<AdminEntity>> {
        let collection = Database::get_collection::<AdminEntity>(mongoc, "admins");
        match Database::find_all(collection).await {
            EntityResult::Success(r) => EntityResult::Success(r),
            EntityResult::Error(e) => {
                error!("Error finding admins: {:?}", e);
                EntityResult::Error(e)
            }
        }
    }
}
