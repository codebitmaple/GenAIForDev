use aarya_utils::{
    date_ops,
    db_ops::Database,
    result_types::{EntityResult, SuccessResultType},
};
use mongodb::{bson::doc, Client};
use serde::{Deserialize, Serialize};

use crate::{key_value::KeyValue, question::QuestionDifficulty};

#[derive(Serialize, Deserialize, Debug, Clone)]
pub struct ResultEntity {
    pub question: String,                        // HTML format of the question
    pub choices: Vec<KeyValue>,                  // A list of choices with key-value pairs
    pub user_answers: Vec<String>,               // User-selected answers
    pub correct_answers: Vec<String>,            // Correct answers
    pub score: f64,                              // Score for the question
    pub key_concept: Option<String>,             // Key concept associated with the question
    pub question_difficulty: QuestionDifficulty, // Difficulty level of the question
    pub answer_explanation: String,              // HTML explanation for the answer
    pub correct: bool,                           // Whether the user's answer was correct
    pub exercise_id: String,                     // ID of the exercise
    pub question_id: String,                     // ID of the question
    pub course_slug: String,                     // Course slug for context
    pub user_id: String,                         // User ID
    pub timestamp: i64,                          // Timestamp of the result
    pub date_created: String,                    // Date created
}

impl Default for ResultEntity {
    fn default() -> Self {
        ResultEntity {
            question: "not-set".to_string(),
            choices: vec![],
            user_answers: vec![],
            correct_answers: vec![],
            score: 0.0,
            key_concept: None,
            question_difficulty: QuestionDifficulty::Easy,
            answer_explanation: "not-set".to_string(),
            correct: false,
            exercise_id: "not-set".to_string(),
            question_id: "not-set".to_string(),
            course_slug: "not-set".to_string(),
            user_id: "not-set".to_string(),
            timestamp: date_ops::to_timestamp(),
            date_created: date_ops::to_display_date(date_ops::local_date_time()),
        }
    }
}

impl ResultEntity {
    pub async fn create(
        &self,
        mongoc: &Client,
    ) -> Option<String> {
        let results = Database::get_collection::<ResultEntity>(mongoc, "results");
        match Database::create(&results, self).await {
            EntityResult::Success(r) => match r {
                SuccessResultType::Created(id) => Some(id),
                _ => None,
            },
            EntityResult::Error(e) => {
                log::error!("Error saving result: {:?}", e);
                None
            }
        }
    }

    pub async fn scan(
        &self,
        mongoc: &Client,
    ) -> Option<Vec<ResultEntity>> {
        let results = Database::get_collection::<ResultEntity>(mongoc, "results");
        match Database::find_all(results).await {
            EntityResult::Success(r) => Some(r),
            EntityResult::Error(e) => {
                log::error!("Error scanning results: {:?}", e);
                None
            }
        }
    }

    pub async fn filter(
        &self,
        mongoc: &Client,
        key: &str,
        value: &str,
    ) -> Option<Vec<ResultEntity>> {
        let results = Database::get_collection::<ResultEntity>(mongoc, "results");
        match Database::filter_by(results, doc! {key: value}).await {
            Some(r) => Some(r),
            None => {
                log::debug!("No results found for key: {} value: {}", key, value);
                None
            }
        }
    }
}
