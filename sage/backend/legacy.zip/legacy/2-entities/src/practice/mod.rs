pub mod practice_entity;
pub mod result_entity;
