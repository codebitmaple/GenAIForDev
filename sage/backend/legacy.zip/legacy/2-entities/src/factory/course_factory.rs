use crate::{
    course::course_entity::CourseEntity,
    product::{
        product_creator::ProductCreator,
        product_entity::{Cadence, DeliveryMethod, ProductEntity, PurchaseType},
        product_type::ProductType,
    },
};

pub struct CourseFactory;

impl CourseFactory {
    pub fn create_products(course: &CourseEntity) -> Vec<ProductEntity> {
        let creator = ProductCreator;

        vec![
            creator.create_product(
                course,
                "self-monthly-subscription",
                DeliveryMethod::SelfService,
                Cadence::Monthly,
                PurchaseType::Subscription,
                ProductType::SelfMonthly,
            ),
            creator.create_product(
                course,
                "self-annual-subscription",
                DeliveryMethod::SelfService,
                Cadence::Yearly,
                PurchaseType::Subscription,
                ProductType::SelfAnnual,
            ),
            creator.create_product(
                course,
                "self-fixed-as-needed",
                DeliveryMethod::SelfService,
                Cadence::AsNeeded,
                PurchaseType::Fixed,
                ProductType::SelfFixed,
            ),
            creator.create_product(
                course,
                "private-as-needed-fixed",
                DeliveryMethod::PrivateLessons,
                Cadence::AsNeeded,
                PurchaseType::Fixed,
                ProductType::PrivateAsNeeded,
            ),
            creator.create_product(
                course,
                "private-ongoing-fixed",
                DeliveryMethod::PrivateLessons,
                Cadence::Ongoing,
                PurchaseType::Fixed,
                ProductType::PrivateOngoing,
            ),
            creator.create_product(
                course,
                "private-monthly-subscription",
                DeliveryMethod::PrivateLessons,
                Cadence::Monthly,
                PurchaseType::Subscription,
                ProductType::PrivateMonthly,
            ),
            creator.create_product(
                course,
                "private-annual-subscription",
                DeliveryMethod::PrivateLessons,
                Cadence::Yearly,
                PurchaseType::Subscription,
                ProductType::PrivateAnnual,
            ),
            creator.create_product(
                course,
                "group-ongoing-fixed",
                DeliveryMethod::GroupLessons,
                Cadence::Ongoing,
                PurchaseType::Fixed,
                ProductType::GroupOngoing,
            ),
        ]
    }
}
