use crate::{
    builder::price_builder::PriceBuilder,
    product::{product_entity::ProductEntity, product_type::ProductType},
};

pub struct PriceFactory;

impl PriceFactory {
    pub fn create_builder(product: &ProductEntity) -> PriceBuilder {
        match product.product_type {
            ProductType::SelfMonthly => PriceBuilder::new(product.clone()).with_amount_cents(1900).with_billing_period(Some("Monthly".to_string())),
            ProductType::SelfAnnual => PriceBuilder::new(product.clone()).with_amount_cents(9 * 12 * 100).with_billing_period(Some("Annually".to_string())),
            ProductType::SelfFixed => PriceBuilder::new(product.clone()).with_amount_cents(4900).with_billing_period(Some("Lifetime".to_string())),
            ProductType::PrivateAsNeeded => {
                PriceBuilder::new(product.clone()).with_amount_cents(14900).with_session_count(Some(1))
                // 1 session
            }
            ProductType::PrivateOngoing => {
                PriceBuilder::new(product.clone()).with_amount_cents(10900).with_session_count(Some(3))
                // 3 sessions
            }
            ProductType::PrivateMonthly => {
                PriceBuilder::new(product.clone())
                    .with_amount_cents(49900)
                    .with_session_count(Some(10)) // 10 hours per month
                    .with_billing_period(Some("Monthly".to_string()))
            }
            ProductType::PrivateAnnual => {
                PriceBuilder::new(product.clone())
                    .with_amount_cents(399900)
                    .with_session_count(Some(100)) // 100 hours annually
                    .with_billing_period(Some("Annually".to_string()))
            }
            ProductType::GroupOngoing => {
                PriceBuilder::new(product.clone())
                    .with_amount_cents(99900)
                    .with_seat_count(Some(5)) // 5 seats
                    .with_session_count(Some(20)) // 20 sessions
            }
            ProductType::Unknown => todo!(),
        }
    }
}
