use aarya_utils::{
    db_ops::Database,
    result_types::{EntityResult, SuccessResultType},
};
use mongodb::{bson::oid::ObjectId, Client};
use serde::{Deserialize, Serialize};

use super::{product_metadata::ProductMetadata, product_type::ProductType};

#[derive(Debug, Serialize, Deserialize, Clone)]
pub struct ProductEntity {
    pub _id: ObjectId,
    pub stripe_id: Option<String>,
    pub course_id: String,
    pub display_name: String,
    pub nickname: String,
    pub description: String,
    pub metadata: ProductMetadata,
    pub created: i64,
    pub updated: i64,
    pub active: bool,
    pub livemode: bool,
    pub course_description: String,
    pub product_type: ProductType,
}

impl Default for ProductEntity {
    fn default() -> Self {
        ProductEntity {
            _id: ObjectId::new(),
            stripe_id: None,
            display_name: String::from("not-set"),
            nickname: String::from("not-set"),
            description: String::from("not-set"),
            metadata: ProductMetadata {
                method: DeliveryMethod::SelfService,
                cadence: Cadence::Monthly,
                billing_type: PurchaseType::Subscription,
                billing_period: None,
                session_count: None,
                seat_count: None,
            },
            created: 0,
            updated: 0,
            active: false,
            livemode: false,
            course_description: String::from("not-set"),
            product_type: ProductType::Unknown,
            course_id: String::from("not-set"),
        }
    }
}

#[derive(Debug, Serialize, Deserialize, Clone, PartialEq)]
pub enum DeliveryMethod {
    SelfService,
    PrivateLessons,
    GroupLessons,
}

#[derive(Debug, Serialize, Deserialize, Clone, PartialEq)]
pub enum Cadence {
    Ongoing,
    Monthly,
    Yearly,
    AsNeeded,
}

#[derive(Debug, Serialize, Deserialize, Clone, PartialEq)]
pub enum PurchaseType {
    Subscription,
    Fixed,
}

impl ProductEntity {
    pub async fn create(
        &self,
        mongoc: &Client,
    ) -> Option<String> {
        let products = Database::get_collection::<ProductEntity>(mongoc, "products");
        match Database::create(&products, self).await {
            EntityResult::Success(SuccessResultType::Created(id)) => Some(id),
            _ => None,
        }
    }
}
