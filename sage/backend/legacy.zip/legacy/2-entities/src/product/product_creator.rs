use crate::{builder::product_builder::ProductBuilder, course::course_entity::CourseEntity};

use super::{
    product_entity::{Cadence, DeliveryMethod, ProductEntity, PurchaseType},
    product_type::ProductType,
};

pub struct ProductCreator;

impl ProductCreator {
    pub fn create_product(
        &self,
        course: &CourseEntity,
        display_name: &str,
        method: DeliveryMethod,
        cadence: Cadence,
        billing_type: PurchaseType,
        product_type: ProductType,
    ) -> ProductEntity {
        ProductBuilder::new()
            .with_display_name(display_name)
            .with_method(method)
            .with_cadence(cadence)
            .with_billing_type(billing_type)
            .with_course_description(course.meta_description.clone())
            .with_product_type(product_type)
            .build()
    }
}
