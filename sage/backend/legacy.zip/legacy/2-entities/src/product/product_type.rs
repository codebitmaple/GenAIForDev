use serde::{Deserialize, Serialize};

#[derive(Debug, Serialize, Deserialize, Clone, Copy, PartialEq)]
pub enum ProductType {
    Unknown,
    SelfMonthly,
    SelfAnnual,
    SelfFixed,
    PrivateAsNeeded,
    PrivateOngoing,
    PrivateMonthly,
    PrivateAnnual,
    GroupOngoing,
}
