use serde::{Deserialize, Serialize};

use super::product_entity::{Cadence, DeliveryMethod, PurchaseType};

#[derive(Debug, Serialize, Deserialize, Clone)]
pub struct ProductMetadata {
    pub method: DeliveryMethod,
    pub cadence: Cadence,
    pub billing_type: PurchaseType,
    pub billing_period: Option<String>, // E.g., "Monthly", "Annually"
    pub session_count: Option<u32>,     // Number of sessions (for private/group topics)
    pub seat_count: Option<u32>,        // Number of seats (for group topics)
}
