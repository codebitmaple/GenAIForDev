use serde::{Deserialize, Serialize};

#[derive(Debug, Deserialize, Serialize, Clone)]
pub enum PricingCategory {
    HumanOneOnOne,
    HumanBatch,
    AiAssisted,
    Unknown,
}

impl PricingCategory {
    pub fn describe(&self) -> String {
        match self {
            PricingCategory::HumanOneOnOne => String::from("1:1"),
            PricingCategory::HumanBatch => String::from("Batch"),
            PricingCategory::AiAssisted => String::from("AI"),
            PricingCategory::Unknown => String::from("Unknown"),
        }
    }
}
