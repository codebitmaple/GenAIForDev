use serde::{Deserialize, Serialize};

use super::{pricing_category::PricingCategory, pricing_type::PricingType};

#[derive(Debug, Deserialize, Serialize)]
pub struct PriceBreakup {
    pub pricing_type: PricingType,
    pub pricing_category: PricingCategory,
    pub count: u32,
    pub amount: f32,
    pub price: f32,
    pub volume_discount: bool,
}

impl Default for PriceBreakup {
    fn default() -> Self {
        PriceBreakup {
            pricing_type: PricingType::Unknown,
            pricing_category: PricingCategory::Unknown,
            count: 0,
            amount: 0.0,
            volume_discount: false,
            price: 0.0,
        }
    }
}

impl PriceBreakup {
    pub fn new(
        pricing_type: PricingType,
        pricing_category: PricingCategory,
        count: u32,
        amount: f32,
        price: f32,
        volume_discount: bool,
    ) -> Self {
        PriceBreakup {
            pricing_type,
            pricing_category,
            count,
            amount,
            price,
            volume_discount,
        }
    }
}
