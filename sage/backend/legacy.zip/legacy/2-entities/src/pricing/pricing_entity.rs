use serde::{Deserialize, Serialize};

use super::{
    price_breakup::PriceBreakup,
    pricing_category::PricingCategory,
    pricing_type::PricingType,
    professional_pricing::ProfessionalPricing,
    stripe_price::StripePrice,
    stripe_product::StripeProduct,
    student_pricing::StudentPricing,
    unit_pricing::{AIAssistedPricing, BatchSession, OneOnOneSession, UnitPrice},
};

// Professional pricing, always 1:1, can be recurring or ad-hoc, and AI-assisted options

// Overall pricing model separating students and professionals
#[derive(Debug, Deserialize, Serialize)]
pub struct PricingEntity {
    pub student_pricing: StudentPricing,           // Pricing for students
    pub professional_pricing: ProfessionalPricing, // Pricing for professionals
    pub pricing_type: PricingType,
    pub pricing_category: PricingCategory,
}

#[derive(Debug, Deserialize, Serialize, Clone)]
pub enum AiCadence {
    Monthly,
    Annual,
    NotSet,
}

impl Default for PricingEntity {
    fn default() -> Self {
        PricingEntity {
            pricing_type: PricingType::Unknown,
            pricing_category: PricingCategory::Unknown,
            student_pricing: StudentPricing {
                one_on_one: OneOnOneSession {
                    recurring_price: UnitPrice { list_price: 99.0, sale_price: 89.0 },
                    ad_hoc_price: UnitPrice { list_price: 129.0, sale_price: 119.0 },
                },
                batch_session: BatchSession {
                    recurring_price: UnitPrice { list_price: 79.0, sale_price: 69.0 },
                    group_size: 10,
                    duration_weeks: 12,
                    sessions_per_week: 3,
                },
                ai_assisted: AIAssistedPricing {
                    monthly_price: UnitPrice { list_price: 39.0, sale_price: 29.0 },
                    annual_price: UnitPrice { list_price: 19.0, sale_price: 9.0 },
                },
            },
            professional_pricing: ProfessionalPricing {
                one_on_one: OneOnOneSession {
                    recurring_price: UnitPrice { list_price: 109.0, sale_price: 99.0 },
                    ad_hoc_price: UnitPrice { list_price: 149.0, sale_price: 139.0 },
                },
                ai_assisted: AIAssistedPricing {
                    monthly_price: UnitPrice { list_price: 59.0, sale_price: 49.0 },
                    annual_price: UnitPrice { list_price: 29.0, sale_price: 19.0 },
                },
            },
        }
    }
}

#[derive(Debug, Deserialize, Serialize)]
pub struct PricingError {
    pub message: String,
}

impl PricingEntity {
    pub fn calculate(
        pricing_type: &PricingType,
        category: &PricingCategory,
        count: u32,
        ai_cadence: Option<AiCadence>,
    ) -> Result<PriceBreakup, PricingError> {
        let pricing = PricingEntity::default();
        let cadence = ai_cadence.unwrap_or(AiCadence::NotSet);

        let mut price_breakup = PriceBreakup::default();

        if count < 1 {
            return Err(PricingError {
                message: "Sessions must be greater than 0".to_string(),
            });
        }

        match pricing_type {
            PricingType::Student => {
                let student = pricing.student_pricing;
                match category {
                    PricingCategory::HumanOneOnOne => {
                        if count > 2 {
                            price_breakup.pricing_type = PricingType::Student;
                            price_breakup.pricing_category = PricingCategory::HumanOneOnOne;
                            price_breakup.count = count;
                            price_breakup.amount = student.one_on_one.recurring_price.sale_price * count as f32;
                            price_breakup.volume_discount = true;
                            price_breakup.price = student.one_on_one.recurring_price.sale_price;
                        } else {
                            price_breakup.pricing_type = PricingType::Student;
                            price_breakup.pricing_category = PricingCategory::HumanOneOnOne;
                            price_breakup.count = count;
                            price_breakup.amount = student.one_on_one.ad_hoc_price.sale_price * count as f32;
                            price_breakup.volume_discount = false;
                            price_breakup.price = student.one_on_one.ad_hoc_price.sale_price;
                        }
                    }
                    PricingCategory::HumanBatch => {
                        let batch = student.batch_session;
                        price_breakup.pricing_type = PricingType::Student;
                        price_breakup.pricing_category = PricingCategory::HumanBatch;
                        price_breakup.count = count;
                        price_breakup.amount = (batch.duration_weeks * batch.sessions_per_week) as f32 * batch.recurring_price.sale_price * count as f32;
                        price_breakup.volume_discount = true;
                        price_breakup.price = batch.recurring_price.sale_price;
                    }
                    PricingCategory::AiAssisted => {
                        let ai = student.ai_assisted;
                        match cadence {
                            AiCadence::Monthly => {
                                price_breakup.pricing_type = PricingType::Student;
                                price_breakup.pricing_category = PricingCategory::AiAssisted;
                                price_breakup.count = 1;
                                price_breakup.amount = ai.monthly_price.sale_price;
                                price_breakup.volume_discount = false;
                                price_breakup.price = ai.monthly_price.sale_price;
                            }
                            AiCadence::Annual => {
                                price_breakup.pricing_type = PricingType::Student;
                                price_breakup.pricing_category = PricingCategory::AiAssisted;
                                price_breakup.count = 12;
                                price_breakup.amount = ai.annual_price.sale_price * 12.0;
                                price_breakup.volume_discount = true;
                                price_breakup.price = ai.annual_price.sale_price;
                            }
                            AiCadence::NotSet => Err(PricingError {
                                message: "AI cadence not set".to_string(),
                            })?,
                        }
                    }
                    PricingCategory::Unknown => Err(PricingError {
                        message: "Unknown pricing category".to_string(),
                    })?,
                }
            }

            PricingType::Professional => {
                let professional = pricing.professional_pricing;
                match category {
                    PricingCategory::HumanOneOnOne => {
                        if count > 3 {
                            // final_price = professional.one_on_one.recurring_price.sale_price * count as f32;
                            price_breakup.pricing_type = PricingType::Professional;
                            price_breakup.pricing_category = PricingCategory::HumanOneOnOne;
                            price_breakup.count = count;
                            price_breakup.amount = professional.one_on_one.recurring_price.sale_price * count as f32;
                            price_breakup.volume_discount = true;
                            price_breakup.price = professional.one_on_one.recurring_price.sale_price;
                        } else {
                            // final_price = professional.one_on_one.ad_hoc_price.sale_price * count as f32;
                            price_breakup.pricing_type = PricingType::Professional;
                            price_breakup.pricing_category = PricingCategory::HumanOneOnOne;
                            price_breakup.count = count;
                            price_breakup.amount = professional.one_on_one.ad_hoc_price.sale_price * count as f32;
                            price_breakup.volume_discount = false;
                            price_breakup.price = professional.one_on_one.ad_hoc_price.sale_price;
                        }
                    }
                    PricingCategory::HumanBatch => Err(PricingError {
                        message: "Professional pricing does not support batch sessions".to_string(),
                    })?,
                    PricingCategory::AiAssisted => {
                        let ai = professional.ai_assisted;
                        match cadence {
                            AiCadence::Monthly => {
                                // final_price = ai.monthly_price.sale_price * 1.0;
                                price_breakup.pricing_type = PricingType::Professional;
                                price_breakup.pricing_category = PricingCategory::AiAssisted;
                                price_breakup.count = 1;
                                price_breakup.amount = ai.monthly_price.sale_price;
                                price_breakup.volume_discount = false;
                                price_breakup.price = ai.monthly_price.sale_price;
                            }
                            AiCadence::Annual => {
                                // final_price = ai.annual_price.sale_price * 12.0;
                                price_breakup.pricing_type = PricingType::Professional;
                                price_breakup.pricing_category = PricingCategory::AiAssisted;
                                price_breakup.count = 12;
                                price_breakup.amount = ai.annual_price.sale_price * 12.0;
                                price_breakup.volume_discount = true;
                                price_breakup.price = ai.annual_price.sale_price;
                            }
                            AiCadence::NotSet => {
                                // final_price = ai.monthly_price.sale_price * 1.0;
                                price_breakup.pricing_type = PricingType::Professional;
                                price_breakup.pricing_category = PricingCategory::AiAssisted;
                                price_breakup.count = 1;
                                price_breakup.amount = ai.monthly_price.sale_price;
                                price_breakup.volume_discount = false;
                                price_breakup.price = ai.monthly_price.sale_price;
                            }
                        }
                    }
                    PricingCategory::Unknown => Err(PricingError {
                        message: "Unknown pricing category".to_string(),
                    })?,
                }
            }
            PricingType::Unknown => Err(PricingError {
                message: "Unknown pricing type".to_string(),
            })?,
        }

        Ok(price_breakup)
    }

    pub fn determine_product_name(
        pricing_type: PricingType,
        category: PricingCategory,
        ai_cadence: Option<AiCadence>,
    ) -> Option<StripeProduct> {
        let cadence = ai_cadence.unwrap_or(AiCadence::NotSet);

        match pricing_type {
            PricingType::Student => match category {
                PricingCategory::HumanOneOnOne => Some(StripeProduct {
                    name: String::from("Student 1:1 Session"),
                }),
                PricingCategory::HumanBatch => Some(StripeProduct {
                    name: String::from("Student Batch Session"),
                }),
                PricingCategory::AiAssisted => match cadence {
                    AiCadence::Monthly => Some(StripeProduct {
                        name: String::from("Student AI Monthly"),
                    }),
                    AiCadence::Annual => Some(StripeProduct {
                        name: String::from("Student AI Annual"),
                    }),
                    AiCadence::NotSet => None,
                },
                PricingCategory::Unknown => None,
            },
            PricingType::Professional => match category {
                PricingCategory::HumanOneOnOne => Some(StripeProduct {
                    name: String::from("Professional 1:1 Session"),
                }),
                PricingCategory::HumanBatch => None,
                PricingCategory::AiAssisted => match cadence {
                    AiCadence::Monthly => Some(StripeProduct {
                        name: String::from("Professional AI Monthly"),
                    }),
                    AiCadence::Annual => Some(StripeProduct {
                        name: String::from("Professional AI Annual"),
                    }),
                    AiCadence::NotSet => Some(StripeProduct {
                        name: String::from("Professional AI Monthly"),
                    }),
                },
                PricingCategory::Unknown => None,
            },
            PricingType::Unknown => None,
        }
    }

    pub fn determine_price_id() -> Option<StripePrice> {
        // uniquely identify price by product id + currency + unit_amount (price in cents)
        None
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_calculate_valid_input_one_on_one() {
        let pricing_type = PricingType::Student;
        let category = PricingCategory::HumanOneOnOne;
        let count = 2;
        let ai_cadence = None;

        let result = PricingEntity::calculate(&pricing_type, &category, count, ai_cadence);

        assert!(result.is_ok());
        let price_breakup = result.unwrap();
        // assert_eq!(price_breakup.pricing_type, pricing_type);
        // assert_eq!(price_breakup.pricing_category, category);
        assert_eq!(price_breakup.count, count);
    }

    #[test]
    fn test_calculate_invalid_input_zero_sessions() {
        let pricing_type = PricingType::Student;
        let category = PricingCategory::HumanOneOnOne;
        let count = 0;
        let ai_cadence = None;

        let result = PricingEntity::calculate(&pricing_type, &category, count, ai_cadence);

        assert!(result.is_err());
        let error = result.err().unwrap();
        assert_eq!(error.message, "Sessions must be greater than 0");
    }

    #[test]
    fn test_calculate_valid_input_batch_session() {
        let pricing_type = PricingType::Student;
        let category = PricingCategory::HumanBatch;
        let count = 5;
        let ai_cadence = None;

        let result = PricingEntity::calculate(&pricing_type, &category, count, ai_cadence);

        assert!(result.is_ok());
        let price_breakup = result.unwrap();
        // assert_eq!(price_breakup.amount, PricingEntity::default().student_pricing.batch_session.recurring_price.sale_price * count as f32);
        // assert_eq!(price_breakup.pricing_type, pricing_type);
        // assert_eq!(price_breakup.pricing_category, category);
        assert_eq!(price_breakup.count, count);
    }

    #[test]
    fn test_calculate_valid_input_ai_assisted() {
        let pricing_type = PricingType::Student;
        let category = PricingCategory::AiAssisted;
        let count = 1;
        let ai_cadence = Some(AiCadence::Monthly);

        let result = PricingEntity::calculate(&pricing_type, &category, count, ai_cadence);

        assert!(result.is_ok());
        let price_breakup = result.unwrap();
        assert_eq!(price_breakup.amount, PricingEntity::default().student_pricing.ai_assisted.monthly_price.sale_price * count as f32);
        // assert_eq!(price_breakup.pricing_type, pricing_type);
        // assert_eq!(price_breakup.pricing_category, category);
        assert_eq!(price_breakup.count, count);
    }
}
