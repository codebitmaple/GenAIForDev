use serde::{Deserialize, Serialize};

#[derive(Debug, Deserialize, Serialize)]
pub struct StripePrice {
    pub id: String,
    pub unit_amount: u32,
    // Stripe product ID
    pub product: String,
    pub currency: String,
    pub recurring: Option<RecurringPrice>,
}

#[derive(Debug, Deserialize, Serialize)]
pub struct LineItem {
    // Stripe price ID
    pub price: String,
    pub quantity: u32,
}

#[derive(Debug, Deserialize, Serialize)]
#[serde(rename_all = "lowercase")]
pub enum RecurringIterval {
    Day,
    Week,
    Month,
    Year,
}

#[derive(Debug, Deserialize, Serialize)]
pub struct RecurringPrice {
    pub interval_count: u32,
    pub interval: RecurringIterval,
}
