use serde::{Deserialize, Serialize};

use super::unit_pricing::{AIAssistedPricing, BatchSession, OneOnOneSession};

// Student pricing, can have 1:1 or batch sessions, and AI-assisted options
#[derive(Debug, Deserialize, Serialize)]
pub struct StudentPricing {
    pub one_on_one: OneOnOneSession,    // 1:1 session pricing (human-assisted)
    pub batch_session: BatchSession,    // Batch session pricing (human-assisted)
    pub ai_assisted: AIAssistedPricing, // AI-assisted pricing for students
}
