// use log::{debug, error};
use reqwest::Client;
use serde::{Deserialize, Serialize};

use super::{pricing_category::PricingCategory, pricing_entity::AiCadence, pricing_type::PricingType};

#[derive(Debug, Deserialize, Serialize)]
pub struct StripeProduct {
    pub name: String,
}

impl StripeProduct {
    fn determine_name(
        &self,
        pricing_type: PricingType,
        category: PricingCategory,
        ai_cadence: Option<AiCadence>,
    ) -> Option<StripeProduct> {
        let cadence = ai_cadence.unwrap_or(AiCadence::NotSet);

        match pricing_type {
            PricingType::Student => match category {
                PricingCategory::HumanOneOnOne => Some(StripeProduct {
                    name: String::from("Student 1:1 Session"),
                }),
                PricingCategory::HumanBatch => Some(StripeProduct {
                    name: String::from("Student Batch Session"),
                }),
                PricingCategory::AiAssisted => match cadence {
                    AiCadence::Monthly => Some(StripeProduct {
                        name: String::from("Student AI Monthly"),
                    }),
                    AiCadence::Annual => Some(StripeProduct {
                        name: String::from("Student AI Annual"),
                    }),
                    AiCadence::NotSet => None,
                },
                PricingCategory::Unknown => None,
            },
            PricingType::Professional => match category {
                PricingCategory::HumanOneOnOne => Some(StripeProduct {
                    name: String::from("Professional 1:1 Session"),
                }),
                PricingCategory::HumanBatch => None,
                PricingCategory::AiAssisted => match cadence {
                    AiCadence::Monthly => Some(StripeProduct {
                        name: String::from("Professional AI Monthly"),
                    }),
                    AiCadence::Annual => Some(StripeProduct {
                        name: String::from("Professional AI Annual"),
                    }),
                    AiCadence::NotSet => Some(StripeProduct {
                        name: String::from("Professional AI Monthly"),
                    }),
                },
                PricingCategory::Unknown => None,
            },
            PricingType::Unknown => None,
        }
    }

    pub async fn create(
        &self,
        pricing_type: PricingType,
        category: PricingCategory,
        ai_cadence: Option<AiCadence>,
    ) {
        let product = self.determine_name(pricing_type, category, ai_cadence).unwrap();
        println!("Product: {:?}", product);
        let client = Client::new();
        let api_url = "http://127.0.0.1:8181/products/";
        let response = client.post(api_url).json(&product).send();
        match response.await {
            Ok(_) => {
                // save in MongoDb
            }
            Err(e) => println!("Error saving product: {:?}", e),
        }
    }

    pub async fn retrieve(
        &self,
        name: String,
    ) -> Option<String> {
        let product = StripeProduct { name };
        println!("Product: {:?}", product);
        // get product_id from database by name
        let client = Client::new();
        let api_url = format!("http://127.0.0.1:8181/products/{}", "product_id");
        let response = client.get(api_url).send();
        match response.await {
            Ok(p) => {
                println!("Product: {:?}", p);
            }
            Err(e) => println!("Error saving product: {:?}", e),
        };

        Some(String::from(""))
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[tokio::test]
    async fn test_create_product_success() {
        let stripe_product = StripeProduct { name: "Test Product".to_string() };

        // Define your parameters
        let pricing_type = PricingType::Student;
        let category = PricingCategory::HumanOneOnOne;
        let ai_cadence = None;

        // Invoke the create function
        stripe_product.create(pricing_type, category, ai_cadence).await;
    }
}
