use serde::{Deserialize, Serialize};

#[derive(Debug, Deserialize, Serialize)]

pub struct UnitPrice {
    pub list_price: f32,
    pub sale_price: f32,
}

// 1:1 session pricing (can be recurring or ad-hoc)
#[derive(Debug, Deserialize, Serialize)]
pub struct OneOnOneSession {
    pub recurring_price: UnitPrice, // Recurring session price
    pub ad_hoc_price: UnitPrice,    // Ad-hoc session price
}

// Batch session pricing (always recurring)
#[derive(Debug, Deserialize, Serialize)]
pub struct BatchSession {
    pub recurring_price: UnitPrice, // Recurring session price
    pub group_size: usize,          // Number of students in the batch
    pub duration_weeks: u32,        // Duration in weeks
    pub sessions_per_week: u32,     // Sessions per week
}

// AI-assisted pricing (monthly and annual)
#[derive(Debug, Deserialize, Serialize)]
pub struct AIAssistedPricing {
    pub monthly_price: UnitPrice, // Monthly subscription price
    pub annual_price: UnitPrice,  // Annual subscription price (paid once a year)
}
