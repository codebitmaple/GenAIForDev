use serde::{Deserialize, Serialize};

use super::unit_pricing::{AIAssistedPricing, OneOnOneSession};

#[derive(Debug, Deserialize, Serialize)]
pub struct ProfessionalPricing {
    pub one_on_one: OneOnOneSession,    // 1:1 session pricing (human-assisted)
    pub ai_assisted: AIAssistedPricing, // AI-assisted pricing for professionals
}
