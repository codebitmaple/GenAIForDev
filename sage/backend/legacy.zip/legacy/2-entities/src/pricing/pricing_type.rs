use serde::{Deserialize, Serialize};

#[derive(Debug, Deserialize, Serialize, Clone)]
pub enum PricingType {
    Student,
    Professional,
    Unknown,
}
