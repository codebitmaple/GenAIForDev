use serde::{Deserialize, Serialize};

use super::stripe_price::LineItem;

#[derive(Debug, Deserialize, Serialize)]
#[serde(rename_all = "lowercase")]
pub enum CheckoutMode {
    Payment,
    Subscription,
    Setup,
}

#[derive(Debug, Deserialize, Serialize)]
pub struct StripeCheckoutModel {
    pub success_url: String,
    pub cancel_url: String,
    pub line_items: Vec<LineItem>,
    pub mode: CheckoutMode,
}

impl Default for StripeCheckoutModel {
    fn default() -> Self {
        StripeCheckoutModel {
            success_url: String::from("https://example.com/success"),
            cancel_url: String::from("https://example.com/cancel"),
            line_items: Vec::new(),
            mode: CheckoutMode::Payment,
        }
    }
}

#[derive(Debug, Deserialize, Serialize)]
pub struct Product {
    pub name: String,
}

#[derive(Debug, Deserialize, Serialize)]
pub struct CheckoutRequest {
    pub product_data: Product,
    pub payment_method_types: Option<Vec<String>>,
    pub currency: Option<String>,
    pub price_in_cents: Option<u32>,
    pub quantity: Option<u32>,
    pub mode: Option<String>,
    pub success_url: String,
    pub cancel_url: String,
    pub customer_email: String,
}

#[derive(Serialize, Deserialize, Debug, Clone)]
pub struct CheckoutResponse {
    pub checkout_url: String,
    pub checkout_id: String,
    pub livemode: bool,
}
