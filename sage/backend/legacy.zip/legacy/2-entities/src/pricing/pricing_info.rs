use serde::{Deserialize, Serialize};

use super::{pricing_category::PricingCategory, pricing_type::PricingType};

#[derive(Debug, Deserialize, Serialize, Clone)]
pub struct PricingInfo {
    pub pricing_type: PricingType,
    pub pricing_category: PricingCategory,
}

impl PricingInfo {
    pub fn set_pricing_type(
        &mut self,
        pricing_type: PricingType,
    ) {
        self.pricing_type = pricing_type;
    }

    pub fn set_pricing_category(
        &mut self,
        pricing_category: PricingCategory,
    ) {
        self.pricing_category = pricing_category;
    }
}

impl Default for PricingInfo {
    fn default() -> Self {
        PricingInfo {
            pricing_type: PricingType::Unknown,
            pricing_category: PricingCategory::Unknown,
        }
    }
}
