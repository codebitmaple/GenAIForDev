use serde::{Deserialize, Serialize};

use crate::queue::NamedQueue;

#[derive(Debug, Serialize, Deserialize, Clone)]
pub struct PaymentConfirmationModel {
    pub queue_name: NamedQueue,
    pub idempotent_key: String,
    pub booking_id: String,
    pub template_name: String,
    pub email_from: String,
    pub email_to: Vec<String>,
    pub header: String,
    pub subject: String,
    pub message: String,
    pub cta_link: String,
    pub cta_text: String,
}

impl Default for PaymentConfirmationModel {
    fn default() -> Self {
        PaymentConfirmationModel {
            queue_name: NamedQueue::Email,
            idempotent_key: String::from(""),
            booking_id: String::from(""),
            template_name: String::from(""),
            email_from: String::from("sanjeet@aarya.ai"),
            email_to: vec![String::from("")],
            header: String::from(""),
            subject: String::from(""),
            message: String::from(""),
            cta_link: String::from(""),
            cta_text: String::from(""),
        }
    }
}
