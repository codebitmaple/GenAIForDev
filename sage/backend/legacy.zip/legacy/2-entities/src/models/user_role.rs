use serde::{Deserialize, Serialize};

#[derive(Debug, Deserialize, Serialize, Clone, PartialEq)]
pub enum UserRole {
    Instructor,
    Student,
    Admin,
}

impl UserRole {
    pub fn from_email(email: &str) -> UserRole {
        let email = email.to_lowercase();
        if email.eq("sanjeet@aarya.ai") {
            UserRole::Admin
        } else if email.ends_with("@aarya.com") {
            UserRole::Instructor
        } else {
            UserRole::Student
        }
    }
}
