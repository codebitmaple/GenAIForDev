use mongodb::bson::oid::ObjectId;
use serde::{Deserialize, Serialize};

use crate::user::UserEntity;

use super::user_role::UserRole;

#[derive(Debug, Deserialize, Serialize, Clone)]
pub struct GoogleUserModel {
    pub id: String,
    pub email: String,
    pub verified_email: bool,
    pub name: String,
    pub given_name: String,
    pub family_name: String,
    pub picture: String,
    pub role: Option<UserRole>,
}

impl Default for GoogleUserModel {
    fn default() -> Self {
        GoogleUserModel {
            id: "not-set".to_string(),
            email: "not-set".to_string(),
            verified_email: false,
            name: "not-set".to_string(),
            given_name: "not-set".to_string(),
            family_name: "not-set".to_string(),
            picture: "not-set".to_string(),
            role: None,
        }
    }
}

impl GoogleUserModel {
    pub fn to_user_entity(&self) -> UserEntity {
        UserEntity {
            _id: ObjectId::new().into(),
            google_id: self.id.clone(),
            email: self.email.clone(),
            verified_email: self.verified_email,
            full_name: self.name.clone(),
            given_name: self.given_name.clone(),
            family_name: self.family_name.clone(),
            picture: self.picture.clone(),
            role: self.role.clone(),
        }
    }
}
