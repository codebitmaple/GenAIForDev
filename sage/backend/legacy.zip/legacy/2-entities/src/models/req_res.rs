use std::collections::HashMap;

use aarya_utils::date_ops;

use schemars::JsonSchema;
use serde::{Deserialize, Serialize};

use crate::{
    instructor::{entity::InstructorEntity, response::InstructorResponseModel},
    post::PostEntity,
    user::UserEntity,
};

#[derive(Debug, Serialize, Deserialize)]
pub struct TagRequestModel {
    pub name: String,
    pub description: String,
}

#[derive(Debug, Serialize, Deserialize)]
pub struct TagResponseModel {
    pub id: String,
    pub name: String,
    pub description: String,
}

#[derive(Debug, Serialize, Deserialize, Clone)]
pub struct PostResponseModel {
    pub id: String,
    pub permalink: String,
    pub title: String,
    pub subtitle: String,
    pub keywords: String,
    pub body: String,
    pub description: String,
    pub tldr: String,
    pub hero_image: String,
    pub profile_image: String,
    pub publish_date: String,
    pub modified_date: String,
    pub instructor: InstructorResponseModel,
}

#[derive(Debug, Serialize, Deserialize, JsonSchema)]
pub struct PostRequestModel {
    pub permalink: String,
    pub title: String,
    pub subtitle: String,
    pub keywords: String,
    pub body: String,
    pub description: String,
    pub tldr: String,
    pub hero_image: String,
    pub tags_csv: String,
}

impl Default for PostResponseModel {
    fn default() -> Self {
        PostResponseModel {
            id: "not-set".to_string(),
            permalink: "not-set".to_string(),
            title: "not-set".to_string(),
            keywords: "not-set".to_string(),
            subtitle: "not-set".to_string(),
            body: "not-set".to_string(),
            description: "not-set".to_string(),
            tldr: "not-set".to_string(),
            hero_image: "not-set".to_string(),
            profile_image: "not-set".to_string(),
            publish_date: date_ops::local_date_time().to_string(),
            modified_date: date_ops::local_date_time().to_string(),
            instructor: InstructorResponseModel::default(),
        }
    }
}

impl PostResponseModel {
    pub fn from_entity(entity: PostEntity) -> Self {
        PostResponseModel {
            id: entity._id.unwrap().to_string(),
            permalink: entity.permalink.to_string(),
            title: entity.title.to_string(),
            keywords: entity.kicker.to_string(),
            subtitle: entity.subtitle.to_string(),
            body: entity.body,
            description: entity.description.to_string(),
            tldr: entity.tldr.to_string(),
            hero_image: entity.hero_image.clone(),
            profile_image: entity.hero_image.clone(),
            publish_date: date_ops::to_display_date(date_ops::from(entity.publish_date)),
            modified_date: date_ops::to_display_date(date_ops::from(entity.publish_date)),
            instructor: InstructorResponseModel::default(),
        }
    }

    fn map_users(users: &[UserEntity]) -> HashMap<String, &UserEntity> {
        users.iter().map(|user| (user.google_id.clone(), user)).collect()
    }

    fn map_instructors(instructors: &[InstructorEntity]) -> HashMap<String, &InstructorEntity> {
        instructors.iter().map(|instr| (instr.user_id.clone(), instr)).collect()
    }

    pub fn all(
        posts: &Vec<PostEntity>,
        users: &[UserEntity],
        instructors: &[InstructorEntity],
    ) -> Vec<PostResponseModel> {
        let mut response = Vec::new();
        let users_map = Self::map_users(users);
        let instructors_map = Self::map_instructors(instructors);

        for post in posts {
            if let Some(user) = users_map.get(&post.creator_id) {
                if let Some(instructor) = instructors_map.get(&user.google_id) {
                    let post_response = PostResponseModel {
                        id: post._id.unwrap().to_hex(),
                        permalink: post.permalink.clone(),
                        title: post.title.clone(),
                        subtitle: post.subtitle.clone(),
                        keywords: post.tag.clone(),
                        body: post.body.clone(),
                        description: post.description.clone(),
                        tldr: post.tldr.clone(),
                        hero_image: post.hero_image.clone(),
                        profile_image: instructor.photo_url.clone(),
                        publish_date: date_ops::to_display_date(date_ops::from(post.publish_date)),
                        modified_date: date_ops::to_display_date(date_ops::from(post.modified_date)),
                        instructor: InstructorResponseModel {
                            id: instructor.get_id(),
                            google_id: instructor.user_id.clone(),
                            first_name: instructor.first_name.clone(),
                            full_name: instructor.full_name.clone(),
                            email: instructor.email.clone(),
                            bio: instructor.bio.clone(),
                            profile_photo: instructor.photo_url.clone(),
                            intro: instructor.intro.clone(),
                            caption: instructor.caption.clone().unwrap_or_default(),
                            last_name: instructor.last_name.clone().unwrap_or_default(),
                        },
                    };
                    response.push(post_response);
                }
            }
        }

        response
    }

    pub fn combine(
        entity: &PostEntity,
        instructor: InstructorResponseModel,
    ) -> Self {
        PostResponseModel {
            id: entity._id.unwrap().to_string(),
            permalink: entity.permalink.to_string(),
            title: entity.title.to_string(),
            keywords: entity.kicker.to_string(),
            subtitle: entity.subtitle.to_string(),
            body: entity.body.clone(),
            description: entity.description.to_string(),
            tldr: entity.tldr.to_string(),
            hero_image: entity.hero_image.clone(),
            profile_image: entity.hero_image.clone(),
            publish_date: date_ops::to_display_date(date_ops::from(entity.publish_date)),
            modified_date: date_ops::to_display_date(date_ops::from(entity.modified_date)),
            instructor,
        }
    }
}

impl PostRequestModel {
    pub fn to(&self) -> PostEntity {
        PostEntity {
            permalink: self.permalink.to_string(),
            title: self.title.to_string(),
            body: self.body.clone(),
            description: self.description.to_string(),
            tldr: self.tldr.to_string(),
            hero_image: self.hero_image.to_string(),
            subtitle: self.subtitle.to_string(),
            _id: None,
            creator_id: "not-set".to_string(),
            tag: self.tags_csv.clone(),
            kicker: self.keywords.to_string(),
            publish_date: date_ops::to_timestamp(),
            modified_date: date_ops::to_timestamp(),
        }
    }

    pub fn from(entity: PostEntity) -> Self {
        PostRequestModel {
            permalink: entity.permalink.to_string(),
            title: entity.title.to_string(),
            subtitle: entity.subtitle.to_string(),
            keywords: entity.kicker.to_string(),
            body: entity.body,
            description: entity.description.to_string(),
            tldr: entity.tldr.to_string(),
            hero_image: entity.hero_image,
            tags_csv: entity.tag.to_string(),
        }
    }
}

impl Default for PostRequestModel {
    fn default() -> Self {
        PostRequestModel {
            permalink: "not-set".to_string(),
            title: "not-set".to_string(),
            subtitle: "not-set".to_string(),
            keywords: "not-set".to_string(),
            body: "not-set".to_string(),
            description: "not-set".to_string(),
            tldr: "not-set".to_string(),
            hero_image: "not-set".to_string(),
            tags_csv: "not-set".to_string(),
        }
    }
}
