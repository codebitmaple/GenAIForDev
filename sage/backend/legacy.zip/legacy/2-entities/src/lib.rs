use key_value::KeyValue;
use question::{QuestionDifficulty, QuestionType};
use serde::{Deserialize, Serialize};

pub mod admin;
pub mod booking;
pub mod builder;
pub mod course;
pub mod email;
pub mod exam;
pub mod exercise;
pub mod factory;
pub mod instructor;
pub mod key_value;
pub mod models;
pub mod openai;
pub mod payment;
pub mod post;
pub mod practice;
pub mod price;
pub mod pricing;
pub mod product;
pub mod question;
pub mod queue;
pub mod session;
pub mod stripe;
pub mod tag;
pub mod topic;
pub mod unit;
pub mod user;

#[derive(Serialize, Deserialize, Debug, Clone)]
pub struct QuestionResponseModel {
    pub id: String,
    pub question: String,
    pub choices: Vec<KeyValue>,
    pub question_type: QuestionType,
    pub difficulty: QuestionDifficulty,
}

#[derive(Serialize, Deserialize, Debug, Clone)]
pub struct AnswerRequest {
    pub question_id: String,
    pub answers: Vec<String>,
}

#[derive(Serialize, Deserialize, Debug, Clone)]
pub struct AnswerRequestModel {
    pub test_id: String,
    pub answers: Vec<AnswerRequest>,
}
