import stripe
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel

import osenv


# Single model for both Create and Update
class ProductModel(BaseModel):
    name: str


# Initialize FastAPI
app = FastAPI()

stripe.api_key = osenv.get_stripe_key()


@app.get("/")
async def home():
    return "Product home"


# Create a new product in Stripe
@app.post("/create/", response_model=dict)
async def create_product(product: ProductModel):
    try:
        print(product)
        stripe_product = stripe.Product.create(
            name=product.name,
        )
        print(stripe_product)
        return stripe_product
    except stripe.error.StripeError as e:
        raise HTTPException(status_code=400, detail=str(e))
