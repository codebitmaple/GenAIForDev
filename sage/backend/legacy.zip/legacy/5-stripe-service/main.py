from fastapi import FastAPI

import price
import product
import session

import osenv

# print(osenv.get_stripe_key())

# FastAPI app
app = FastAPI()
# Mount the apps with different paths
app.mount("/session", session.app)
app.mount("/price", price.app)
app.mount("/product", product.app)





