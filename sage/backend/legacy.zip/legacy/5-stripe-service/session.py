import stripe
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from typing import Dict, List, Optional
import logging
import osenv

stripe.api_key = osenv.get_stripe_key()

class Product(BaseModel):
    name: str

app = FastAPI()

class CheckoutArgs(BaseModel):
    product_data: Product
    payment_method_types: Optional[List[str]] = ["card"]  # Default value
    currency: Optional[str] = "usd"  # Default value
    price_in_cents: Optional[int] = 1  # Default value
    quantity: Optional[int] = 1  # Default value
    mode: Optional[str] = "payment"  # Default value
    customer_email: str
    success_url: str
    cancel_url: str


@app.get("/")
async def home():
    return "Session home"

# Checkout API
@app.post("/checkout/")
async def create_checkout_session(arg: CheckoutArgs):
    print(arg)
    try:
        pricing_session = stripe.Price.create(
            currency=arg.currency,
            unit_amount=arg.price_in_cents,
            product_data=arg.product_data.model_dump(),
        )

        print(pricing_session)

        # Attempt to create a Stripe Checkout session
        session = stripe.checkout.Session.create(
            payment_method_types=arg.payment_method_types,
            line_items=[{'price': pricing_session.id, 'quantity': arg.quantity}],
            mode=arg.mode,
            success_url=arg.success_url,
            cancel_url=arg.cancel_url,
            customer_email=arg.customer_email
        )

        print(session)

        return {"checkout_url": session.url, "livemode": session.livemode, "checkout_id": session.id}

    except stripe.error.AuthenticationError as e:
        logging.error(e)
        raise HTTPException(status_code=401, detail="Authentication with Stripe API failed")

    except stripe.error.InvalidRequestError as e:
        logging.error(e)
        raise HTTPException(status_code=400, detail=f"Invalid request to Stripe API: {e.user_message}")

    except stripe.error.APIConnectionError as e:
        logging.error(e)
        raise HTTPException(status_code=502, detail="Network error connecting to Stripe API")

    except stripe.error.StripeError as e:
        logging.error(e)
        raise HTTPException(status_code=500, detail="Something went wrong with Stripe")

    except Exception as e:
        logging.error(e)
        raise HTTPException(status_code=500, detail="An internal server error occurred")