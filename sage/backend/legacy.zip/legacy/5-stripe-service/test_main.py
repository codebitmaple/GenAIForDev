from typing import List
import pytest
from fastapi.testclient import TestClient
from main import app

client = TestClient(app)

valid_price_data = {
    "price_in_cents": 1000,
    "product_data": {"name": "Student AI Learning (Annual Plan)"},
    "currency": "usd",
    "payment_method_types": ["card"],
    "quantity": 1,
    "payment_frequency": "one_time",
    "mode": "payment"
}


def test_create_checkout_session_integration():
    """Integration test for creating a Stripe checkout session."""
    
    # Send a POST request to the stripe-checkout endpoint with valid data
    response = client.post("http://127.0.0.1:8000/stripe-checkout/", json=valid_price_data)
    
    # Assert the response status code
    assert response.status_code == 200
    
    # Parse the response JSON
    response_data = response.json()

    print(response_data)
    
    # Check if the checkout URL exists
    assert "checkout_url" in response_data
    assert response_data["checkout_url"].startswith("https://checkout.stripe.com/")
    
    # Optionally, print the checkout URL for manual inspection
    print(f"Checkout URL: {response_data['checkout_url']}")
    


def test_create_checkout_session_integration_invalid_data():
    """Integration test with invalid data to test error handling."""
    
    # Invalid data (missing required fields)
    invalid_price_data = {
        "currency": "usd"
        # Missing unit_amount, recurring, and product_data
    }
    
    # Send a POST request with invalid data
    response = client.post("/stripe-checkout/", json=invalid_price_data)
    
    # Assert the response status code
    assert response.status_code == 422  # Unprocessable Entity, as validation should fail