from pydantic import BaseModel
from fastapi import FastAPI, HTTPException
import stripe
from pydantic import BaseModel
import osenv
import logging

# Single model for both Create and Update
class ProductModel(BaseModel):
    name: str

# Initialize FastAPI
app = FastAPI()

stripe.api_key = osenv.get_stripe_key()

# Single data model for both Create and Update
class PriceModel(BaseModel):
    product_id: str
    currency: str
    unit_amount: int

@app.get("/")
async def home():
    return "Price home"

# Create a new product in Stripe
@app.post("/create/", response_model=dict)
async def create_price(pricing_request: PriceModel):
    try:
        print(pricing_request)
        price_response = stripe.Price.create(
            product=pricing_request.product_id,
            unit_amount=pricing_request.unit_amount,
            currency=pricing_request.currency
        )
        print(price_response)
        return price_response
    except stripe.error.StripeError as e:
        raise HTTPException(status_code=400, detail=str(e))

