# start docker
sudo systemctl start docker

# enable and start the service
sudo systemctl daemon-reload

# enable the service to start on boot
sudo systemctl enable docker-compose-app

# stop the service
sudo systemctl stop docker-compose-app

# start the service
sudo systemctl start docker-compose-app

# check the status
sudo systemctl status docker-compose-app