[Unit]
Description=Docker Compose App Service
After=docker.service
Requires=docker.service

[Service]
EnvironmentFile=/home/ec2-user/aarya/.env
WorkingDirectory=/home/ec2-user/aarya
ExecStart=/usr/local/bin/docker-compose up
ExecStop=/usr/local/bin/docker-compose down
Restart=always
TimeoutStartSec=0

[Install]
WantedBy=multi-user.target