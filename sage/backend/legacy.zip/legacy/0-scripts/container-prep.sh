IMAGE_TAG=$(git rev-parse --short HEAD)
WEB_IMAGE_TAG=$(git rev-parse --short HEAD)
AWS_REGION=us-west-2
AWS_ACCOUNT_ID=579989334487

## Step 1: Build and push docker images to ECR
docker build -t aarya-web:$WEB_IMAGE_TAG .
docker build -f Dockerfile.consumers -t aarya-queue-consumers:$IMAGE_TAG .
docker build -f Dockerfile.stripe -t aarya-stripe-service:$IMAGE_TAG .
docker build -f Dockerfile.email -t aarya-email-service:$IMAGE_TAG .
docker build -f Dockerfile.cli -t aarya-generator-cli:$IMAGE_TAG .

# Step 2: authenticate docker to EC2
aws ecr get-login-password --region $AWS_REGION | docker login --username AWS --password-stdin $AWS_ACCOUNT_ID.dkr.ecr.$AWS_REGION.amazonaws.com

# Step 3: tag docker images
docker tag aarya-web:$WEB_IMAGE_TAG $AWS_ACCOUNT_ID.dkr.ecr.$AWS_REGION.amazonaws.com/aarya-web:$WEB_IMAGE_TAG
docker tag aarya-queue-consumers:$IMAGE_TAG $AWS_ACCOUNT_ID.dkr.ecr.$AWS_REGION.amazonaws.com/aarya-queue-consumers:$IMAGE_TAG
docker tag aarya-stripe-service:$IMAGE_TAG $AWS_ACCOUNT_ID.dkr.ecr.$AWS_REGION.amazonaws.com/aarya-stripe-service:$IMAGE_TAG
docker tag aarya-email-service:$IMAGE_TAG $AWS_ACCOUNT_ID.dkr.ecr.$AWS_REGION.amazonaws.com/aarya-email-service:$IMAGE_TAG
docker tag aarya-generator-cli:$IMAGE_TAG $AWS_ACCOUNT_ID.dkr.ecr.$AWS_REGION.amazonaws.com/aarya-generator-cli:$IMAGE_TAG

# Step 4: push docker images to ECR
docker push $AWS_ACCOUNT_ID.dkr.ecr.$AWS_REGION.amazonaws.com/aarya-web:$WEB_IMAGE_TAG
docker push $AWS_ACCOUNT_ID.dkr.ecr.$AWS_REGION.amazonaws.com/aarya-queue-consumers:$IMAGE_TAG
docker push $AWS_ACCOUNT_ID.dkr.ecr.$AWS_REGION.amazonaws.com/aarya-stripe-service:$IMAGE_TAG
docker push $AWS_ACCOUNT_ID.dkr.ecr.$AWS_REGION.amazonaws.com/aarya-email-service:$IMAGE_TAG
docker push $AWS_ACCOUNT_ID.dkr.ecr.$AWS_REGION.amazonaws.com/aarya-generator-cli:$IMAGE_TAG

# # create ECR repositories
# aws ecr create-repository --repository-name aarya-web
# aws ecr create-repository --repository-name aarya-browser-app
# aws ecr create-repository --repository-name aarya-queue-consumers
# aws ecr create-repository --repository-name aarya-stripe-service
# aws ecr create-repository --repository-name aarya-email-service

# get account Id
# aws sts get-caller-identity --query Account --output text

# Step 5: sync assets folder
aws s3 sync ./1-website/assets s3://aarya-website-assets/assets --exclude ".*"

aws s3 sync ./9-app/build s3://app.aarya.ai --exclude ".*"

# Step 6: on the instace fetch the latest image
## authenticate
aws ecr get-login-password --region $AWS_REGION | docker login --username AWS --password-stdin $AWS_ACCOUNT_ID.dkr.ecr.$AWS_REGION.amazonaws.com
## then
sudo systemctl stop docker-compose-app && docker-compose pull && sudo systemctl start docker-compose-app

# Run the CLI using image id
# docker run -v ./8-generator-cli/contexts/:/usr/src/app/contexts \
# -v ./8-generator-cli/prompts/:/usr/src/app/prompts \
# c59285d0686c /usr/src/app/aarya-generator-cli courses \
# --prompt-file /usr/src/app/prompts/apcs.json \
# --target-audience "High School Students" \
# --context-file /usr/src/app/contexts/courses/ap-csa-u1.json

mongoexport --uri="mongodb://127.0.0.1:27017" --db=aarya_web --collection=courses --out=courses.json
mongoexport --uri="mongodb://127.0.0.1:27017" --db=aarya_web --collection=units --out=units.json
mongoexport --uri="mongodb://127.0.0.1:27017" --db=aarya_web --collection=topics --out=topics.json
mongoexport --uri="mongodb://127.0.0.1:27017" --db=aarya_web --collection=questions --out=questions.json

scp -i macncheese-1May24.pem ~/projects/aarya/courses.json ec2-user@54.218.116.136:/home/ec2-user/aarya/
scp -i macncheese-1May24.pem ~/projects/aarya/units.json ec2-user@54.218.116.136:/home/ec2-user/aarya/
scp -i macncheese-1May24.pem ~/projects/aarya/topics.json ec2-user@54.218.116.136:/home/ec2-user/aarya/
scp -i macncheese-1May24.pem ~/projects/aarya/questions.json ec2-user@54.218.116.136:/home/ec2-user/aarya/

mongoimport --uri="mongodb://aarya-mongo:27017" --db=aarya_web --collection=courses --file=courses.json
mongoimport --uri="mongodb://aarya-mongo:27017" --db=aarya_web --collection=units --file=units.json
mongoimport --uri="mongodb://aarya-mongo:27017" --db=aarya_web --collection=topics --file=topics.json
mongoimport --uri="mongodb://aarya-mongo:27017" --db=aarya_web --collection=questions --file=questions.json


# # transfer files to EC2
# scp -i macncheese-1May24.pem ~/projects/aarya/1-website/.env.prod ec2-user@54.218.116.136:/home/ec2-user/aarya/1-website
# scp -i macncheese-1May24.pem ~/projects/aarya/4-consumers/.env.prod ec2-user@54.218.116.136:/home/ec2-user/aarya/4-consumers
# scp -i macncheese-1May24.pem ~/projects/aarya/5-stripe-service/.env.prod ec2-user@54.218.116.136:/home/ec2-user/aarya/5-stripe-service
# scp -i macncheese-1May24.pem ~/projects/aarya/6-email-service/.env.prod ec2-user@54.218.116.136:/home/ec2-user/aarya/6-email-service
# scp -i macncheese-1May24.pem -r ~/projects/aarya/6-email-service/.secrets ec2-user@54.218.116.136:/home/ec2-user/aarya/6-email-service/.secrets
# scp -i macncheese-1May24.pem ~/projects/aarya/nginx.conf ec2-user@54.218.116.136:/home/ec2-user/

# # run docker container
# sudo docker run --env-file ./1-website/.env.prod -v $(pwd)/logs:/app/logs -p 9191:9191 aarya-web
# sudo docker run --env-file ./4-consumers/.env.prod -v $(pwd)/logs:/app/logs aarya-queue-consumers
# sudo docker run --env-file ./5-stripe-service/.env.prod -v $(pwd)/logs:/app/logs aarya-stripe-service
# sudo docker run --env-file ./6-email-service/.env.prod -v $(pwd)/logs:/app/logs aarya-email-service

# # docker
# sudo systemctl start docker

# # run the service
# docker-compose down
# docker-compose up --build
# docker compose up

# # create a service file
# sudo vim /etc/systemd/system/docker-compose-app.service

# # contents of the service
# [Unit]
# Description=Docker Compose App Service
# After=docker.service
# Requires=docker.service

# [Service]
# WorkingDirectory=/home/ec2-user/aarya
# ExecStart=/usr/local/bin/docker-compose up
# ExecStop=/usr/local/bin/docker-compose down
# Restart=always
# TimeoutStartSec=0

# [Install]
# WantedBy=multi-user.target

# # enable and start the service
# sudo systemctl daemon-reload

# # enable the service to start on boot
# sudo systemctl enable docker-compose-app

# # check the status
# sudo systemctl status docker-compose-app

# manual restart
# sudo systemctl start docker-compose-app

# manual stop
# sudo systemctl stop docker-compose-app


# failed ECS attempt because running mongo in ECS is a terrible idea

# # push to ECR: example aarya-web. Do the same for other services
# aws ecr create-repository --repository-name aarya-web --region us-west-2
# aws ecr get-login-password --region us-west-2 | docker login --username AWS --password-stdin 579989334487.dkr.ecr.us-west-2.amazonaws.com
# docker build -t aarya-web .
# docker tag aarya-web:latest 579989334487.dkr.ecr.us-west-2.amazonaws.com/aarya-web:latest
# docker push 579989334487.dkr.ecr.us-west-2.amazonaws.com/aarya-web:latest

# # configure ECS
# aws ecs create-cluster --cluster-name aarya-prod

# # register task definition
# aws ecs register-task-definition --cli-input-json file://ecs-task-definition.json

# # finding security groups
# aws ec2 describe-security-groups --query 'SecurityGroups[*].[GroupId,GroupName]' --output text

# # create security group for ECS task
# aws ec2 create-security-group \
#     --group-name aarya-task-sg \
#     --description "Security group for Aarya ECS task" \
#     --vpc-id vpc-003c770afe43eeb0a

# # create security group for Mongo
# aws ec2 create-security-group \
#     --group-name aarya-mongo-sg \
#     --description "Security group for MongoDB" \
#     --vpc-id vpc-003c770afe43eeb0a

# # create security group for Redis
# aws ec2 create-security-group \
#     --group-name aarya-redis-sg \
#     --description "Security group for Redis" \
#     --vpc-id vpc-003c770afe43eeb0a

# # Allow MongoDB (port 27017) access from ECS tasks:
# aws ec2 authorize-security-group-ingress \
#     --group-id sg-0d043a3db1766a0b4 \
#     --protocol tcp \
#     --port 27017 \
#     --source-group sg-086411a122a8291a2

# # Allow Redis (port 6379) access from ECS tasks:
# aws ec2 authorize-security-group-ingress \
#     --group-id sg-0815cecde479bf6f1 \
#     --protocol tcp \
#     --port 6379 \
#     --source-group sg-086411a122a8291a2

# # enable inbound traffic
# aws ec2 authorize-security-group-ingress \
#     --group-id sg-086411a122a8291a2 \
#     --protocol tcp \
#     --port 80 \
#     --cidr 0.0.0.0/0

# aws ec2 authorize-security-group-ingress \
#     --group-id sg-086411a122a8291a2 \
#     --protocol tcp \
#     --port 443 \
#     --cidr 0.0.0.0/0


# # run task
# aws ecs run-task \
#   --cluster aarya-prod \
#   --launch-type FARGATE \
#   --network-configuration "awsvpcConfiguration={subnets=[subnet-0619b0a1bedb9ae40,subnet-062b3b8096cd4939b],securityGroups=[sg-086411a122a8291a2,sg-0d043a3db1766a0b4,sg-0815cecde479bf6f1],assignPublicIp=ENABLED}" \
#   --task-definition aarya-ecs-task

# # Create the ECS Task Execution Role
# aws iam create-role \
#     --role-name ecsTaskExecutionRole \
#     --assume-role-policy-document file://role-trust-policy.json

# # Attach the ECS Task Execution Policy
# aws iam attach-role-policy \
#     --role-name ecsTaskExecutionRole \
#     --policy-arn arn:aws:iam::aws:policy/service-role/AmazonECSTaskExecutionRolePolicy

# # Verify the Role Creation
# aws iam get-role --role-name ecsTaskExecutionRole

# # get role ARN
# aws iam get-role --role-name ecsTaskExecutionRole --query 'Role.Arn' --output text