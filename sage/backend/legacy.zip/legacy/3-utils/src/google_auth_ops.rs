use chrono::Utc;
use reqwest::blocking::Client;
use serde::{Deserialize, Serialize};
use serde_json::{from_str, json};

use crate::file_ops;

#[derive(Debug, Serialize, Deserialize)]
struct ServiceAccountCredentials {
    pub client_email: String,
    pub token_uri: String,
    pub private_key: String,
}

pub fn get_auth_token(
    service_account_file: &str,
    scope: &str,
) -> String {
    let contents = match file_ops::read_file(service_account_file) {
        Ok(c) => c,
        Err(e) => panic!("Error reading service account file: {}", e),
    };
    let creds = match from_str::<ServiceAccountCredentials>(contents.as_str()) {
        Ok(c) => c,
        Err(e) => panic!("Error parsing service account credentials: {}", e),
    };
    // println!("Creds: {:?}", creds);

    let jwt_claim = json!({
        "iss": creds.client_email,
        "scope": scope,
        "aud": creds.token_uri,
        "exp": Utc::now().timestamp() + 3600,
        "iat": Utc::now().timestamp(),
    });

    let key = creds.private_key.as_str();
    let jwt = jsonwebtoken::encode(
        &jsonwebtoken::Header::new(jsonwebtoken::Algorithm::RS256),
        &jwt_claim,
        &jsonwebtoken::EncodingKey::from_rsa_pem(key.as_bytes()).expect("Invalid private key"),
    )
    .expect("Failed to encode JWT");

    let client = Client::new();
    let res: serde_json::Value = client
        .post(creds.token_uri.as_str())
        .form(&json!({
            "grant_type": "urn:ietf:params:oauth:grant-type:jwt-bearer",
            "assertion": jwt,
        }))
        .send()
        .expect("Failed to get token")
        .json()
        .expect("Invalid token response");

    res["access_token"].as_str().unwrap().to_string()
}
