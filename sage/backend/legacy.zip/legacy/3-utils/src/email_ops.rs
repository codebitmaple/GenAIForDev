#[derive(Serialize)]
pub struct GoogleEmailMessage {
    raw: String,
}

use log::debug;
use reqwest::blocking::Client;
use serde::{Deserialize, Serialize};
use serde_json::json;

#[derive(Serialize, Deserialize, Debug)]
pub struct EmailRequest {
    pub key: String,
    pub subject: String,
    pub from: Option<String>,
    pub to: String,
    pub body: String,
}

pub fn send_email(request: EmailRequest) -> Option<bool> {
    let service_url = String::from("http://127.0.0.1:8181/send-email/");
    let client = Client::new();
    debug!("Sending email: {:?}", request);
    let response = client.post(service_url).json(&json!(request)).send();
    match response {
        Ok(r) => {
            if r.status().is_success() {
                Some(true)
            } else {
                eprintln!("Error sending email: {:?}", r);
                None
            }
        }
        Err(e) => {
            eprintln!("Error sending email: {:?}", e);
            None
        }
    }
}
