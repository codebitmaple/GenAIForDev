use handlebars::{Context, Handlebars, Helper, HelperDef, Output, RenderContext, RenderError, Renderable};

use crate::file_ops::read_files_from_dir;

#[derive(Clone, Copy)]
struct IfEqualsHelper;

impl HelperDef for IfEqualsHelper {
    fn call<'reg: 'rc, 'rc>(
        &self,
        h: &Helper<'rc>,
        r: &'reg Handlebars<'reg>,
        c: &'rc Context,
        rc: &mut RenderContext<'reg, 'rc>,
        out: &mut dyn Output,
    ) -> Result<(), RenderError> {
        let param1 = h.param(0).unwrap().value().as_str().unwrap();
        let param2 = h.param(1).unwrap().value().as_str().unwrap();

        if param1 == param2 {
            if let Some(template) = h.template() {
                template.render(r, c, rc, out)?;
            }
        } else if let Some(inverse) = h.inverse() {
            inverse.render(r, c, rc, out)?;
        }

        Ok(())
    }
}

pub fn configure_handlebars() -> Handlebars<'static> {
    let mut handlebars = Handlebars::new();
    read_files_from_dir("./assets/pages", ".hbs")
        .iter()
        .for_each(|file| handlebars.register_template_file(&file.name, &file.path).unwrap());

    handlebars.register_helper("ifEquals", Box::new(IfEqualsHelper));

    handlebars
}
