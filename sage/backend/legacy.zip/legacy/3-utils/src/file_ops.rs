use std::{ffi::OsStr, fs, path::Path};

use actix_multipart::{Field, MultipartError};
use actix_web::http::header::ContentDisposition;
use base64::prelude::*;
use futures::StreamExt;
use log::{debug, error};

pub struct FileInfo {
    pub name: String,
    pub path: String,
}

/// read all files of a given extension from a directory and all its subdirectories
/// then return a vector of each file name without its extension and its path
pub fn read_files_from_dir(
    dir: &str,
    ext: &str,
) -> Vec<FileInfo> {
    let mut files = Vec::new();
    // println!("Reading files from: [{}]", dir);
    let paths = std::fs::read_dir(dir).unwrap();
    for path in paths {
        let path = path.unwrap().path();
        if path.is_dir() {
            let mut sub_files = read_files_from_dir(path.to_str().unwrap(), ext);
            files.append(&mut sub_files);
        } else {
            let path = path.to_str().unwrap();
            if path.ends_with(ext) {
                let name = path.split('/').last().unwrap().split('.').next().unwrap().to_string();
                files.push(FileInfo { name, path: path.to_string() });
            }
        }
    }
    files
}

pub fn read_file(file: &str) -> Result<String, String> {
    match std::fs::read_to_string(file) {
        Ok(c) => Ok(c),
        Err(e) => Err(format!("Error reading file {}: [{:?}]", file, e)),
    }
}

pub fn write_file(
    file: &str,
    contents: &str,
) -> Result<(), String> {
    match std::fs::write(file, contents) {
        Ok(_) => Ok(()),
        Err(e) => Err(format!("Error writing file: [{:?}]", e)),
    }
}

pub fn write_file_force(
    file: &str,
    contents: &str,
) -> Result<(), String> {
    let path = Path::new(file);

    // Ensure the parent directory exists
    if let Some(parent) = path.parent() {
        if let Err(e) = fs::create_dir_all(parent) {
            return Err(format!("Error creating directories: [{:?}]", e));
        }
    }

    // Write the file (overwriting if it exists)
    match fs::write(path, contents) {
        Ok(_) => Ok(()),
        Err(e) => Err(format!("Error writing file: [{:?}]", e)),
    }
}

pub fn read_base64_file(file: &str) -> Option<String> {
    match std::fs::read_to_string(file) {
        Ok(c) => match BASE64_STANDARD.decode(c.as_bytes()) {
            Ok(b) => match String::from_utf8(b) {
                Ok(s) => Some(s),
                Err(e) => {
                    println!("Error converting bytes to string: [{:?}]", e);
                    None
                }
            },
            Err(e) => {
                println!("Error decoding base64: [{:?}]", e);
                None
            }
        },
        Err(e) => {
            println!("Error reading file: [{:?}]", e);
            None
        }
    }
}

pub fn get_extension_content_type(content_disposition: &ContentDisposition) -> Option<(String, String)> {
    let filename = content_disposition.get_filename().unwrap();
    let extension = Path::new(filename).extension().and_then(OsStr::to_str).unwrap_or("");

    debug!("upload filename: {}", filename);
    debug!("upload extension: {}", extension);

    match extension {
        "png" => Some(("image/png".to_string(), extension.to_string())),
        "jpg" => Some(("image/jpeg".to_string(), extension.to_string())),
        "jpeg" => Some(("image/jpeg".to_string(), extension.to_string())),
        "gif" => Some(("image/gif".to_string(), extension.to_string())),
        "svg" => Some(("image/svg+xml".to_string(), extension.to_string())),
        "pdf" => Some(("application/pdf".to_string(), extension.to_string())),
        "text" => Some(("text/plain".to_string(), extension.to_string())),
        "json" => Some(("application/json".to_string(), extension.to_string())),
        "md" => Some(("text/markdown".to_string(), extension.to_string())),
        _ => Some(("application/octet-stream".to_string(), extension.to_string())),
    }
}

pub async fn get_remote_contents(url: &str) -> Option<String> {
    let response = match reqwest::get(url).await {
        Ok(r) => r,
        Err(e) => {
            error!("Failed to download file: {:?}", e);
            return None;
        }
    };
    if response.status().is_success() {
        // Read the response bytes
        let bytes = match response.bytes().await {
            Ok(b) => b,
            Err(e) => {
                error!("Failed to read response bytes: {:?}", e);
                return None;
            }
        };
        Some(String::from_utf8(bytes.to_vec()).unwrap())
    } else {
        error!("Failed to download file: {:?}", response.status());
        None
    }
}

pub fn ensure_path(path: &str) -> Option<bool> {
    print!("Ensuring path: {:?}", path);
    let file_path = Path::new(path);
    if let Some(parent_dir) = file_path.parent() {
        // Create the parent directories if they don't exist
        if !parent_dir.exists() {
            match fs::create_dir_all(parent_dir) {
                Ok(_) => {
                    println!("Created directories: {:?}", parent_dir);
                    Some(true)
                }
                Err(e) => {
                    println!("Error creating directories: {:?}", e);
                    None
                }
            }
        } else {
            println!("Directories already exist: {:?}", parent_dir);
            Some(true)
        }
    } else {
        None
    }
}

pub async fn read_upload_file(item: Result<Field, MultipartError>) -> Option<String> {
    let mut field = item.unwrap();
    let mut buffer: Vec<u8> = Vec::new();
    while let Some(chunk) = field.next().await {
        let bytes = chunk.unwrap();
        buffer.extend_from_slice(&bytes); // Append the current chunk to the buffer
    }

    Some(String::from_utf8(buffer).unwrap())
}
