use actix_web::HttpRequest;

#[derive(serde::Serialize)]
pub struct Breadcrumb {
    pub label: String,
    pub url: String,
}

impl Breadcrumb {
    pub fn build_breadcrumbs(req: &HttpRequest) -> Option<Vec<Breadcrumb>> {
        // Example: Create breadcrumbs based on the path
        let mut breadcrumbs = Vec::new();

        let restricted_segments = ["booking", "instructor", "admin"];

        // Dynamically build breadcrumbs based on the request path
        let path_segments: Vec<&str> = req.path().trim_start_matches('/').split('/').collect();

        // If any segment is in the ignored_segments list, return empty
        if path_segments.iter().any(|segment| restricted_segments.contains(segment)) {
            return Some(breadcrumbs);
        }

        // Add Home as the first breadcrumb
        breadcrumbs.push(Breadcrumb {
            label: "Home".to_string(),
            url: "/".to_string(),
        });

        let mut accumulated_path = String::new();

        for segment in path_segments {
            if !segment.is_empty() {
                accumulated_path.push('/');
                accumulated_path.push_str(segment);
                breadcrumbs.push(Breadcrumb {
                    label: segment.to_string(),
                    url: accumulated_path.clone(),
                });
            }
        }

        if breadcrumbs.len() == 1 {
            return None;
        }

        Some(breadcrumbs)
    }
}
