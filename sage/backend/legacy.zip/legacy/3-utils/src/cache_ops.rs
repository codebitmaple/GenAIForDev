extern crate redis;

use log::{debug, info};
use redis::{Commands, FromRedisValue, ToRedisArgs};
use serde::de::DeserializeOwned;
use serde::Serialize;
use serde_json;
use std::sync::{Arc, Mutex};

use crate::environ::{Environ, RedisConfig};

#[derive(Clone)]
pub struct Cache {
    redis_conn: Arc<Mutex<redis::Connection>>, // Reuse the connection
    cache_key_prefix: String,
}

impl Default for Cache {
    fn default() -> Self {
        // let connection_str = Environ::default().redis_server;
        let redis_config: RedisConfig = Environ::init();
        let connection_str = redis_config.redis_server.clone();
        println!("Connecting to Redis at: {}", connection_str);
        let client = match redis::Client::open(connection_str.clone()) {
            Ok(c) => c,
            Err(e) => {
                panic!("Error creating Redis client at {}: {:?}", connection_str, e)
            }
        };
        let conn = match client.get_connection() {
            Ok(c) => c,
            Err(e) => {
                panic!("Error connecting to Redis: {:?}", e)
            }
        };
        Cache {
            redis_conn: Arc::new(Mutex::new(conn)), // Store the connection in an Arc<Mutex<>> for sharing and safety
            cache_key_prefix: "aarya_web:".to_string(),
        }
    }
}

impl Cache {
    fn get_ttl(&self) -> u64 {
        let redis_config: RedisConfig = Environ::init();
        redis_config.redis_ttl
    }

    fn build_key(
        &self,
        key: &str,
    ) -> String {
        format!("{}{}", self.cache_key_prefix, key)
    }

    pub fn get_scalar<T: FromRedisValue>(
        &self,
        key: &str,
    ) -> Option<T> {
        let mut conn = match self.redis_conn.lock() {
            Ok(c) => c,
            Err(e) => {
                println!("Error getting Redis connection: {:?}", e);
                return None;
            }
        }; // Reuse the connection
        let redis_key = self.build_key(key);
        debug!("Getting key: {}", redis_key);
        conn.get(redis_key).ok()
    }

    // Removed the specific set_scalar method for String values

    pub fn set_scalar<T: ToRedisArgs>(
        &self,
        key: String,
        value: T,
    ) {
        let mut conn = match self.redis_conn.lock() {
            Ok(c) => c,
            Err(e) => {
                println!("Error getting Redis connection: {:?}", e);
                return;
            }
        }; // Reuse the connection
        let redis_key = self.build_key(&key);
        let _: () = conn.set_ex::<String, T, ()>(redis_key, value, self.get_ttl()).unwrap();
    }

    pub fn get_json<T: DeserializeOwned>(
        &self,
        key: &str,
    ) -> Option<T> {
        info!("Getting key: {}", key);
        let mut conn = match self.redis_conn.lock() {
            Ok(c) => c,
            Err(e) => {
                println!("Error getting Redis connection: {:?}", e);
                return None;
            }
        }; // Reuse the connection
        let redis_key = self.build_key(key);
        debug!("Using Redis key: {}", redis_key);

        if let Ok(json_str) = conn.get::<_, String>(redis_key) {
            // Corrected syntax here
            serde_json::from_str(&json_str).ok()
        } else {
            None
        }
    }

    pub fn set_json<T: Serialize>(
        &self,
        key: &str,
        value: &T,
    ) -> bool {
        if let Ok(json_str) = serde_json::to_string(value) {
            let mut conn = match self.redis_conn.lock() {
                Ok(c) => c,
                Err(e) => {
                    println!("Error getting Redis connection: {:?}", e);
                    return false;
                }
            }; // Reuse the connection
            let redis_key = self.build_key(key);
            let _: () = conn.set_ex(redis_key, json_str.clone(), self.get_ttl()).unwrap();
            info!("Setting key: {}", key);
            true
        } else {
            false
        }
    }

    pub fn remove(
        &self,
        key: &str,
    ) -> bool {
        info!("Removing key: {}", key);
        let mut conn = match self.redis_conn.lock() {
            Ok(c) => c,
            Err(e) => {
                println!("Error getting Redis connection: {:?}", e);
                return false;
            }
        }; // Reuse the connection
        let redis_key = self.build_key(key);
        conn.del(redis_key).unwrap_or(0) > 0
    }
}
