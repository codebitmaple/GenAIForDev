use base64::{prelude::BASE64_STANDARD, Engine};

pub fn escape(input: &str) -> String {
    let mut escaped = String::new();
    for c in input.chars() {
        match c {
            '\\' => escaped.push_str("\\\\"),
            '\"' => escaped.push_str("\\\""),
            '\n' => escaped.push_str(" \\n"),
            '\r' => escaped.push_str("\\r"),
            '\t' => escaped.push_str("\\t"),
            _ => escaped.push(c),
        }
    }
    escaped
}

pub fn unescape(input: &str) -> String {
    // input.replace("\\n", " \n").replace("\\r", "\r").replace("\\t", "\t").replace("\\\"", "\"").replace("\\\\", "\\")
    input.replace("\n\r", "\n")
}

pub fn to_base64(input: &[u8]) -> String {
    BASE64_STANDARD.encode(input)
}

pub fn from_base64(input: &[u8]) -> String {
    let result = match BASE64_STANDARD.decode(input) {
        Ok(b) => match String::from_utf8(b) {
            Ok(s) => Some(s),
            Err(e) => {
                println!("Error converting bytes to string: [{:?}]", e);
                None
            }
        },
        Err(e) => {
            println!("Error decoding base64: [{:?}]", e);
            None
        }
    };

    result.unwrap_or_default()
}
