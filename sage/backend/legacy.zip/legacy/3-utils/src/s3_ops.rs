use actix_multipart::{Field, MultipartError};
use aws_config::meta::region::RegionProviderChain;
use aws_config::{self, BehaviorVersion, ConfigLoader, Region};
use aws_sdk_s3::primitives::ByteStream;
use aws_sdk_s3::Client;
use futures::StreamExt;
use log::{debug, error};

use crate::file_ops;

pub async fn upload(
    item: Result<Field, MultipartError>,
    path: String,
    s3_bucket: String,
) -> Option<String> {
    let mut field = item.unwrap();
    let content_type = file_ops::get_extension_content_type(field.content_disposition()).unwrap();
    let extension = content_type.1;
    let content_type = content_type.0;
    let path = format!("{}.{}", path, extension);

    debug!("S3 upload path: {}", path);

    let mut buffer: Vec<u8> = Vec::new();

    while let Some(chunk) = field.next().await {
        let bytes = chunk.unwrap();
        buffer.extend_from_slice(&bytes); // Append the current chunk to the buffer
    }

    upload_bytes(&s3_bucket, path.as_str(), &buffer, content_type.as_str()).await.map(|_| path.clone());

    Some(path)
}

pub async fn upload_leading_slash(
    item: Result<Field, MultipartError>,
    path: String,
    s3_bucket: String,
) -> Option<String> {
    upload(item, path, s3_bucket).await.map(|path| format!("/{}", path))
}

/// Uploads a file to the specified S3 bucket
pub async fn upload_bytes(
    bucket: &str,
    key: &str,
    bytes: &[u8],
    content_type: &str,
) -> Option<String> {
    // Load the AWS configuration from environment or default config
    let region_provider = RegionProviderChain::first_try(Region::new("us-west-2"));
    let config = ConfigLoader::default().behavior_version(BehaviorVersion::latest()).region(region_provider).load().await;

    debug!("Bucket: {:?}", bucket);
    debug!("Key: {:?}", key);

    // Create an S3 client using the loaded config
    let client = Client::new(&config);

    // Convert the buffer to a ByteStream that S3 API expects
    let byte_stream = ByteStream::from(bytes.to_vec());

    // Perform the upload operation
    let result = client
        .put_object()
        .bucket(bucket)
        .key(key) // S3 object key (path inside the bucket)
        .body(byte_stream)
        .content_type(content_type.to_string()) // Set the content type accordingly
        .send()
        .await;

    match result {
        Ok(f) => {
            debug!("File uploaded successfully! {:?}", f);
            Some(key.to_string())
        }
        Err(err) => {
            error!("Failed to upload file: {:?}", err);
            None
        }
    }
}
