use std::fmt::Debug;

use log::error;
use schemars::{schema_for, JsonSchema};
use serde::Serialize;
use serde_json::Value;

pub fn to_json_schema<T>() -> Option<String>
where
    T: JsonSchema + Serialize + Debug,
{
    let schema = schema_for!(T);
    match serde_json::to_string_pretty(&schema) {
        Ok(json) => Some(json),
        Err(e) => {
            error!("Error converting schema to JSON: {}", e);
            None
        }
    }
}

pub fn to_openai_schema(schema: String) -> Option<Value> {
    let mut schema: Value = serde_json::from_str(&schema).unwrap();
    // Remove the $schema field
    if let Some(obj) = schema.as_object_mut() {
        obj.remove("$schema");
    }

    // Remove title field
    if let Some(obj) = schema.as_object_mut() {
        obj.remove("title");
    }

    Some(schema)
}
