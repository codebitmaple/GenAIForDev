use std::str::FromStr;

use futures::stream::TryStreamExt;
use log::{debug, error, warn};
use mongodb::{
    bson::{self, doc, oid::ObjectId, Bson},
    Client, Collection,
};

use serde::{de::DeserializeOwned, Serialize};

use crate::{
    environ::{DatabaseConfig, Environ},
    result_types::{DatabaseErrorType, EntityResult, SuccessResultType},
};

pub struct Database;

impl Database {
    pub fn generate_id() -> ObjectId {
        ObjectId::new()
    }

    pub async fn get_client() -> Client {
        let db_config: DatabaseConfig = Environ::init();
        match Client::with_uri_str(db_config.db_connection_string).await {
            Ok(client) => client,
            Err(e) => {
                panic!("Error connecting to database: {}", e);
            }
        }
    }

    pub fn get_collection<T>(
        client: &Client,
        collection_name: &str,
    ) -> Collection<T> {
        let db_config: DatabaseConfig = Environ::init();
        client.database(db_config.db_name.as_str()).collection::<T>(collection_name)
    }

    pub async fn create<T>(
        collection: &Collection<T>,
        entity: &T,
    ) -> EntityResult<SuccessResultType>
    where
        T: Serialize + Unpin + Send + Sync,
    {
        match collection.insert_one(entity, None).await {
            Ok(result) => EntityResult::Success(SuccessResultType::Created(result.inserted_id.as_object_id().unwrap().to_hex())),
            Err(e) => EntityResult::Error(DatabaseErrorType::MutationError(format!("Error creating document in {}", collection.name()), e.to_string())),
        }
    }

    pub async fn find_all<T>(collection: Collection<T>) -> EntityResult<Vec<T>>
    where
        T: DeserializeOwned + Unpin + Send + Sync,
    {
        match collection.find(doc! {}, None).await {
            Ok(mut cursor) => {
                let mut entities = vec![];
                loop {
                    match cursor.try_next().await {
                        Ok(Some(entity)) => entities.push(entity),
                        Ok(None) => break,
                        Err(e) => return EntityResult::Error(DatabaseErrorType::QueryError(format!("Error getting documents from {}", collection.name()), e.to_string())),
                    }
                }
                EntityResult::Success(entities)
            }
            Err(e) => EntityResult::Error(DatabaseErrorType::QueryError(format!("Error getting documents from {}", collection.name()), e.to_string())),
        }
    }

    /// Find all documents in a collection that match a filter
    pub async fn filter<T>(
        collection: Collection<T>,
        field_name: String,
        field_value: String,
    ) -> EntityResult<Vec<T>>
    where
        T: DeserializeOwned + Unpin + Send + Sync,
    {
        let filter = doc! { field_name: field_value };
        debug!("Filter: {:?}", filter);
        match collection.find(filter, None).await {
            Ok(mut cursor) => {
                let mut results = Vec::new();
                match cursor.try_next().await {
                    Ok(Some(result)) => results.push(result),
                    Ok(None) => (),
                    Err(e) => return EntityResult::Error(DatabaseErrorType::QueryError(format!("Error getting documents from {}", collection.name()), e.to_string())),
                }
                EntityResult::Success(results)
            }
            Err(e) => EntityResult::Error(DatabaseErrorType::QueryError(format!("Error getting documents from {}", collection.name()), e.to_string())),
        }
    }

    /// Find all documents in a collection that match a filter
    pub async fn filter_by<T>(
        collection: Collection<T>,
        filter: bson::Document,
    ) -> Option<Vec<T>>
    where
        T: DeserializeOwned + Unpin + Send + Sync,
    {
        debug!("Filter: {:?}", filter);
        match collection.find(filter, None).await {
            Ok(mut cursor) => {
                let mut results = Vec::new();
                while let Some(result) = cursor.try_next().await.unwrap_or(None) {
                    results.push(result);
                }
                if results.is_empty() {
                    warn!("No documents found in {}", collection.name());
                    None
                } else {
                    Some(results)
                }
            }
            Err(e) => {
                error!("Error getting documents from {}: {}", collection.name(), e);
                None
            }
        }
    }

    pub async fn find_by<T, E>(
        collection: &Collection<T>,
        key: String,
        value: E,
    ) -> EntityResult<T>
    where
        T: DeserializeOwned + Unpin + Send + Sync,
        E: Serialize + Into<Bson>,
    {
        match collection.find_one(doc! {key.clone(): value}, None).await {
            Ok(cursor) => match cursor {
                Some(r) => EntityResult::Success(r),
                None => EntityResult::Error(DatabaseErrorType::NotFound(
                    format!("Error finding document by {} in {}", key, collection.name()),
                    "Document not found".to_string(),
                )),
            },
            Err(e) => EntityResult::Error(DatabaseErrorType::QueryError(format!("Error getting documents from {}", collection.name()), e.to_string())),
        }
    }

    pub async fn find<T>(
        collection: Collection<T>,
        id: &String,
    ) -> EntityResult<T>
    where
        T: DeserializeOwned + Unpin + Send + Sync,
    {
        let object_id = match ObjectId::from_str(id.as_str()) {
            Ok(id) => id,
            Err(e) => return EntityResult::Error(DatabaseErrorType::QueryError(format!("Error parsing id {} in {}", id, collection.name()), e.to_string())),
        };

        match collection.find_one(doc! {"_id": object_id}, None).await {
            Ok(cursor) => match cursor {
                Some(r) => EntityResult::Success(r),
                None => EntityResult::Error(DatabaseErrorType::NotFound(
                    format!("Error finding document {} in {}", id, collection.name()),
                    "Document not found".to_string(),
                )),
            },
            Err(e) => EntityResult::Error(DatabaseErrorType::QueryError(format!("Error getting documents from {}", collection.name()), e.to_string())),
        }
    }

    pub async fn update_with<T>(
        collection: &Collection<T>,
        entity: &T,
        id: &ObjectId,
    ) -> EntityResult<SuccessResultType>
    where
        T: Serialize + Unpin + Send + Sync,
    {
        Self::update(collection, entity, &id.to_hex()).await
    }

    pub async fn update<T>(
        collection: &Collection<T>,
        entity: &T,
        id: &str,
    ) -> EntityResult<SuccessResultType>
    where
        T: Serialize + Unpin + Send + Sync,
    {
        let object_id = match ObjectId::from_str(id) {
            Ok(id) => id,
            Err(_) => {
                return EntityResult::Error(DatabaseErrorType::MutationError("Invalid ObjectId format".to_string(), "Failed to parse id".to_string()));
            }
        };

        // Convert the entity into a BSON document.
        let mut entity_doc = match bson::to_document(entity) {
            Ok(doc) => doc,
            Err(e) => {
                return EntityResult::Error(DatabaseErrorType::MutationError("Error serializing entity to BSON".to_string(), e.to_string()));
            }
        };

        // Remove the _id field to avoid attempting to update it.
        entity_doc.remove("_id");

        let filter = doc! { "_id": object_id };
        let update = doc! { "$set": entity_doc };

        debug!("Filter: {:?}", filter);
        debug!("Update: {:?}", update);

        match collection.update_one(filter, update, None).await {
            Ok(result) => {
                if result.matched_count > 0 {
                    EntityResult::Success(SuccessResultType::Updated(id.to_string()))
                } else {
                    EntityResult::Error(DatabaseErrorType::MutationError(
                        format!("No document found to update in {}", collection.name()),
                        "No matching document found".to_string(),
                    ))
                }
            }
            Err(e) => EntityResult::Error(DatabaseErrorType::MutationError(format!("Error updating document in {}", collection.name()), e.to_string())),
        }
    }

    pub async fn update_by<T>(
        collection: &Collection<T>,
        entity: &T,
        filter: bson::Document,
    ) -> EntityResult<SuccessResultType>
    where
        T: Serialize + Unpin + Send + Sync,
    {
        let update = doc! { "$set": bson::to_bson(&entity).unwrap() };

        debug!("Filter: {:?}", filter);
        debug!("Update: {:?}", update);

        match collection.update_one(filter.clone(), update, None).await {
            Ok(result) => {
                if result.matched_count > 0 {
                    EntityResult::Success(SuccessResultType::Updated(filter.to_string()))
                } else {
                    EntityResult::Error(DatabaseErrorType::MutationError(
                        format!("No document found to update in {}", collection.name()),
                        "No matching document found".to_string(),
                    ))
                }
            }
            Err(e) => EntityResult::Error(DatabaseErrorType::MutationError(format!("Error updating document in {}", collection.name()), e.to_string())),
        }
    }
}
