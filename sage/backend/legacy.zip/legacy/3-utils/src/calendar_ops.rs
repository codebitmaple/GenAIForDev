use chrono::{Datelike, NaiveDate, NaiveTime, Weekday};
use chrono::{Duration, Utc};
use reqwest::blocking::Client;
use serde::Serialize;
use std::collections::HashSet;

use crate::date_ops;

#[derive(Debug)]
pub struct CalendarEvent {
    pub event_id: String,
    pub summary: String,
    pub start: String,
    pub end: String,
}

#[derive(Debug, PartialEq)]
pub struct InstructorAvailability {
    pub user_id: String,
    pub role: String,
    pub days: HashSet<Weekday>,
    pub start_time: Vec<NaiveTime>,
    pub out_of_office: HashSet<NaiveDate>,
}

#[derive(Debug, PartialEq)]
pub struct AvailabilityEntry {
    pub date: NaiveDate,
    pub time_slots: Vec<TimeSlotStatus>,
}

#[derive(Debug, PartialEq)]
pub enum TimeSlotStatus {
    Available(NaiveTime),
    Blocked(String),
}

#[derive(Debug, Serialize)]
pub struct TimeSlot {
    pub display_time: String,
    pub typed_time: NaiveTime,
}

#[derive(Debug, Serialize)]
pub struct AvailabilityModel {
    pub display_date: String, // Use String for serialization compatibility with Handlebars
    pub typed_date: NaiveDate,
    pub time_slots: Vec<TimeSlot>,
}

pub fn generate_availability_list(
    availability: &InstructorAvailability,
    start_date: NaiveDate,
    days_ahead: i64,
) -> Vec<AvailabilityEntry> {
    let mut availability_list: Vec<AvailabilityEntry> = Vec::new();

    for i in 0..days_ahead {
        let date = start_date + chrono::Duration::days(i);
        let weekday = date.weekday();

        let mut time_slots: Vec<TimeSlotStatus> = Vec::new();

        if availability.out_of_office.contains(&date) {
            for _ in &availability.start_time {
                time_slots.push(TimeSlotStatus::Blocked("Blocked (Out of Office)".to_string()));
            }
        } else if availability.days.contains(&weekday) {
            for &time in &availability.start_time {
                time_slots.push(TimeSlotStatus::Available(time));
            }
        } else {
            for _ in &availability.start_time {
                time_slots.push(TimeSlotStatus::Blocked("Blocked (Unavailable Day)".to_string()));
            }
        }

        availability_list.push(AvailabilityEntry { date, time_slots });
    }

    availability_list
}

pub fn get_events(
    calendar_id: &str,
    token: &str,
    duration: Duration,
) -> Vec<CalendarEvent> {
    let now = Utc::now();
    let time_min = now.format("%Y-%m-%dT%H:%M:%S%:z").to_string();
    let time_max = (now + duration).format("%Y-%m-%dT%H:%M:%S%:z").to_string();

    println!("Time Min: {}", time_min);
    println!("Time Max: {}", time_max);

    let url = format!("https://www.googleapis.com/calendar/v3/calendars/{}/events", calendar_id);

    let client = Client::new();
    let res: serde_json::Value = client
        .get(url)
        .bearer_auth(token)
        .query(&[("timeMin", time_min.as_str()), ("timeMax", time_max.as_str()), ("singleEvents", "true"), ("orderBy", "startTime")])
        .send()
        .expect("Failed to get events")
        .json()
        .expect("Invalid events response");

    // println!("Events: {:?}", res);

    res["items"]
        .as_array()
        .unwrap_or(&vec![])
        .iter()
        .map(|event| CalendarEvent {
            event_id: event["id"].as_str().unwrap_or("").to_string(),
            summary: event["summary"].as_str().unwrap_or("").to_string(),
            start: event["start"]["dateTime"].as_str().or_else(|| event["start"]["date"].as_str()).unwrap_or("").to_string(),
            end: event["end"]["dateTime"].as_str().or_else(|| event["end"]["date"].as_str()).unwrap_or("").to_string(),
        })
        .collect()
}

pub fn get_availablity_model(
    availability: &InstructorAvailability,
    start_date: NaiveDate,
    days_ahead: i64,
) -> Vec<AvailabilityModel> {
    generate_availability_list(availability, start_date, days_ahead)
        .into_iter()
        .map(|entry| AvailabilityModel {
            typed_date: entry.date,
            display_date: date_ops::format_date(&entry.date.to_string(), None, Some("%A, %B %e")),
            time_slots: entry
                .time_slots
                .into_iter()
                .filter_map(|slot| match slot {
                    TimeSlotStatus::Available(time) => Some(TimeSlot {
                        display_time: date_ops::format_time_from(&time),
                        typed_time: time,
                    }),
                    TimeSlotStatus::Blocked(reason) if reason.contains("Out of Office") => Some(TimeSlot {
                        display_time: "Out of Office".to_string(),
                        typed_time: NaiveTime::from_hms_opt(0, 0, 0).expect("Invalid time"), // Placeholder time
                    }),
                    _ => None, // Exclude other blocked or unavailable slots
                })
                .collect(),
        })
        .filter(|model| !model.time_slots.is_empty()) // Filter out entries with empty time_slots
        .collect()
}

#[cfg(test)]
mod tests {

    use crate::google_auth_ops::get_auth_token;

    use super::*;
    use chrono::Duration;

    const SCOPE: &str = "https://www.googleapis.com/auth/calendar.events.readonly";

    #[test]
    fn test_authenticate_with_service_account() {
        // Test with a valid service account file
        let service_account_file = ".secrets/aarya-calendar-api-service-account-key.json";
        let token = get_auth_token(service_account_file, SCOPE);
        // println!("Token: {}", token);
        assert!(!token.is_empty(), "Token should not be empty");
    }

    #[test]
    fn test_get_events() {
        // Use a valid token and calendar ID
        let service_account_file = ".secrets/aarya-calendar-api-service-account-key.json";
        let token = get_auth_token(service_account_file, SCOPE);
        let calendar_id = "sanjeet.sahay@gmail.com";
        let duration = Duration::days(7);

        let events = get_events(calendar_id, &token, duration);
        // assert!(events.len() >= 0, "Events should be retrieved successfully");

        // println!("Events: {:?}", events);

        // Check if the events list is empty (if calendar has no events)
        if events.is_empty() {
            assert_eq!(events.len(), 0, "No events should be returned");
        } else {
            // Test the structure of retrieved events
            for event in &events {
                assert!(!event.event_id.is_empty(), "Event ID should not be empty");
                // assert!(!event.summary.is_empty(), "Summary should not be empty");
                assert!(!event.start.is_empty(), "Start time should not be empty");
                assert!(!event.end.is_empty(), "End time should not be empty");
            }
        }
    }

    #[test]
    fn test_generate_availability_list_basic() {
        let availability = InstructorAvailability {
            user_id: "abc".to_string(),
            role: "tutor".to_string(),
            days: vec![Weekday::Mon, Weekday::Tue, Weekday::Thu].into_iter().collect(),
            start_time: vec![
                NaiveTime::from_hms_opt(8, 0, 0).expect("Invalid time"),
                NaiveTime::from_hms_opt(9, 0, 0).expect("Invalid time"),
                NaiveTime::from_hms_opt(17, 0, 0).expect("Invalid time"),
                NaiveTime::from_hms_opt(18, 0, 0).expect("Invalid time"),
            ],
            out_of_office: vec![NaiveDate::from_ymd_opt(2024, 9, 4).expect("Invalid date")].into_iter().collect(),
        };

        let start_date = NaiveDate::from_ymd_opt(2024, 9, 3).expect("Invalid date");
        let days_ahead = 3;

        let result = generate_availability_list(&availability, start_date, days_ahead);

        let expected = vec![
            AvailabilityEntry {
                date: NaiveDate::from_ymd_opt(2024, 9, 3).expect(""),
                time_slots: vec![
                    TimeSlotStatus::Available(NaiveTime::from_hms_opt(8, 0, 0).expect("Invalid time")),
                    TimeSlotStatus::Available(NaiveTime::from_hms_opt(9, 0, 0).expect("Invalid time")),
                    TimeSlotStatus::Available(NaiveTime::from_hms_opt(17, 0, 0).expect("Invalid time")),
                    TimeSlotStatus::Available(NaiveTime::from_hms_opt(18, 0, 0).expect("Invalid time")),
                ],
            },
            AvailabilityEntry {
                date: NaiveDate::from_ymd_opt(2024, 9, 4).expect("Invalid date"),
                time_slots: vec![
                    TimeSlotStatus::Blocked("Blocked (Out of Office)".to_string()),
                    TimeSlotStatus::Blocked("Blocked (Out of Office)".to_string()),
                    TimeSlotStatus::Blocked("Blocked (Out of Office)".to_string()),
                    TimeSlotStatus::Blocked("Blocked (Out of Office)".to_string()),
                ],
            },
            AvailabilityEntry {
                date: NaiveDate::from_ymd_opt(2024, 9, 5).expect("Invalid date"),
                time_slots: vec![
                    TimeSlotStatus::Available(NaiveTime::from_hms_opt(8, 0, 0).expect("Invalid time")),
                    TimeSlotStatus::Available(NaiveTime::from_hms_opt(9, 0, 0).expect("Invalid time")),
                    TimeSlotStatus::Available(NaiveTime::from_hms_opt(17, 0, 0).expect("Invalid time")),
                    TimeSlotStatus::Available(NaiveTime::from_hms_opt(18, 0, 0).expect("Invalid time")),
                ],
            },
        ];

        assert_eq!(result, expected);
    }

    #[test]
    fn test_generate_availability_list_unavailable_day() {
        let availability = InstructorAvailability {
            user_id: "abc".to_string(),
            role: "tutor".to_string(),
            days: vec![Weekday::Mon, Weekday::Tue].into_iter().collect(),
            start_time: vec![NaiveTime::from_hms_opt(8, 0, 0).expect("Invalid time"), NaiveTime::from_hms_opt(9, 0, 0).expect("Invalid time")],
            out_of_office: HashSet::new(),
        };

        let start_date = NaiveDate::from_ymd_opt(2024, 9, 5).expect("Invalid date"); // Thursday
        let days_ahead = 1;

        let result = generate_availability_list(&availability, start_date, days_ahead);

        let expected = vec![AvailabilityEntry {
            date: NaiveDate::from_ymd_opt(2024, 9, 5).expect("Invalid date"),
            time_slots: vec![
                TimeSlotStatus::Blocked("Blocked (Unavailable Day)".to_string()),
                TimeSlotStatus::Blocked("Blocked (Unavailable Day)".to_string()),
            ],
        }];

        assert_eq!(result, expected);
    }

    #[test]
    fn test_generate_availability_list_mixed_days() {
        let availability = InstructorAvailability {
            user_id: "abc".to_string(),
            role: "tutor".to_string(),
            days: vec![Weekday::Mon, Weekday::Thu].into_iter().collect(),
            start_time: vec![NaiveTime::from_hms_opt(8, 0, 0).expect("Invalid time"), NaiveTime::from_hms_opt(10, 0, 0).expect("Invalid time")],
            out_of_office: vec![NaiveDate::from_ymd_opt(2024, 9, 9).expect("Invalid date")].into_iter().collect(),
        };

        let start_date = NaiveDate::from_ymd_opt(2024, 9, 8).expect("Invalid date"); // Sunday
        let days_ahead = 3;

        let result = generate_availability_list(&availability, start_date, days_ahead);

        let expected = vec![
            AvailabilityEntry {
                date: NaiveDate::from_ymd_opt(2024, 9, 8).expect("Invalid date"),
                time_slots: vec![
                    TimeSlotStatus::Blocked("Blocked (Unavailable Day)".to_string()),
                    TimeSlotStatus::Blocked("Blocked (Unavailable Day)".to_string()),
                ],
            },
            AvailabilityEntry {
                date: NaiveDate::from_ymd_opt(2024, 9, 9).expect("Invalid date"),
                time_slots: vec![
                    TimeSlotStatus::Blocked("Blocked (Out of Office)".to_string()),
                    TimeSlotStatus::Blocked("Blocked (Out of Office)".to_string()),
                ],
            },
            AvailabilityEntry {
                date: NaiveDate::from_ymd_opt(2024, 9, 10).expect("Invalid date"),
                time_slots: vec![
                    TimeSlotStatus::Blocked("Blocked (Unavailable Day)".to_string()),
                    TimeSlotStatus::Blocked("Blocked (Unavailable Day)".to_string()),
                ],
            },
        ];

        assert_eq!(result, expected);
    }
}
